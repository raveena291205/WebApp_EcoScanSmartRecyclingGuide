import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set standard parsing limit for base64 images
  app.use(express.json({ limit: "15mb" }));

  // Keep GoogleGenAI client lazy-loaded or instantiable with a safety check
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not set. Please add it via the Settings > Secrets panel in AI Studio.");
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  };

  // API Scan route using server-side Gemini 3.5 Flash vision AI
  app.post("/api/scan", async (req, res) => {
    try {
      const { image, mimeType } = req.body;

      if (!image) {
        return res.status(400).json({ error: "Missing image base64 data." });
      }

      // Check key existence
      let ai;
      try {
        ai = getGeminiClient();
      } catch (err: any) {
        return res.status(500).json({ error: err.message || "Gemini API configuration missing." });
      }

      const cleanBase64 = image.replace(/^data:image\/\w+;base64,/, "");

      const imagePart = {
        inlineData: {
          mimeType: mimeType || "image/jpeg",
          data: cleanBase64,
        },
      };

      const promptPart = {
        text: `Analyze this image of waste/trash. Categorize it precisely into one of the following waste types: 'organic', 'plastic', 'paper', 'metal', 'glass', or 'B3'.
Provide details including the specific item name, exact disposal method for a citizen in Indonesia (how to empty, clean, sort), upcycling tips, environmental hazard/impact if not recycled, whether it is recyclable, and a reasonable eco points reward (integer between 10 and 50) based on ecological sorting value.
Reply strictly in JSON matching the specified schema structure. Ensure all fields (including itemName, disposalMethod, recyclingTips, and environmentalImpact) are written strictly and exclusively in Bahasa Indonesia, addressing a youth-friendly sustainability audience in Indonesia. Do not use English for any textual descriptions.`,
      };

      const responseSchema = {
        type: Type.OBJECT,
        properties: {
          itemName: {
            type: Type.STRING,
            description: "Nama spesifik dalam Bahasa Indonesia dari sampah yang dideteksi, contoh: Botol Plastik Teh Sosro, Kertas Koran Bekas, Baterai Alkalin AA Bekas"
          },
          wasteType: {
            type: Type.STRING,
            description: "Kategori resmi. Harus salah satu dari: 'organic', 'plastic', 'paper', 'metal', 'glass', 'B3'"
          },
          disposalMethod: {
            type: Type.STRING,
            description: "Langkah-langkah terperinci dalam Bahasa Indonesia tentang cara membersihkan, memilah, dan menyerahkan/membuangnya ke Bank Sampah atau wadah resmi di Indonesia."
          },
          recyclingTips: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "3 ide pembuatan kerajinan kreasi daur ulang kreatif (upcycling) dalam Bahasa Indonesia yang bisa dibuat di rumah oleh anak muda."
          },
          environmentalImpact: {
            type: Type.STRING,
            description: "Dampak negatif buruk bagi kelestarian alam dalam Bahasa Indonesia jika dibuang begitu saja tanpa didaur ulang (seperti di TPA Bantar Gebang atau sungai-sungai Indonesia)."
          },
          isRecyclable: {
            type: Type.BOOLEAN,
            description: "True jika dapat didaur ulang atau dikomposkan. False jika sangat terkontaminasi atau berbahaya."
          },
          ecoPoints: {
            type: Type.INTEGER,
            description: "Poin logis sebagai penghargaan pemilahan sampah yang tepat. Rentang: 10 hingga 50."
          }
        },
        required: [
          "itemName",
          "wasteType",
          "disposalMethod",
          "recyclingTips",
          "environmentalImpact",
          "isRecyclable",
          "ecoPoints"
        ]
      };

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: { parts: [imagePart, promptPart] },
        config: {
          responseMimeType: "application/json",
          responseSchema,
          temperature: 0.2, // low temperature for precise classification
        }
      });

      const text = response.text;
      if (!text) {
        throw new Error("Empty response from AI vision model.");
      }

      const parsedResult = JSON.parse(text);
      return res.json(parsedResult);

    } catch (err: any) {
      console.error("Gemini Scan Error:", err);
      return res.status(500).json({
        error: "Failed to analyze image with EcoScan AI. " + (err.message || "Please check your network and API credentials.")
      });
    }
  });

  // Vite dev or production static serving config
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`EcoScan backend server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
