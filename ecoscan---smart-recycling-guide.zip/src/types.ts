export type WasteType = 'organic' | 'plastic' | 'paper' | 'metal' | 'glass' | 'B3';

export interface ScanResult {
  itemName: string;
  wasteType: WasteType;
  disposalMethod: string;
  recyclingTips: string[];
  environmentalImpact: string;
  isRecyclable: boolean;
  ecoPoints: number;
}

export interface EcoLogItem {
  id: string;
  timestamp: string;
  itemName: string;
  wasteType: WasteType;
  ecoPoints: number;
  imageUrl?: string;
}

export interface EcoPointsStats {
  totalScanned: number;
  mostCommonType: WasteType | 'None';
  pointsEarned: number;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number; // index of correct option
  explanation: string;
}

export interface WasteCategoryDetail {
  id: WasteType;
  name: string;
  nameIndonesian: string;
  iconName: string;
  description: string;
  descriptionIndonesian: string;
  dos: string[];
  donts: string[];
  upcyclingIdeas: string[];
  bgGradient: string;
  accentColor: string;
  textColor: string;
}

export interface EcoFact {
  id: number;
  emoji: string;
  title: string;
  fact: string;
  factIndonesian: string;
}
