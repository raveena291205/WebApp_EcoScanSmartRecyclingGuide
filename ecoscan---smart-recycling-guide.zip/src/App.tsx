import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import Header from './components/Header';
import ScanPage from './components/ScanPage';
import GuidePage from './components/GuidePage';
import FactsPage from './components/FactsPage';
import QuizPage from './components/QuizPage';
import LogPage from './components/LogPage';
import SplashScreen from './components/SplashScreen';
import { EcoLogItem, WasteType } from './types';
import { getLevelInfo, EcoLevel } from './utils/level';
import LevelUpPopup from './components/LevelUpPopup';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('scan');
  const [points, setPoints] = useState<number>(0);
  const [logs, setLogs] = useState<EcoLogItem[]>([]);
  const [isSplashActive, setIsSplashActive] = useState<boolean>(true);
  const [levelUpData, setLevelUpData] = useState<{
    show: boolean;
    oldLevel: EcoLevel | null;
    newLevel: EcoLevel | null;
  }>({
    show: false,
    oldLevel: null,
    newLevel: null
  });

  // Hydrate states from localStorage on startup
  useEffect(() => {
    try {
      const persistedPoints = localStorage.getItem('eco_points');
      if (persistedPoints) {
        setPoints(parseInt(persistedPoints, 10));
      } else {
        setPoints(0);
      }

      const persistedLogs = localStorage.getItem('eco_scans_history');
      if (persistedLogs) {
        setLogs(JSON.parse(persistedLogs));
      } else {
        setLogs([]);
      }
    } catch (err) {
      console.error("Local storage hydration failed:", err);
    }
  }, []);

  // Save new scanned waste item to log
  const handleAddLog = (newScan: { itemName: string; wasteType: WasteType; ecoPoints: number; imageUrl?: string }) => {
    const newItem: EcoLogItem = {
      id: 'sc_' + Math.random().toString(36).substring(2, 11),
      timestamp: new Date().toISOString(),
      ...newScan
    };
    
    const updatedLogs = [newItem, ...logs];
    setLogs(updatedLogs);
    localStorage.setItem('eco_scans_history', JSON.stringify(updatedLogs));
  };

  // Delete individual log
  const handleDeleteLog = (id: string) => {
    const updatedLogs = logs.filter(item => item.id !== id);
    setLogs(updatedLogs);
    localStorage.setItem('eco_scans_history', JSON.stringify(updatedLogs));
  };

  // Reset entire history log
  const handleClearAllLogs = () => {
    if (window.confirm("Apakah Anda yakin ingin menghapus semua history? Poin Anda yang tersimpan di log aktif akan disetel ulang.")) {
      setLogs([]);
      localStorage.setItem('eco_scans_history', JSON.stringify([]));
    }
  };

  // Add points to wallet persistent
  const handleAwardPoints = (gainedPoints: number) => {
    setPoints((prevPoints) => {
      const updatedPoints = prevPoints + gainedPoints;
      localStorage.setItem('eco_points', String(updatedPoints));
      
      const oldLevel = getLevelInfo(prevPoints);
      const newLevel = getLevelInfo(updatedPoints);
      
      if (newLevel.id > oldLevel.id) {
        setLevelUpData({
          show: true,
          oldLevel,
          newLevel
        });
      }
      return updatedPoints;
    });
  };

  const renderActivePage = () => {
    switch (currentPage) {
      case 'scan':
        return (
          <ScanPage 
            onAddLog={handleAddLog} 
            onAwardPoints={handleAwardPoints} 
          />
        );
      case 'guide':
        return <GuidePage />;
      case 'facts':
        return <FactsPage />;
      case 'quiz':
        return <QuizPage onAwardPoints={handleAwardPoints} />;
      case 'log':
        return (
          <LogPage 
            logs={logs} 
            onDeleteLog={handleDeleteLog} 
            onClearAllLogs={handleClearAllLogs} 
            points={points}
          />
        );
      default:
        return (
          <ScanPage 
            onAddLog={handleAddLog} 
            onAwardPoints={handleAwardPoints} 
          />
        );
    }
  };

  return (
    <>
      <AnimatePresence mode="wait">
        {isSplashActive && (
          <SplashScreen onComplete={() => setIsSplashActive(false)} />
        )}
      </AnimatePresence>

      {/* Real-time Level Up Celebration Modal */}
      {levelUpData.show && levelUpData.oldLevel && levelUpData.newLevel && (
        <LevelUpPopup
          show={levelUpData.show}
          oldLevel={levelUpData.oldLevel}
          newLevel={levelUpData.newLevel}
          onClose={() => setLevelUpData(prev => ({ ...prev, show: false }))}
        />
      )}

      <div className="min-h-screen bg-[#F8FAFC] text-slate-850 font-sans flex flex-col relative z-0 selection:bg-[#FF8FA3]/30 selection:text-red-950">
      
      {/* Persisted Header Navigation bar */}
      <Header 
        currentPage={currentPage} 
        setCurrentPage={setCurrentPage} 
        points={points} 
      />

      {/* Primary Application Pages container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-0 sm:px-2 md:px-4 pb-12 relative z-10">
        {renderActivePage()}
      </main>

      {/* Small design signature footer representing premium humble craft */}
      <footer className="py-6 border-t border-slate-100 bg-white/50 backdrop-blur-sm text-center text-xs text-slate-500 tracking-wide relative z-20">
        <p className="flex items-center justify-center space-x-1.5">
          <span>EcoScan - Panduan Daur Ulang Pintar</span>
          <span className="opacity-50">|</span>
          <span>Inisiatif Keberlanjutan Pemuda Indonesia</span>
        </p>
      </footer>
    </div>
  </>
  );
}
