export interface EcoLevel {
  id: number;
  name: string;
  emoji: string;
  minPoints: number;
  maxPoints: number;
  description: string;
  badgeColor: string; // Tailwind class
  accentColor: string; // Hex color for layout/borders
  gradient: string; // Tailwind gradient
  longDescription: string;
}

export const ECO_LEVELS: EcoLevel[] = [
  {
    id: 1,
    name: "Eco Pemula",
    emoji: "🌱",
    minPoints: 0,
    maxPoints: 100,
    description: "Pendekar lingkungan pemula yang baru memulai langkah daur ulang.",
    badgeColor: "bg-emerald-50 text-emerald-800 border-emerald-350",
    accentColor: "#10B981",
    gradient: "from-emerald-100 to-green-100",
    longDescription: "Selamat bergabung di aksi pelestarian! Sebagai Eco Pemula, Anda telah menunjukkan kepedulian awal terhadap bumi dengan mempelajari dasar-dasar pemilahan sampah."
  },
  {
    id: 2,
    name: "Eco Pejuang",
    emoji: "🌿",
    minPoints: 101,
    maxPoints: 300,
    description: "Mulai konsisten memisahkan sampah dan menggerakkan perubahan kecil.",
    badgeColor: "bg-lime-50 text-lime-800 border-lime-350",
    accentColor: "#84CC16",
    gradient: "from-lime-100 to-emerald-100",
    longDescription: "Aksi Anda mulai berakar! Sebagai Eco Pejuang, Anda secara konsisten menyortir sampah demi kelangsungan bumi kita yang berharga."
  },
  {
    id: 3,
    name: "Eco Hero",
    emoji: "🌳",
    minPoints: 301,
    maxPoints: 500,
    description: "Inspirator penjaga kebersihan bumi dengan dampak daur ulang yang nyata.",
    badgeColor: "bg-green-150 text-emerald-950 border-green-300",
    accentColor: "#22C55E",
    gradient: "from-green-100 to-teal-100",
    longDescription: "Dampak nyata! Anda adalah pahlawan lingkungan (Eco Hero) sejati yang terus menginspirasi sekitar melalui log pemilahan yang luar biasa."
  },
  {
    id: 4,
    name: "Eco Legend",
    emoji: "🌍",
    minPoints: 501,
    maxPoints: 1000,
    description: "Pejuang legendaris yang mengorbankan waktu demi bumi bebas tumpukan plastik.",
    badgeColor: "bg-teal-50 text-teal-900 border-teal-300",
    accentColor: "#14B8A6",
    gradient: "from-teal-100 to-sky-100",
    longDescription: "Luar biasa, tingkat Legenda! Kontribusi daur ulang Anda telah menyelamatkan ratusan gram material berharga dari kepunahan ekosistem."
  },
  {
    id: 5,
    name: "Eco Master",
    emoji: "⭐",
    minPoints: 1001,
    maxPoints: 999999,
    description: "Guru besar ekologi yang menyandang gelar bintang utama kelestarian.",
    badgeColor: "bg-amber-50 text-amber-950 border-amber-300",
    accentColor: "#F59E0B",
    gradient: "from-amber-100 to-rose-100",
    longDescription: "Gelar tertinggi di EcoScan! Anda adalah master sejati, pelindung ekosistem bumi tercinta yang menjadi panutan tertinggi kelestarian global."
  }
];

// Returns the active level info for any given points amount
export function getLevelInfo(points: number): EcoLevel {
  const level = ECO_LEVELS.find(lvl => points >= lvl.minPoints && points <= lvl.maxPoints);
  return level || ECO_LEVELS[0];
}

// Returns the next level info
export function getNextLevelInfo(points: number): EcoLevel | null {
  const currentLvl = getLevelInfo(points);
  const nextLvl = ECO_LEVELS.find(lvl => lvl.id === currentLvl.id + 1);
  return nextLvl || null;
}

// Calculates percentage completed towards the next level
export function getPercentageToNextLevel(points: number): number {
  const currentLvl = getLevelInfo(points);
  const nextLvl = getNextLevelInfo(points);
  if (!nextLvl) return 100; // Already max level

  const range = nextLvl.minPoints - currentLvl.minPoints;
  const progress = points - currentLvl.minPoints;
  return Math.max(0, Math.min(100, (progress / range) * 100));
}
