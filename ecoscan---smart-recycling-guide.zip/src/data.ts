import { WasteCategoryDetail, EcoFact, QuizQuestion } from './types';

export const WASTE_CATEGORIES: WasteCategoryDetail[] = [
  {
    id: 'organic',
    name: 'Sampah Organik',
    nameIndonesian: 'Sampah Organik',
    iconName: 'Leaf',
    description: 'Bahan ramah lingkungan yang mudah terurai dan berasal dari makhluk hidup. Bahan ini dapat membusuk secara alami dan diolah menjadi pupuk kompos yang kaya nutrisi.',
    descriptionIndonesian: 'Sampah yang berasal dari makhluk hidup, mudah membusuk secara alami, dan dapat diolah menjadi kompos berkualitas tinggi.',
    dos: [
      'Pisahkan sisa makanan, kulit buah, dan sisa sayuran.',
      'Masukkan daun kering, potongan rumput, dan ampas kopi.',
      'Cincang potongan besar untuk mempercepat proses pembuatan kompos.'
    ],
    donts: [
      'Jangan campur dengan bungkus plastik, stiker, atau kawat pengikat logam.',
      'Hindari memasukkan tanaman yang sakit atau kotoran hewan ke dalam kompos rumah tangga.',
      'Jangan masukkan produk susu, daging, atau minyak (dapat menarik hama dan menimbulkan bau pada kompos biasa).'
    ],
    upcyclingIdeas: [
      'Ubah sisa dapur menjadi Kompos Kaya Nutrisi untuk tanaman Anda.',
      'Buat Eco-Enzyme (pembersih alami serbaguna) dari kulit buah dan gula merah.',
      'Buat pewarna alami menggunakan kulit bawang, bit, atau parutan kunyit.'
    ],
    bgGradient: 'from-[#E8F8E8] to-[#D0F0C0]',
    accentColor: '#A8DF8E',
    textColor: 'text-green-800'
  },
  {
    id: 'plastic',
    name: 'Sampah Plastik',
    nameIndonesian: 'Sampah Plastik',
    iconName: 'Sparkles',
    description: 'Polimer sintetis yang sangat tahan lama tetapi dapat mencemari ekosistem selama berabad-abad jika tidak dikelola. Sangat penting untuk mengidentifikasi kode daur ulang (PET 1, HDPE 2, dsb).',
    descriptionIndonesian: 'Polimer sintetis yang sangat tahan lama namun sulit terurai. Sangat penting mengenali kode daur ulang (PET 1, HDPE 2, dsb).',
    dos: [
      'Selalu bilas botol dan wadah untuk menghilangkan sisa makanan/minuman.',
      'Lepaskan tutup botol plastik dan pipihkan botol untuk menghemat ruang penyimpanan.',
      'Periksa kode angka daur ulang segitiga di bagian bawah wadah.'
    ],
    donts: [
      'Jangan daur ulang plastik yang sangat kotor atau bungkus plastik tipis yang berminyak.',
      'Hindari mencampur plastik ramah lingkungan sekali pakai (PLA) dengan plastik konvensional.',
      'Jangan pernah membakar sampah plastik karena melepas dioksin beracun ke udara.'
    ],
    upcyclingIdeas: [
      'Ubah botol PET transparan menjadi pot gantung mandiri untuk tanaman herbal kecil.',
      'Buat ecobrick yang tahan lama dengan memadatkan bungkus plastik lembut yang bersih dan kering ke dalam botol.',
      'Kreasikan tutup botol yang kokoh menjadi alas gelas indah atau dekorasi seni mosaik warna-warni.'
    ],
    bgGradient: 'from-[#FFD6DC] to-[#FFB7B2]',
    accentColor: '#FF8FA3',
    textColor: 'text-red-800'
  },
  {
    id: 'paper',
    name: 'Sampah Kertas',
    nameIndonesian: 'Sampah Kertas',
    iconName: 'BookOpen',
    description: 'Produk berbahan dasar selulosa yang dapat dihancurkan kembali menjadi bubur kertas dan didaur ulang berkali-kali, menghemat kelestarian hutan dan sumber daya air.',
    descriptionIndonesian: 'Produk berbahan dasar selulosa yang dapat dihancurkan menjadi bubur kertas untuk didaur ulang kembali, menyelamatkan hutan.',
    dos: [
      'Jaga kertas tetap kering dan rata. Serat basah kehilangan kekuatan dan tidak dapat didaur ulang.',
      'Pipihkan kotak kardus sepenuhnya untuk memaksimalkan efisiensi tempat sampah.',
      'Lepaskan selotip plastik, staples logam tebal, dan amplop gelembung plastik.'
    ],
    donts: [
      'Jangan daur ulang kotak pizza yang berminyak, bungkus makanan, atau kotak kue kering yang berminyak.',
      'Jangan membuang struk belanja (kertas termal mengandung bahan kimia BPA/BPS dan termasuk sampah umum).',
      'Jangan daur ulang karton minuman berlapis lilin atau plastik di tempat sampah kertas biasa.'
    ],
    upcyclingIdeas: [
      'Hancurkan kertas bekas untuk membuat kartu ucapan DIY ramah lingkungan yang berisi benih tanaman.',
      'Gulung pita koran dengan kencang untuk menenun keranjang penyimpanan atau tempat pena yang ramah lingkungan.',
      'Komposkan kardus murni yang dihancurkan dan wadah telur sebagai unsur karbon (elemen cokelat) untuk tanah.'
    ],
    bgGradient: 'from-[#FFF9E6] to-[#FFEAA7]',
    accentColor: '#FDCB6E',
    textColor: 'text-amber-800'
  },
  {
    id: 'metal',
    name: 'Sampah Logam',
    nameIndonesian: 'Sampah Logam',
    iconName: 'ShieldAlert',
    description: 'Mineral berharga seperti aluminium, besi, dan kaleng baja yang dapat didaur ulang tanpa batas tanpa mengurangi kekuatan atau kualitas fisiknya.',
    descriptionIndonesian: 'Mineral berharga (aluminium, baja, kaleng) yang bisa didaur ulang terus-menerus tanpa mengurangi kualitas fisiknya.',
    dos: [
      'Kosongkan dan bilas kaleng makanan baja dan kaleng minuman hingga bersih.',
      'Remas aluminium foil yang bersih menjadi bola padat agar tidak beterbangan.',
      'Biarkan tutup kaleng logam tetap menempel atau masukkan ke dalam kaleng agar pinggiran tajam tidak melukai petugas.'
    ],
    donts: [
      'Jangan daur ulang kaleng logam yang masih berisi cairan atau aerosol bertekanan.',
      'Hindari membuang bagian logam yang memiliki residu baterai atau komponen kabel.',
      'Jangan mengecat atau mewarnai kaleng logam sebelum dikirim ke pengumpul bank sampah.'
    ],
    upcyclingIdeas: [
      'Bersihkan kaleng minuman dan ubah menjadi pot tanaman herbal retro atau organizer meja.',
      'Bungkus kaleng timah dengan tali rami rustic atau cat untuk menjadikannya tempat lilin vintage.',
      'Simpan berbagai sekrup kecil, paku, atau jarum jahit dengan rapi di dalam wadah kaleng yang diberi label.'
    ],
    bgGradient: 'from-[#E1F5FE] to-[#B3E5FC]',
    accentColor: '#29B6F6',
    textColor: 'text-sky-800'
  },
  {
    id: 'glass',
    name: 'Sampah Kaca',
    nameIndonesian: 'Sampah Kaca',
    iconName: 'GlassWater',
    description: 'Wadah kaca (botol kaca, stoples saus) dapat didaur ulang 100%. Kaca tidak kehilangan mutunya selama daur ulang, tetapi perlu dipisahkan dengan aman.',
    descriptionIndonesian: 'Wadah kaca (botol, toples) dapat didaur ulang 100%. Kaca tidak kehilangan kualitasnya namun membutuhkan penyortiran yang aman.',
    dos: [
      'Bilas semua sisa kotoran dan buang segel plastik serta tutup logam luar.',
      'Pisahkan barang kaca berdasarkan warna (transparan/cokelat/hijau) jika diminta oleh mitra daur ulang lokal Anda.',
      'Bungkus potongan kaca pecah dengan koran secara hati-hati dan beri label yang jelas untuk melindungi petugas kebersihan.'
    ],
    donts: [
      'Jangan pernah mencampur peralatan masak pyrex, kaca tahan panas, gelas minum, kaca jendela, atau cermin dengan kaca botol.',
      'Jangan memasukkan bola lampu atau tabung kaca medis ke dalam daur ulang kaca rumah tangga.'
    ],
    upcyclingIdeas: [
      'Cuci stoples kaca yang indah untuk digunakan kembali sebagai wadah makanan estetik atau rak bumbu kering.',
      'Tambahkan air dan nutrisi tanaman cair ke botol kaca untuk memperbanyak tanaman (hidroponik).',
      'Cat botol saus/sirup yang lebih besar menjadi vas bunga artistik modern.'
    ],
    bgGradient: 'from-[#F3E5F5] to-[#E1BEE7]',
    accentColor: '#AB47BC',
    textColor: 'text-purple-800'
  },
  {
    id: 'B3',
    name: 'Limbah B3',
    nameIndonesian: 'Limbah B3',
    iconName: 'Skull',
    description: 'Bahan Berbahaya dan Beracun. Meliputi zat beracun, reaktif, mudah terbakar, atau korosif seperti baterai bekas, limbah elektronik, kaleng semprot, dan limbah medis.',
    descriptionIndonesian: 'Bahan Berbahaya dan Beracun. Meliputi zat beracun, reaktif, mudah terbakar, atau korosif seperti baterai bekas, e-waste, kaleng aerosol, dan limbah medis.',
    dos: [
      'Simpan baterai isi ulang/alkalin di wadah kering yang aman dan serahkan ke kotak e-waste resmi.',
      'Simpan obat-obatan yang tidak terpakai dalam kemasan aslinya, coret informasi pasien, dan konsultasikan ke apotek aktif.',
      'Buang limbah elektronik (charger rusak, earphone, ponsel lama) di Dropbox pemerintah yang ditunjuk.'
    ],
    donts: [
      'JANGAN PERNAH membuang baterai, bahan kimia, atau barang elektronik ke tempat sampah organik/plastik rumah tangga biasa.',
      'Jangan membuang cairan pelarut, oli mobil, atau bahan kimia ke saluran pembuangan air atau wastafel.',
      'Jangan membakar kaleng semprotan aerosol (karena akan meledak) atau melubangi baterai isi ulang bekas.'
    ],
    upcyclingIdeas: [
      'Daur ulang mandiri limbah elektronik sangat terbatas demi alasan keamanan; namun pembuat profesional melepas suku cadang fungsional (LED, kabel tembaga) dari perangkat yang rusak.',
      'Teknologi retro yang tidak dapat digunakan seperti kaset lama, casing video game, atau disket dapat disusun menjadi kolase seni yang keren dan bernostalgia.',
      'Untuk barang-barang berat, selalu kirimkan langsung ke layanan ekosistem sampah terdaftar (seperti E-Waste RJ atau pos dropbox Dinas Lingkungan Hidup).'
    ],
    bgGradient: 'from-[#FFEBEE] to-[#FFCDD2]',
    accentColor: '#EF5350',
    textColor: 'text-red-900'
  }
];

export const ECO_FACTS: EcoFact[] = [
  {
    id: 1,
    emoji: '🌊',
    title: 'Plastik di Lautan Indonesia',
    fact: 'Indonesia menghasilkan sekitar 6,8 juta ton sampah plastik setahun, dengan estimasi 620.000 ton di antaranya mencemari ekosistem laut.',
    factIndonesian: 'Indonesia menghasilkan sekitar 6,8 juta ton sampah plastik setahun, dengan estimasi 620.000 ton di antaranya mencemari ekosistem laut.'
  },
  {
    id: 2,
    emoji: '🏔️',
    title: 'Gunung Sampah Bantar Gebang',
    fact: 'TPST Bantar Gebang memiliki luas 110 hektar dengan ketinggian gunungan sampah melebihi 40 meter, menampung hingga 7.500 ton sampah per hari.',
    factIndonesian: 'TPST Bantar Gebang memiliki luas 110 hektar dengan ketinggian gunungan sampah melebihi 40 meter, menampung hingga 7.500 ton sampah per hari.'
  },
  {
    id: 3,
    emoji: '🏦',
    title: 'Bank Sampah (Sistem Tabungan)',
    fact: 'Indonesia memiliki lebih dari 11.000 Bank Sampah. Warga mendepositkan sampah kering yang sudah dipilah untuk ditukar uang atau tabungan investasi emas!',
    factIndonesian: 'Indonesia memiliki lebih dari 11.000 Bank Sampah. Warga mendepositkan sampah kering yang sudah dipilah untuk ditukar uang atau tabungan emas!'
  },
  {
    id: 4,
    emoji: '☕',
    title: 'Upcycling Sabut Kelapa & Kopi',
    fact: 'Indonesia memimpin inovasi upcycling sabut kelapa dan kulit kopi, mengubahnya menjadi peralatan dapur organik dan briket ramah lingkungan.',
    factIndonesian: 'Indonesia memimpin inovasi upcycling sabut kelapa dan kulit kopi, mengubahnya menjadi peralatan dapur organik dan briket ramah lingkungan.'
  },
  {
    id: 5,
    emoji: '🥬',
    title: 'Dampak Gas Metana',
    fact: 'Lebih dari 55% sampah di Indonesia adalah sampah dapur organik. Jika tertimbun tanpa udara di TPA, sampah ini menghasilkan gas metana yang merusak atmosfer.',
    factIndonesian: 'Lebih dari 55% sampah di Indonesia adalah sampah dapur organik. Jika tertimbun tanpa udara di TPA, sampah ini menghasilkan gas metana.'
  },
  {
    id: 6,
    emoji: '🛍️',
    title: 'Larangan Plastik Sekali Pakai',
    fact: 'Kota-kota besar seperti Jakarta, Bali, Bogor, dan Bandung secara resmi melarang penyediaan kantong plastik sekali pakai di ritel modern dan pusat perbelanjaan.',
    factIndonesian: 'Kota-kota besar seperti Jakarta, Bali, Bogor, dan Bandung secara resmi melarang penyediaan kantong plastik sekali pakai di ritel modern.'
  },
  {
    id: 7,
    emoji: '🌳',
    title: 'Dampak Hebat Daur Ulang Kertas',
    fact: 'Daur ulang 1 ton kertas kantor dapat menyelamatkan sekitar 17 pohon, 26.500 liter air bersih, dan pasokan listrik rumah tangga rata-rata selama 6 bulan.',
    factIndonesian: 'Daur ulang 1 ton kertas kantor dapat menyelamatkan sekitar 17 pohon, 26.500 liter air bersih, dan listrik rumah tangga selama 6 bulan.'
  },
  {
    id: 8,
    emoji: '🚧',
    title: 'Penyaring Sampah Sungai Watch',
    fact: 'Komunitas pemuda di Bali dan Jawa memasang jaring logam di sungai, menahan ribuan kilogram plastik agar tidak sampai mengalir mencemari samudra.',
    factIndonesian: 'Komunitas pemuda di Bali dan Jawa memasang jaring logam di sungai, menahan ribuan kilogram plastik agar tidak sampai mengalir ke samudra.'
  },
  {
    id: 9,
    emoji: '🏺',
    title: 'Daur Ulang Kaca Tanpa Batas',
    fact: 'Berbeda dengan plastik yang kualitasnya menurun setiap kali didaur ulang, wadah kaca dapat dilebur ulang secara terus-menerus tanpa batas.',
    factIndonesian: 'Berbeda dengan plastik yang kualitasnya menurun setiap didaur ulang, kaca dapat dilebur ulang tanpa batas secara terus-menerus.'
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'Bahan Berbahaya dan Beracun direpresentasikan sebagai B3. Manakah barang rumah tangga berikut yang termasuk kategori limbah B3?',
    options: [
      'Cangkang telur, potongan sayuran, dan ampas kopi',
      'Baterai bekas, kabel charger rusak, dan kaleng semprotan aerosol',
      'Kardus pembungkus paket dan koran bekas',
      'Pecahan stoples kaca dan gelas kristal minum'
    ],
    correctAnswer: 1,
    explanation: 'Baterai bekas, limbah elektronik (charger, lampu), dan kaleng semprotan aerosol bersifat sangat beracun, reaktif, atau mudah terbakar, sehingga dikelompokkan ke dalam Limbah B3.'
  },
  {
    id: 2,
    question: 'Bagaimana cara Bank Sampah menarik minat masyarakat Indonesia untuk terus mendaur ulang sampah kering terpilah?',
    options: [
      'Dengan menawarkan tarif tol gratis di seluruh tol nasional',
      'Warga dapat menukar unit sampah kering yang bersih dengan saldo uang, pulsa listrik, atau tabungan investasi emas',
      'Dengan membagikan medali penghargaan yang ditandatangani ketua RW setempat',
      'Dengan mendistribusikan sayuran segar secara cuma-cuma'
    ],
    correctAnswer: 1,
    explanation: 'Bank Sampah membayar warga untuk sampah kering terpilah. Layanan ini bahkan bermitra dengan Pegadaian untuk mengonversi saldo sampah menjadi tabungan emas!'
  },
  {
    id: 3,
    question: 'Rata-rata, berapa lama waktu yang dibutuhkan sebuah botol minum plastik PET sekali pakai untuk hancur atau terurai di TPA?',
    options: [
      'Sekitar 10 sampai 20 tahun',
      'Sekitar 100 tahun',
      'Sekitar 450 tahun',
      'Sekitar 10.000 tahun'
    ],
    correctAnswer: 2,
    explanation: 'Plastik PET tidak dapat terurai secara biologis, melainkan terpecah menjadi mikroplastik yang sangat kecil. Proses ini memakan waktu sekitar 450 tahun di lingkungan TPA.'
  },
  {
    id: 4,
    question: 'Langkah paling krusial apa yang wajib dilakukan SEBELUM memasukkan wadah plastik atau kotak jus ke tempat pembuangan daur ulang?',
    options: [
      'Mengecatnya terlebih dahulu dengan cat hijau ramah lingkungan',
      'Membilas sisa cairan/susu di dalamnya dan mengeringkannya agar tidak menimbulkan jamur atau bau busuk',
      'Memotong-motongnya menjadi serpihan kecil menggunakan gunting rumah',
      'Menuliskan tautan akun Instagram favorit di permukaan luar wadah'
    ],
    correctAnswer: 1,
    explanation: 'Sisa makanan/minuman yang kotor dapat mengotori barang kering lain (terutama kertas), membuat satu wadah sampah membusuk dan gagal didaur ulang. Selalu tiriskan, bilas, dan pipihkan dahulu!'
  },
  {
    id: 5,
    question: 'Mengapa membungkus tumpukan sisa makanan dapur di dalam bungkus plastik rapat di dasar wadah TPA sangat tidak dianjurkan?',
    options: [
      'Karena dapat memicu hantaran listrik statis yang berbahaya jika terkena petir',
      'Proses pembusukan tanpa udara (anaerob) oleh bakteri melepas gas metana—gas rumah kaca yang jauh lebih kuat dari karbon dioksida',
      'Karena membuat sisa makanan membatu sekeras fondasi beton cor',
      'Karena dapat memicu turunnya salju es secara tiba-tiba di daerah khatulistiwa'
    ],
    correctAnswer: 1,
    explanation: 'Sampah organik membutuhkan paparan oksigen agar terurai menjadi kompos yang bersih. Pembusukan anaerobik di dalam timbunan sampah yang rapat melepaskan gas metana berbahaya!'
  }
];
