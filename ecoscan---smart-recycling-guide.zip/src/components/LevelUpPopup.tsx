import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Trophy, ArrowRight, X, Heart } from 'lucide-react';
import { EcoLevel } from '../utils/level';

interface LevelUpPopupProps {
  show: boolean;
  oldLevel: EcoLevel;
  newLevel: EcoLevel;
  onClose: () => void;
}

// Particle interface for our customized native eco confetti
interface ConfettiParticle {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
  emoji: string;
  delay: number;
  duration: number;
  spin: number;
}

export default function LevelUpPopup({ show, oldLevel, newLevel, onClose }: LevelUpPopupProps) {
  const [particles, setParticles] = useState<ConfettiParticle[]>([]);

  // Generate customized cute eco confetti when popup is showing
  useEffect(() => {
    if (show) {
      const colors = ['#A8DF8E', '#FF8FA3', '#73EC8B', '#FACC15', '#FFD6DC', '#3B82F6'];
      const emojis = ['✦', '★', '●', '✦', '◆', '✶'];
      const newParticles = Array.from({ length: 45 }).map((_, idx) => ({
        id: idx,
        x: Math.random() * 92 + 4, // scattered across screen width (percentage)
        y: -15, // start above screen
        size: Math.random() * 15 + 12, // random screen sizes
        color: colors[idx % colors.length],
        emoji: emojis[idx % emojis.length],
        delay: Math.random() * 1.5,
        duration: Math.random() * 2.5 + 2.0, // fall duration 2-4.5s
        spin: Math.random() * 360 - 180 // rotation
      }));
      setParticles(newParticles);
    } else {
      setParticles([]);
    }
  }, [show]);

  return (
    <AnimatePresence>
      {show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          
          {/* Backdrop blur overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-[#1E3A1E]/40 backdrop-blur-md z-40 cursor-pointer"
            id="levelup-backdrop"
          />

          {/* Eco confetti particles container */}
          <div className="absolute inset-0 pointer-events-none z-[42] overflow-hidden">
            {particles.map((p) => (
              <motion.div
                key={p.id}
                initial={{ y: -50, x: `${p.x}vw`, opacity: 0, scale: 0.1, rotate: 0 }}
                animate={{
                  y: '110vh',
                  x: [`${p.x}vw`, `${p.x + (Math.random() * 20 - 10)}vw`],
                  opacity: [0, 1, 1, 0.4, 0],
                  scale: [0.6, 1.2, 1, 0.8],
                  rotate: [0, p.spin]
                }}
                transition={{
                  duration: p.duration,
                  delay: p.delay,
                  ease: "easeOut",
                  repeat: 0
                }}
                className="absolute flex items-center justify-center select-none"
                style={{ fontSize: `${p.size}px` }}
              >
                {p.emoji}
              </motion.div>
            ))}
          </div>

          {/* Main Level Up Reward Card */}
          <motion.div
            initial={{ scale: 0.85, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 15 }}
            transition={{ type: "spring", stiffness: 180, damping: 18 }}
            className="w-full max-w-md bg-[#FFF] rounded-[2.5rem] border-4 border-emerald-450 p-6 shadow-2xl relative overflow-hidden z-[45] outline outline-8 outline-[#C5E8C5]"
            id="levelup-card-container"
          >
            {/* Top right close trigger */}
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 rounded-full transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Glowing yellow accent background */}
            <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-[#A8DF8E]/40 to-transparent -z-10" />

            {/* Title / Celebration Header */}
            <div className="text-center space-y-2 mt-4">
              <motion.div
                initial={{ scale: 0.5, rotate: -20 }}
                animate={{ scale: [1, 1.2, 1], rotate: [0, 15, -15, 0] }}
                transition={{ delay: 0.2, duration: 0.8 }}
                className="inline-flex items-center justify-center p-4 bg-gradient-to-tr from-yellow-300 to-amber-400 text-amber-950 rounded-3xl shadow-lg border-2 border-amber-500 mb-2 rotate-12"
              >
                <Trophy className="w-10 h-10 filter drop-shadow" />
              </motion.div>
              
              <p className="text-[#FF8FA3] font-mono text-xs font-black uppercase tracking-widest">
                PRESTASI HEBAT TERKLAIM!
              </p>
              
              <h2 className="font-serif italic text-3xl sm:text-4xl font-extrabold text-green-950 leading-tight">
                Selamat! <br />Level Anda <span className="text-emerald-700 font-sans not-italic">Naik</span>
              </h2>
            </div>

            {/* Progression Comparison section */}
            <div className="my-8 bg-slate-50/90 rounded-2xl border-2 border-dashed border-green-200 p-5 flex items-center justify-around relative">
              
              {/* Old Level Element */}
              <div className="text-center space-y-1">
                <span className="flex items-center justify-center h-10 w-10 mx-auto text-slate-400">
                  <Trophy className="w-8 h-8" />
                </span>
                <span className="block text-xs font-mono font-bold text-slate-500 uppercase tracking-tight">Level Sebelumnya</span>
                <span className="block text-sm font-extrabold text-slate-600">
                  {oldLevel.name}
                </span>
              </div>

              {/* Arrow transition container */}
              <motion.div
                animate={{ x: [-3, 3, -3] }}
                transition={{ repeat: Infinity, duration: 1.4, ease: "easeInOut" }}
                className="flex flex-col items-center justify-center"
              >
                <ArrowRight className="w-6 h-6 text-emerald-600" />
                <span className="text-[9px] uppercase font-mono font-black text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded-full mt-1">UP</span>
              </motion.div>

              {/* New Level Element */}
              <div className="text-center space-y-1 relative">
                <div className="absolute -top-4 -right-4 -z-10 text-xl text-yellow-500 animate-spin-slow opacity-60">
                  <Sparkles className="w-5 h-5 text-yellow-500" />
                </div>
                
                <motion.span 
                  animate={{ scale: [1, 1.25, 1] }}
                  transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                  className="flex items-center justify-center h-12 w-12 mx-auto text-yellow-500 filter drop-shadow-md"
                >
                  <Trophy className="w-10 h-10" />
                </motion.span>
                <span className="block text-xs font-mono font-black text-emerald-600 uppercase tracking-tight">Level Baru</span>
                <span className="block text-base font-black text-emerald-800 drop-shadow-sm">
                  {newLevel.name}
                </span>
              </div>

            </div>

            {/* Celebration details descriptions */}
            <div className="space-y-4 text-center px-2">
              <p className="text-xs sm:text-sm font-bold text-green-950 bg-emerald-50 py-3 px-4 rounded-xl border border-emerald-100 italic leading-relaxed">
                {newLevel.longDescription}
              </p>
              
              <div className="flex justify-center items-center space-x-1.5 text-[11px] font-mono font-extrabold text-emerald-900/70">
                <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
                <span>Poin minimal terlampaui: {newLevel.minPoints} POIN</span>
              </div>
            </div>

            {/* CTA action trigger button */}
            <div className="mt-8">
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={onClose}
                className="w-full py-4 bg-gradient-to-r from-[#2D6A2D] to-emerald-700 text-white font-bold text-sm tracking-wide rounded-2xl shadow-md hover:shadow-lg hover:from-emerald-700 hover:to-[#2D6A2D] border-b-4 border-emerald-900 transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <span>Lanjutkan Perjuangan Hijau!</span>
                <Heart className="w-4 h-4 fill-white text-white animate-pulse" />
              </motion.button>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
