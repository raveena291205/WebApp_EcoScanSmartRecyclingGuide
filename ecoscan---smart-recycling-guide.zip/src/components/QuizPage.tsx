import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Award, CheckCircle, XCircle, ChevronRight, HelpCircle, 
  RotateCw, Play, Trophy, Sparkles, Coins, Info 
} from 'lucide-react';
import { QUIZ_QUESTIONS } from '../data';

interface QuizPageProps {
  onAwardPoints: (points: number) => void;
}

export default function QuizPage({ onAwardPoints }: QuizPageProps) {
  const [showBubble, setShowBubble] = useState(true);
  const [showPensiBubble, setShowPensiBubble] = useState(true);
  const [showKuizBubble, setShowKuizBubble] = useState(true);
  const [gameState, setGameState] = useState<'welcome' | 'playing' | 'scoring'>('welcome');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAns, setSelectedAns] = useState<number | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [hasAwardedInThisRun, setHasAwardedInThisRun] = useState(false);

  const currentQuestion = QUIZ_QUESTIONS[currentIdx];

  // Pick Option
  const handleSelectOption = (optIndex: number) => {
    if (selectedAns !== null) return; // locked
    setSelectedAns(optIndex);
    if (optIndex === currentQuestion.correctAnswer) {
      setQuizScore((prev) => prev + 1);
    }
  };

  // Skip or Next Question
  const handleNextQuestion = () => {
    setSelectedAns(null);
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      setGameState('scoring');
    }
  };

  // Done Claim Points
  const handleFinishAndClaim = () => {
    if (!hasAwardedInThisRun) {
      // Award 20 points per correct answer
      const pointsToEarn = quizScore * 20;
      onAwardPoints(pointsToEarn);
      setHasAwardedInThisRun(true);
    }
  };

  // Reset/Restart Quiz
  const handleResetQuiz = () => {
    setCurrentIdx(0);
    setSelectedAns(null);
    setQuizScore(0);
    setHasAwardedInThisRun(false);
    setGameState('playing');
  };

  // Get score rankings evaluation
  const getRankAssessment = () => {
    const ratio = quizScore / QUIZ_QUESTIONS.length;
    if (ratio === 1) {
      return { 
        title: 'Pahlawan Lingkungan (Pahlawan Hijau)', 
        desc: 'Sempurna! Anda memiliki pemahaman mendalam tentang manajemen sampah dan pemilahan di Indonesia. Anda siap menjadi panutan dan pelopor pelestarian lingkungan di lingkungan sekitar Anda.', 
        color: 'text-emerald-800 bg-emerald-50 border-emerald-200' 
      };
    }
    if (ratio >= 0.6) {
      return { 
        title: 'Cendekiawan Pendukung (Kadet Hijau)', 
        desc: 'Skor luar biasa! Anda sudah memahami dasar klasifikasi sampah dan proses daur ulang kreatif. Cukup sedikit penajaman lagi untuk mencapai skor sempurna!', 
        color: 'text-green-800 bg-green-50 border-green-200' 
      };
    }
    return { 
      title: 'Pemula Lestari (Magang Mandiri)', 
      desc: 'Upaya yang bagus! Upaya pelestarian bumi adalah proses belajar berkelanjutan secara bertahap. Pelajari Panduan Daur Ulang kami untuk menyempurnakan pemahaman Anda.', 
      color: 'text-amber-800 bg-amber-50 border-amber-200' 
    };
  };

  return (
    <div className="w-full relative min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8 flex items-center justify-center overflow-hidden bg-[#FFF0F3]" id="quiz-page-root">
      
      {/* Decorative Blob Shapes */}
      <div className="absolute top-10 left-10 w-64 h-64 bg-[#A8DF8E]/25 rounded-full blur-3xl -z-10 animate-float-slow" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-[#FFD6DC]/35 rounded-full blur-3xl -z-10 animate-float-reverse" />

      <div className="w-full max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          
          {/* Welcome Screen */}
          {gameState === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-[2rem] border border-[#E0F0D8] p-6 sm:p-10 shadow-xl text-center space-y-6 max-w-xl mx-auto"
            >
              <div className="relative inline-block">
                <div className="p-5 rounded-3xl bg-gradient-to-tr from-[#A8DF8E] to-[#FF8FA3] text-white shadow-md">
                  <Award className="h-10 w-10 animate-bounce" />
                </div>
                <div className="absolute -top-1 -right-1 bg-yellow-400 p-1 rounded-full text-white">
                  <Sparkles className="h-3.5 w-3.5" />
                </div>
              </div>

              {/* Responsive Dual Mascot Header */}
              <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-20 w-full mb-2">
                
                {/* Left Mascot (Pensi the Pencil) - Hidden on mobile, shown on desktop sides */}
                <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[140px] shrink-0">
                  <div className="relative cursor-pointer group" onClick={() => setShowPensiBubble(prev => !prev)} title="Ketuk saya!">
                    {/* Speech bubble */}
                    <AnimatePresence mode="wait">
                      {showPensiBubble && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8, y: 15 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.8, y: -5 }}
                          transition={{ type: "spring", stiffness: 300, damping: 20 }}
                          className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-3 py-1.5 rounded-2xl text-[11px] shadow-sm border border-[#A8DF8E]/40 w-40 text-center z-20 hover:scale-103 transition-all duration-200"
                        >
                          <p className="leading-snug text-green-950 font-semibold">Siap kuis?</p>
                          <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Pensi SVG wrapper */}
                    <div className="relative mt-10 text-center">
                      <div className="absolute inset-0 bg-[#A8DF8E]/20 rounded-full blur-xl group-hover:bg-[#FFD6DC]/20 transition-colors duration-300 -z-10" />
                      <motion.div
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Infinity, duration: 2.1, ease: "easeInOut" }}
                      >
                        <svg viewBox="0 0 100 100" className="w-16 h-16 sm:w-20 sm:h-20 mx-auto filter drop-shadow-sm select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                          {/* Eraser */}
                          <path d="M 40 20 L 60 20 L 60 28 L 40 28 Z" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.5" />
                          {/* Metal band (silver) */}
                          <rect x="39" y="27" width="22" height="4" rx="1" fill="#E2E8F0" stroke="#3F6212" strokeWidth="2" />
                          {/* Wood shaft */}
                          <path d="M 40 31 L 60 31 L 60 71 L 50 83 L 40 71 Z" fill="#FACC15" stroke="#3F6212" strokeWidth="2.5" strokeLinejoin="round" />
                          {/* Sharp wood tip */}
                          <path d="M 40 71 Q 50 72, 60 71 L 50 85 Z" fill="#F8E3C0" stroke="#3F6212" strokeWidth="1.5" />
                          {/* Lead point */}
                          <path d="M 46 79 L 54 79 L 50 85 Z" fill="#222222" />
                          {/* Face */}
                          <ellipse cx="46" cy="46" rx="3.5" ry="5" fill="#222222" />
                          <circle cx="44.5" cy="44" r="1.5" fill="#FFFFFF" />
                          <ellipse cx="54" cy="46" rx="3.5" ry="5" fill="#222222" />
                          <circle cx="52.5" cy="44" r="1.5" fill="#FFFFFF" />
                          <circle cx="41" cy="51" r="2.5" fill="#FF8FA3" opacity="0.8" />
                          <circle cx="59" cy="51" r="2.5" fill="#FF8FA3" opacity="0.8" />
                          <path d="M 47 52 Q 50 57, 53 52 Z" fill="#E11D48" stroke="#222222" strokeWidth="1.5" />
                          <path d="M 38 48 Q 30 42, 28 35" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                          <path d="M 62 48 Q 70 42, 72 35" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                          <path d="M 45 66 L 43 73" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                          <path d="M 55 66 L 57 73" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                        </svg>
                      </motion.div>
                      <div className="mt-1">
                        <span className="inline-block text-[8px] uppercase font-mono tracking-wider font-extrabold text-lime-850 bg-lime-50 px-2 py-0.5 rounded-full border border-lime-300 shadow-sm">
                          Pensi
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Center text details */}
                <div className="flex-1 space-y-2 font-nunito">
                  <span className="text-xs font-mono uppercase tracking-widest font-black text-[#FF8FA3]">
                    Tantangan Pemilahan Sampah
                  </span>
                  <h1 className="font-fredoka text-2xl sm:text-3xl md:text-4xl font-bold text-[#1A4A0A]">
                    Kuis Hijau: <span className="text-[#FF8FA3]">Uji Pengetahuan</span>
                  </h1>
                  <p className="text-sm text-[#5A7A50] max-w-sm mx-auto font-semibold">
                    Jawab 5 pertanyaan seputar waktu dekomposisi sampah, Bank Sampah, dan dampak ekologis. Dapatkan +20 Koin Eco untuk setiap jawaban benar!
                  </p>
                </div>

                {/* Right Mascot (Kuiz the Question Mark) - Hidden on mobile */}
                <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[140px] shrink-0">
                  <div className="relative cursor-pointer group" onClick={() => setShowKuizBubble(prev => !prev)} title="Ketuk saya!">
                    {/* Speech bubble */}
                    <AnimatePresence mode="wait">
                      {showKuizBubble && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8, y: 15 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.8, y: -5 }}
                          transition={{ type: "spring", stiffness: 300, damping: 20 }}
                          className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-3 py-1.5 rounded-2xl text-[11px] shadow-sm border border-[#A8DF8E]/40 w-40 text-center z-20 hover:scale-103 transition-all duration-200"
                        >
                          <p className="leading-snug text-green-950 font-semibold">Kamu pasti bisa!</p>
                          <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Kuiz SVG wrapper */}
                    <div className="relative mt-10 text-center">
                      <div className="absolute inset-0 bg-[#FF8FA3]/20 rounded-full blur-xl group-hover:bg-[#A8DF8E]/20 transition-colors duration-300 -z-10" />
                      <motion.div
                        animate={{ y: [0, -5, 0] }}
                        transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
                      >
                        <svg viewBox="0 0 100 100" className="w-16 h-16 sm:w-20 sm:h-20 mx-auto filter drop-shadow-md select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                          {/* Question mark shape */}
                          <path d="M 35 30 C 35 15, 65 15, 65 30 C 65 42, 50 45, 50 56" fill="none" stroke="#FF8FA3" strokeWidth="11" strokeLinecap="round" />
                          <circle cx="50" cy="71" r="5.5" fill="#FF8FA3" />
                          {/* Cute face */}
                          <circle cx="43" cy="27" r="3" fill="#222222" />
                          <circle cx="42" cy="26" r="1" fill="#FFFFFF" />
                          <circle cx="53" cy="27" r="3" fill="#222222" />
                          <circle cx="52" cy="26" r="1" fill="#FFFFFF" />
                          <circle cx="38" cy="32" r="2" fill="#A8DF8E" opacity="0.8" />
                          <circle cx="58" cy="32" r="2" fill="#A8DF8E" opacity="0.8" />
                          <path d="M 46 31 Q 48 34, 50 31" stroke="#222222" strokeWidth="1.5" strokeLinecap="round" fill="none" />
                          <path d="M 33 35 Q 23 38, 20 44" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" fill="none" />
                          <path d="M 67 35 Q 77 38, 80 44" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" fill="none" />
                          <path d="M 44 76 L 40 82" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                          <path d="M 56 76 L 60 82" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                        </svg>
                      </motion.div>
                      <div className="mt-1">
                        <span className="inline-block text-[8px] uppercase font-mono tracking-wider font-extrabold text-pink-800 bg-pink-50 px-2 py-0.5 rounded-full border border-pink-300 shadow-sm">
                          Kuiz
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Mobile Mascot Row - shown inside layout when vertically compressed on mobile */}
                <div className="flex md:hidden items-center justify-center gap-8 w-full select-none pt-2 border-t border-dotted border-[#A8DF8E]/30">
                  {/* Pensi on mobile */}
                  <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer" onClick={() => setShowPensiBubble(prev => !prev)}>
                    <AnimatePresence mode="wait">
                      {showPensiBubble && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8, y: 10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.8, y: -5 }}
                          className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-3 py-1.5 rounded-xl text-[10px] shadow border border-[#A8DF8E]/40 w-36 text-center z-20"
                        >
                          <p className="leading-snug text-green-950 font-semibold text-center">Siap kuis?</p>
                          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                    <div className="relative mt-10">
                      <svg viewBox="0 0 100 100" className="w-14 h-14 filter drop-shadow">
                        <path d="M 40 20 L 60 20 L 60 28 L 40 28 Z" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.5" />
                        <path d="M 40 31 L 60 31 L 60 71 L 50 83 L 40 71 Z" fill="#FACC15" stroke="#3F6212" strokeWidth="2.5" />
                        <circle cx="46" cy="46" r="3.5" fill="#222222" />
                        <circle cx="54" cy="46" r="3.5" fill="#222222" />
                        <path d="M 47 52 Q 50 57, 53 52 Z" fill="#E11D48" stroke="#222222" strokeWidth="1.5" />
                      </svg>
                      <div className="text-center mt-0.5">
                        <span className="inline-block text-[8px] font-black text-lime-800 bg-lime-50 px-1.5 py-0.2 rounded-full border border-lime-300/30">
                          Pensi
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Kuiz on mobile */}
                  <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer" onClick={() => setShowKuizBubble(prev => !prev)}>
                    <AnimatePresence mode="wait">
                      {showKuizBubble && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8, y: 10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.8, y: -5 }}
                          className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-3 py-1.5 rounded-xl text-[10px] shadow border border-[#A8DF8E]/40 w-36 text-center z-20"
                        >
                          <p className="leading-snug text-green-950 font-semibold text-center">Kamu pasti bisa!</p>
                          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                    <div className="relative mt-10">
                      <svg viewBox="0 0 100 100" className="w-14 h-14 filter drop-shadow">
                        <path d="M 35 30 C 35 15, 65 15, 65 30 C 65 42, 50 45, 50 56" fill="none" stroke="#FF8FA3" strokeWidth="11" strokeLinecap="round" />
                        <circle cx="50" cy="71" r="5.5" fill="#FF8FA3" />
                        <circle cx="43" cy="27" r="3" fill="#222222" />
                        <circle cx="53" cy="27" r="3" fill="#222222" />
                      </svg>
                      <div className="text-center mt-0.5">
                        <span className="inline-block text-[8px] font-black text-pink-850 bg-pink-50 px-1.5 py-0.2 rounded-full border border-pink-300/30">
                          Kuiz
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Informative tips box */}
              <div className="p-4 rounded-2xl bg-[#F4FAF0] border border-[#E0F0D8] text-xs text-[#5A7A50] flex items-start space-x-2.5 max-w-md mx-auto text-left leading-relaxed font-nunito">
                <Info className="h-4 w-4 shrink-0 text-[#1A4A0A] mt-0.5" />
                <span>
                  <strong>Tips:</strong> Bacalah Buku Panduan Daur Ulang kami terlebih dahulu! Semua jawaban didasarkan pada riset manual dan SNI persampahan.
                </span>
              </div>

              <button
                onClick={() => setGameState('playing')}
                className="px-8 py-3.5 rounded-2xl bg-[#1A4A0A] hover:bg-[#A8DF8E] text-white hover:text-[#1A4A0A] font-black tracking-wide shadow-md hover:scale-103 active:scale-95 transition-all duration-200 flex items-center justify-center space-x-2 mx-auto cursor-pointer font-fredoka"
              >
                <Play className="h-4.5 w-4.5 fill-current" />
                <span>Mulai Kuis Sekarang</span>
              </button>
            </motion.div>
          )}

          {/* Playing Trivia Screen */}
          {gameState === 'playing' && (
            <motion.div
              key="playing"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white rounded-[2rem] border border-[#E0F0D8] p-6 sm:p-8 shadow-xl space-y-6 max-w-xl mx-auto"
            >
              {/* Question Header */}
              <div className="space-y-4 font-nunito">
                <div className="flex items-center justify-between text-xs sm:text-sm text-[#1A4A0A]">
                  <span className="font-mono font-bold uppercase tracking-wider text-[#FF8FA3]">
                    Pertanyaan {currentIdx + 1} dari {QUIZ_QUESTIONS.length}
                  </span>
                  <div className="flex items-center space-x-1 font-bold text-[#1A4A0A]">
                    <Trophy className="h-4 w-4 text-amber-500 animate-pulse" />
                    <span>Skor Seketika: {quizScore}/{QUIZ_QUESTIONS.length}</span>
                  </div>
                </div>

                {/* Progress bar container */}
                <div className="h-2 w-full bg-[#F4FAF0] border border-[#E0F0D8] rounded-full overflow-hidden shadow-inner">
                  <div 
                    className="h-full bg-gradient-to-r from-[#A8DF8E] to-[#1A4A0A] rounded-full transition-all duration-500"
                    style={{ width: `${((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
                  />
                </div>

                <h2 className="font-fredoka text-lg sm:text-xl font-bold text-[#1A4A0A] leading-snug">
                  {currentQuestion.question}
                </h2>
              </div>

              {/* Options list */}
              <div className="space-y-3 pt-2">
                {currentQuestion.options.map((option, idx) => {
                  const isCorrect = idx === currentQuestion.correctAnswer;
                  const isSelected = idx === selectedAns;
                  const hasAnswered = selectedAns !== null;

                  let optStyle = 'border-[#E0F0D8] hover:border-[#1A4A0A] hover:bg-[#F4FAF0] bg-white text-[#1A2E10]';
                  
                  if (hasAnswered) {
                    if (isCorrect) {
                      optStyle = 'bg-[#EAF7EA] border-[#A8DF8E]/85 text-[#1A4A0A] shadow-sm font-bold scale-[1.01]';
                    } else if (isSelected) {
                      optStyle = 'bg-[#FFF0F2] border-[#FF8FA3]/85 text-[#1A2E10]';
                    } else {
                      optStyle = 'opacity-50 border-[#E0F0D8] text-gray-400';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectOption(idx)}
                      disabled={hasAnswered}
                      className={`w-full text-left p-4 rounded-2xl border text-xs sm:text-sm leading-relaxed transition-all duration-200 cursor-pointer flex items-start space-x-3 group ${optStyle}`}
                    >
                      {/* Interactive alphabet tag */}
                      <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-mono font-black ${
                        hasAnswered && isCorrect
                          ? 'bg-[#1A4A0A] text-white'
                          : hasAnswered && isSelected
                          ? 'bg-[#FF8FA3] text-white'
                          : 'bg-[#F4FAF0] text-[#1A4A0A] font-bold'
                      }`}>
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span className="font-semibold leading-normal font-nunito">{option}</span>
                    </button>
                  );
                })}
              </div>

              {/* Verified Explanation Section */}
              <AnimatePresence>
                {selectedAns !== null && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className={`p-4 rounded-2xl border flex items-start space-x-3 text-xs sm:text-sm leading-relaxed shadow-inner ${
                      selectedAns === currentQuestion.correctAnswer
                        ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
                        : 'bg-rose-50/50 border-rose-100 text-rose-950'
                    }`}
                  >
                    <div className="p-1 rounded-lg bg-white/90 text-amber-600 shrink-0 mt-0.5 shadow-sm">
                      <HelpCircle className="h-4.5 w-4.5" />
                    </div>
                    <div>
                      <span className="font-extrabold block text-[10px] uppercase font-mono tracking-wider opacity-85">
                        {selectedAns === currentQuestion.correctAnswer ? 'Hebat! Jawaban Anda Benar' : 'Kurang Tepat! Penjelasan:'}
                      </span>
                      <p className="font-semibold mt-1">
                        {currentQuestion.explanation}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Next navigation toolbar */}
              {selectedAns !== null && (
                <div className="flex justify-end pt-4 border-t border-[#E0F0D8]">
                  <button
                    onClick={handleNextQuestion}
                    className="px-6 py-2.5 rounded-xl bg-[#1A4A0A] text-white hover:bg-[#A8DF8E] hover:text-[#1A4A0A] font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all cursor-pointer shadow-sm font-fredoka"
                  >
                    <span>{currentIdx < QUIZ_QUESTIONS.length - 1 ? 'Pertanyaan Selanjutnya' : 'Lihat Hasil Skor Akhir'}</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {/* Scoring Completion Screen */}
          {gameState === 'scoring' && (
            <motion.div
              key="scoring"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              className="bg-white rounded-[2rem] border border-[#E0F0D8] p-8 sm:p-10 shadow-xl text-center space-y-6 max-w-xl mx-auto"
            >
              <div className="relative inline-block">
                <div className="p-6 rounded-3xl bg-gradient-to-br from-[#A8DF8E] to-[#FF8FA3] text-white shadow-md">
                  <Trophy className="h-12 w-12 text-yellow-300 animate-pulse" />
                </div>
                <div className="absolute -top-1 -right-1 bg-yellow-400 p-1.5 rounded-full text-white shadow-md">
                  <Sparkles className="h-4 w-4 animate-spin-slow" />
                </div>
              </div>

              <div className="space-y-1 font-nunito">
                <span className="text-[10px] font-mono uppercase tracking-widest font-black text-[#FF8FA3]">
                  KUIS SELESAI
                </span>
                <h1 className="font-fredoka text-3xl font-bold text-[#1A4A0A]">
                  Skor Anda: <span className="text-[#FF8FA3]">{quizScore} / {QUIZ_QUESTIONS.length}</span>
                </h1>
                <p className="text-xs uppercase font-mono font-bold tracking-widest text-[#1A4A0A]">
                  (+{quizScore * 20} Koin Eco Berhasil Diperoleh)
                </p>
              </div>

              {/* Ranking analysis block */}
              <div className="p-5 bg-[#F4FAF0] border border-[#E0F0D8] rounded-2xl max-w-md mx-auto text-left space-y-2 font-nunito">
                <h3 className="font-fredoka text-base font-bold text-[#1A4A0A]">
                  {getRankAssessment().title}
                </h3>
                <p className="text-xs leading-relaxed text-[#5A7A50] font-semibold">
                  {getRankAssessment().desc}
                </p>
              </div>

              {/* Point claiming drawer panel */}
              <div className="pt-4 border-t border-[#E0F0D8] max-w-md mx-auto flex flex-col sm:flex-row items-center gap-3 justify-center font-fredoka">
                
                <AnimatePresence mode="wait">
                  {!hasAwardedInThisRun ? (
                    <motion.button
                      key="claim-coin"
                      onClick={handleFinishAndClaim}
                      className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#FF8FA3] hover:bg-[#FFD6DC] text-[#1A2E10] text-sm font-extrabold flex items-center justify-center space-x-2 shadow-sm transition-all cursor-pointer"
                    >
                      <Coins className="h-4.5 w-4.5 text-[#1A2E10]" />
                      <span>Klaim +{quizScore * 20} Koin Eco</span>
                    </motion.button>
                  ) : (
                    <motion.div
                      key="claimed-coin"
                      className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-[#1A4A0A] text-white text-xs font-bold text-center flex items-center justify-center space-x-2 shadow-inner"
                    >
                      <CheckCircle className="h-4.5 w-4.5 text-white" />
                      <span>Koin Eco berhasil disimpan ke dompet!</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                <button
                  onClick={handleResetQuiz}
                  className="w-full sm:w-auto px-6 py-3 rounded-xl border border-[#E0F0D8] text-[#1A4A0A] hover:bg-[#F4FAF0] font-bold text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer"
                >
                  <RotateCw className="h-4 w-4" />
                  <span>Ulangi Kuis</span>
                </button>
              </div>
            </motion.div>
          )}

        </AnimatePresence>

        {/* Cute Excited Pencil Mascot in the Corner */}
        <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 hidden xs:block">
          <div className="relative group">
            {/* Speech Bubble */}
            <AnimatePresence>
              {showBubble && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: 15 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  className="absolute bottom-20 right-2 bg-white text-green-950 font-bold px-3 py-2 rounded-2xl text-[11px] sm:text-xs shadow-lg border border-[#A8DF8E]/40 w-40 text-center z-50 hover:scale-102 transition-transform duration-150 cursor-pointer"
                  onClick={() => setShowBubble(false)}
                  title="Klik untuk menyembunyikan bubble"
                >
                  <p className="leading-snug text-green-950 font-semibold">Ayo uji pengetahuanmu!</p>
                  <div className="absolute -bottom-1.5 right-6 w-3 h-3 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                </motion.div>
              )}
            </AnimatePresence>
            
            {/* Mascot Button */}
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ repeat: Infinity, duration: 2.1, ease: "easeInOut" }}
              className="w-16 h-16 sm:w-20 sm:h-20 filter drop-shadow-md cursor-pointer select-none"
              onClick={() => setShowBubble(!showBubble)}
              title="Klik saya!"
            >
              <svg viewBox="0 0 100 100" className="w-full h-full transform hover:scale-110 active:scale-95 transition-transform duration-200">
                {/* Eraser */}
                <path d="M 40 20 L 60 20 L 60 28 L 40 28 Z" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.5" />
                {/* Metal band (silver) */}
                <rect x="39" y="27" width="22" height="4" rx="1" fill="#E2E8F0" stroke="#3F6212" strokeWidth="2" />
                
                {/* Wood shaft */}
                <path d="M 40 31 L 60 31 L 60 71 L 50 83 L 40 71 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="2.5" strokeLinejoin="round" />
                
                {/* Sharp wood tip */}
                <path d="M 40 71 Q 50 72, 60 71 L 50 85 Z" fill="#F8E3C0" stroke="#3F6212" strokeWidth="1.5" />
                {/* Lead point */}
                <path d="M 46 79 L 54 79 L 50 85 Z" fill="#222222" />
                
                {/* Face on the shaft */}
                {/* Big shiny eyes */}
                <ellipse cx="46" cy="46" rx="3.5" ry="5" fill="#222222" />
                <circle cx="44.5" cy="44" r="1.5" fill="#FFFFFF" />
                <ellipse cx="54" cy="46" rx="3.5" ry="5" fill="#222222" />
                <circle cx="52.5" cy="44" r="1.5" fill="#FFFFFF" />
                
                {/* Rosy Cheeks */}
                <circle cx="41" cy="51" r="2.5" fill="#FF8FA3" opacity="0.8" />
                <circle cx="59" cy="51" r="2.5" fill="#FF8FA3" opacity="0.8" />
                
                {/* Open excited mouth */}
                <path d="M 47 52 Q 50 57, 53 52 Z" fill="#E11D48" stroke="#222222" strokeWidth="1.5" />
                
                {/* Hands high cheering */}
                <path d="M 38 48 Q 30 42, 28 35" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                <path d="M 62 48 Q 70 42, 72 35" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                
                {/* Standing feet */}
                <path d="M 45 66 L 43 73" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                <path d="M 55 66 L 57 73" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </motion.div>
          </div>
        </div>

      </div>
    </div>
  );
}
