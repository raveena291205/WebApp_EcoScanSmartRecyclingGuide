import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Leaf, Sparkles, BookOpen, ShieldAlert, GlassWater, Skull, 
  CheckCircle2, XCircle, Lightbulb, ChevronRight, HelpCircle 
} from 'lucide-react';
import { WASTE_CATEGORIES } from '../data';
import { WasteType } from '../types';

const iconMap: Record<string, any> = {
  Leaf,
  Sparkles,
  BookOpen,
  ShieldAlert,
  GlassWater,
  Skull
};

export default function GuidePage() {
  const [selectedCategory, setSelectedCategory] = useState<WasteType>('organic');
  const [showBubble, setShowBubble] = useState(true);
  const [showTonoBubble, setShowTonoBubble] = useState(true);
  const [showLiliBubble, setShowLiliBubble] = useState(true);

  const currentCategory = WASTE_CATEGORIES.find(cat => cat.id === selectedCategory) || WASTE_CATEGORIES[0];
  const CategoryIcon = iconMap[currentCategory.iconName] || HelpCircle;

  return (
    <div className="w-full relative min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8 overflow-hidden bg-[#F4FAF0]" id="guide-page-root">
      
      {/* Decorative Blob Shapes */}
      <div className="absolute top-10 right-10 w-72 h-72 bg-[#FFD6DC]/30 rounded-full blur-3xl -z-10 animate-float-slow" />
      <div className="absolute bottom-10 left-10 w-72 h-72 bg-[#A8DF8E]/20 rounded-full blur-3xl -z-10 animate-float-reverse" />

      <div className="max-w-5xl mx-auto space-y-8">
        
        {/* Responsive Dual Mascot Header */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-20 w-full mb-2">
          
          {/* Left Mascot (Tono the Green Trash Bin) - Hidden on mobile view, shown on desktop sides */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" title="Tono!">
              {/* Tono SVG Wrapper */}
              <div className="relative mt-2 text-center">
                <div className="absolute inset-0 bg-[#A8DF8E]/20 rounded-full blur-xl group-hover:bg-[#FFD6DC]/20 transition-colors duration-300 -z-10" />
                <div>
                  <svg viewBox="0 0 100 100" className="w-20 h-20 sm:w-24 sm:h-24 mx-auto filter drop-shadow-md select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                    <path d="M 28 37 L 34 85 C 35 90, 65 90, 66 85 L 72 37 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" strokeLinejoin="round" />
                    <path d="M 25 35 Q 50 25, 75 35" stroke="#3F6212" strokeWidth="2.5" fill="#FF8FA3" strokeLinecap="round" />
                    <path d="M 45 28 Q 50 20, 55 28" stroke="#3F6212" strokeWidth="2.5" fill="#FF8FA3" strokeLinecap="round" />
                    <rect x="22" y="32" width="56" height="5" rx="2" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.5" />
                    <path d="M 44 60 L 50 51 L 56 60 Z" fill="none" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" />
                    <circle cx="42" cy="48" r="4.5" fill="#222222" />
                    <circle cx="40.5" cy="46" r="1.5" fill="#FFFFFF" />
                    <circle cx="58" cy="48" r="4.5" fill="#222222" />
                    <circle cx="56.5" cy="46" r="1.5" fill="#FFFFFF" />
                    <circle cx="36" cy="53" r="3" fill="#FF8FA3" opacity="0.8" />
                    <circle cx="64" cy="53" r="3" fill="#FF8FA3" opacity="0.8" />
                    <path d="M 47 52 Q 50 56, 53 52" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 27 50 Q 18 45, 15 50" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 73 50 Q 82 55, 84 48" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <ellipse cx="38" cy="87" rx="5" ry="3.5" fill="#3F6212" />
                    <ellipse cx="62" cy="87" rx="5" ry="3.5" fill="#3F6212" />
                  </svg>
                </div>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-lime-800 bg-[#E8F8E8] px-2 py-0.5 rounded-full border border-lime-300/40 shadow-sm">
                    Tono
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Title area */}
          <div className="flex-1 text-center py-2 space-y-2">
            <span className="text-xs uppercase font-mono tracking-widest font-extrabold text-[#FF8FA3]">
              Buku Panduan & Manual Daur Ulang
            </span>
            <h1 className="font-fredoka text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#1A4A0A]">
              Panduan <span className="text-[#FF8FA3]">Pilah Sampah</span>
            </h1>
            <p className="font-nunito text-sm sm:text-base text-[#5A7A50] max-w-xl mx-auto font-semibold">
              Pilih kategori sampah di bawah untuk mempelajari cara pemilahan terbaik, daftar hal yang perlu dilakukan dan dihindari, serta ide kreasi daur ulang kreatif mandiri.
            </p>
          </div>

          {/* Right Mascot (Lili the Leaf) - Hidden on mobile view, shown on desktop sides */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" title="Lili!">
              {/* Lili SVG Wrapper */}
              <div className="relative mt-2 text-center">
                <div className="absolute inset-0 bg-[#A8DF8E]/25 rounded-full blur-xl group-hover:bg-[#FF8FA3]/25 transition-colors duration-300 -z-10" />
                <div>
                  <svg viewBox="0 0 100 100" className="w-20 h-20 sm:w-24 sm:h-24 mx-auto filter drop-shadow-md select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                    <path d="M 50 20 C 53 10, 60 5, 60 5" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 50 15 C 80 35, 83 75, 50 95 C 17 75, 20 35, 50 15 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="2.5" />
                    <path d="M 50 15 L 50 95" stroke="#4D7C0F" strokeWidth="1.5" opacity="0.5" strokeDasharray="2 2" />
                    <path d="M 50 40 Q 65 35, 72 30" stroke="#4D7C0F" strokeWidth="1.2" opacity="0.5" />
                    <path d="M 50 40 Q 35 35, 28 30" stroke="#4D7C0F" strokeWidth="1.2" opacity="0.5" />
                    <path d="M 50 60 Q 68 55, 75 50" stroke="#4D7C0F" strokeWidth="1.2" opacity="0.5" />
                    <path d="M 50 60 Q 32 55, 25 50" stroke="#4D7C0F" strokeWidth="1.2" opacity="0.5" />
                    <circle cx="40" cy="52" r="3.5" fill="#222222" />
                    <circle cx="38.5" cy="50.5" r="1" fill="#FFFFFF" />
                    <path d="M 55 50 Q 60 45, 64 50" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <ellipse cx="34" cy="58" rx="3.5" ry="2.2" fill="#FF8FA3" opacity="0.8" />
                    <ellipse cx="66" cy="58" rx="3.5" ry="2.2" fill="#FF8FA3" opacity="0.8" />
                    <path d="M 47 58 Q 50 61, 53 58" stroke="#222222" strokeWidth="2" strokeLinecap="round" fill="none" />
                    <path d="M 28 62 Q 20 60, 18 55" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" fill="none" />
                    <path d="M 72 62 Q 80 60, 82 55" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" fill="none" />
                    <circle cx="83" cy="51" r="2.5" fill="#FF8FA3" />
                    <circle cx="83" cy="51" r="0.8" fill="#FACC15" />
                  </svg>
                </div>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-blue-800 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-300/40 shadow-sm">
                    Lili
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Mascot Row - shown side by side below/within header layout to save height on mobile */}
          <div className="flex md:hidden items-center justify-center gap-8 w-full select-none pt-2 border-t border-dotted border-[#A8DF8E]/30">
            {/* Tono on mobile */}
            <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer">
              <div className="relative mt-2">
                <svg viewBox="0 0 100 100" className="w-16 h-16 filter drop-shadow">
                  <path d="M 28 37 L 34 85 C 35 90, 65 90, 66 85 L 72 37 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" strokeLinejoin="round" />
                  <path d="M 25 35 Q 50 25, 75 35" stroke="#3F6212" strokeWidth="2.5" fill="#FF8FA3" strokeLinecap="round" />
                  <rect x="22" y="32" width="56" height="5" rx="2" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.5" />
                  <circle cx="42" cy="48" r="4.5" fill="#222222" />
                  <circle cx="58" cy="48" r="4.5" fill="#222222" />
                  <path d="M 47 52 Q 50 56, 53 52" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-lime-800 bg-[#E8F8E8] px-1.5 py-0.2 rounded-full border border-lime-300/30">
                    Tono
                  </span>
                </div>
              </div>
            </div>

            {/* Lili on mobile */}
            <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer">
              <div className="relative mt-2">
                <svg viewBox="0 0 100 100" className="w-16 h-16 filter drop-shadow">
                  <path d="M 50 15 C 80 35, 83 75, 50 95 C 17 75, 20 35, 50 15 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="2.5" />
                  <circle cx="40" cy="52" r="3.5" fill="#222222" />
                  <path d="M 55 50 Q 60 45, 64 50" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-blue-800 bg-blue-50 px-1.5 py-0.2 rounded-full border border-blue-300/30">
                    Lili
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Categories Carousel / Tabs select */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 sm:gap-3 bg-white p-2.5 rounded-[1.8rem] border border-[#E0F0D8] shadow-sm relative z-10">
          {WASTE_CATEGORIES.map((cat) => {
            const Icon = iconMap[cat.iconName] || HelpCircle;
            const isSelected = selectedCategory === cat.id;
            
            // Set styles based on category select
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`py-3 px-2 rounded-2xl flex flex-col items-center justify-center transition-all duration-300 relative group cursor-pointer ${
                  isSelected
                    ? 'bg-[#1A4A0A] text-white shadow-md scale-102'
                    : 'text-[#5A7A50] hover:bg-[#F4FAF0] hover:text-[#1A4A0A]'
                }`}
              >
                {/* Visual Circle Indicator wrapper */}
                <div 
                  className={`p-2.5 rounded-xl mb-1.5 transition-transform duration-300 group-hover:scale-105 ${
                    isSelected 
                      ? 'bg-white/10 text-white' 
                      : 'bg-[#F4FAF0] text-[#1A4A0A]'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <span className={`block text-xs font-bold font-fredoka tracking-tight leading-none ${isSelected ? 'text-white' : 'text-[#1A4A0A]'}`}>
                  {cat.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Content detail area with layout switches */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentCategory.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-12 gap-6 relative"
          >
            {/* Category Intro Column (Left pane / 4 columns) */}
            <div className={`md:col-span-4 rounded-3xl p-6 sm:p-8 bg-gradient-to-br ${currentCategory.bgGradient} border border-[#A8DF8E]/20 shadow-lg flex flex-col justify-between relative overflow-hidden h-fit md:min-h-[28rem]`}>
              
              {/* Abs decoration card shape */}
              <div className="absolute -right-10 -bottom-10 opacity-10">
                <CategoryIcon className="h-44 w-44" />
              </div>

              <div className="space-y-4">
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/75 text-green-950 text-xs font-black uppercase tracking-wider shadow-sm border border-white/40">
                  <CategoryIcon className="h-4 w-4" style={{ color: currentCategory.accentColor }} />
                  <span>Kategori {currentCategory.id.toUpperCase()}</span>
                </div>

                <div className="space-y-1">
                  <h2 className="font-serif text-2xl sm:text-3xl font-bold text-green-950 leading-tight">
                    {currentCategory.name}
                  </h2>
                </div>

                <div className="space-y-3 pt-2">
                  <p className="text-xs sm:text-sm text-green-900 leading-relaxed font-semibold">
                    {currentCategory.description}
                  </p>
                </div>
              </div>

              {/* Status footer inside left box */}
              <div className="pt-8 relative z-10 w-full">
                <div className="p-3 bg-white/70 backdrop-blur-md rounded-2xl border border-white/60 shadow-sm">
                  <span className="block text-[9px] font-mono text-green-800 uppercase font-bold tracking-wider">Standar Indonesia</span>
                  <span className="block text-xs font-serif font-extrabold text-green-950 mt-0.5">Kode Pemilahan Sampah SNI</span>
                </div>
              </div>
            </div>

            {/* Dos, Donts, and Upcycling Area (Right pane / 8 columns) */}
            <div className="md:col-span-8 space-y-6">
              
              {/* Do & Don'ts Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Do card */}
                <div className="bg-white rounded-[2rem] border-l-4 border-l-[#1A4A0A] border-y border-r border-[#E0F0D8] p-6 space-y-4 shadow-md hover:shadow-lg transition-all">
                  <div className="flex items-center space-x-2 text-emerald-800 pb-2 border-b border-slate-100">
                    <CheckCircle2 className="h-5 w-5 text-emerald-600 fill-emerald-100" />
                    <div>
                      <h4 className="font-fredoka font-bold leading-none text-[#1A4A0A]">Lakukan Hal Ini</h4>
                      <span className="text-[10px] text-[#5A7A50] font-bold uppercase tracking-wider font-mono">Silakan Praktekkan</span>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    {currentCategory.dos.map((doItem, k) => (
                      <div key={k} className="flex space-x-2.5 items-start">
                        <ChevronRight className="h-4 w-4 text-emerald-605 text-[#1A4A0A] shrink-0 mt-0.5" />
                        <span className="text-xs sm:text-sm text-[#3A5A30] leading-relaxed font-semibold font-nunito">
                          {doItem}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Don'ts Card */}
                <div className="bg-white rounded-[2rem] border-l-4 border-l-[#1A4A0A] border-y border-r border-[#E0F0D8] p-6 space-y-4 shadow-md hover:shadow-lg transition-all font-nunito">
                  <div className="flex items-center space-x-2 text-rose-800 pb-2 border-b border-slate-100 font-fredoka">
                    <XCircle className="h-5 w-5 text-rose-600 fill-rose-100" />
                    <div>
                      <h4 className="font-bold leading-none text-[#1A4A0A]">Hindari Hal Ini</h4>
                      <span className="text-[10px] text-rose-700/80 font-bold uppercase tracking-wider font-mono">Tindakan Keliru</span>
                    </div>
                  </div>
                  
                  <div className="space-y-3 font-nunito">
                    {currentCategory.donts.map((dontItem, k) => (
                      <div key={k} className="flex space-x-2.5 items-start">
                        <ChevronRight className="h-4 w-4 text-rose-500 shrink-0 mt-0.5" />
                        <span className="text-xs sm:text-sm text-[#3A5A30] leading-relaxed font-semibold">
                          {dontItem}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Creative Upcycling Ideas block */}
              <div className="bg-white rounded-[2rem] border-l-4 border-l-[#1A4A0A] border-y border-r border-[#E0F0D8] p-6 space-y-4 shadow-md">
                <div className="flex items-center space-x-2.5 pb-2.5 border-b border-slate-100">
                  <div className="p-1.5 rounded-xl bg-[#FFD6DC] text-[#FF8FA3]">
                    <Lightbulb className="h-5 w-5 fill-current text-[#FF8FA3]" />
                  </div>
                  <div>
                    <h4 className="font-fredoka font-bold leading-none text-[#1A4A0A]">Ide Upcycling Kreatif</h4>
                    <span className="text-[10px] text-[#5A7A50] font-bold uppercase tracking-wider font-mono">Proyek Kreatif Daur Ulang Mandiri</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {currentCategory.upcyclingIdeas.map((idea, i) => (
                    <div 
                      key={i} 
                      className="p-4 rounded-2xl bg-[#F4FAF0] border border-[#E0F0D8] shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div className="space-y-1.5">
                        <span className="inline-block text-[10px] font-bold font-fredoka text-[#1A4A0A] bg-[#A8DF8E] px-2 py-0.5 rounded-md">
                          PROYEK 0{i + 1}
                        </span>
                        <p className="text-xs text-[#3A5A30] leading-relaxed font-bold font-nunito">
                          {idea}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </motion.div>
        </AnimatePresence>

        {/* Cute Smiling Trash Bin Mascot in the Corner */}
        <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 hidden xs:block">
          <div className="relative group">
            {/* Mascot Button */}
            <div className="w-16 h-16 sm:w-20 sm:h-20 filter drop-shadow-md cursor-pointer select-none" title="Tono!">
              <svg viewBox="0 0 100 100" className="w-full h-full transform hover:scale-110 active:scale-95 transition-transform duration-200">
                {/* Litter lid */}
                <path d="M 25 35 Q 50 25, 75 35" stroke="#3F6212" strokeWidth="2.5" fill="#FF8FA3" strokeLinecap="round" />
                <path d="M 45 28 Q 50 20, 55 28" stroke="#3F6212" strokeWidth="2.5" fill="#FF8FA3" strokeLinecap="round" />
                {/* Lid side edges */}
                <rect x="22" y="32" width="56" height="5" rx="2" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.5" />
                
                {/* Trash Bin core body */}
                <path d="M 28 37 L 34 85 C 35 90, 65 90, 66 85 L 72 37 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" strokeLinejoin="round" />
                
                {/* Simple recycling symbol */}
                <path d="M 44 60 L 50 51 L 56 60 Z" fill="none" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" />
                
                {/* Large shiny eyes */}
                <circle cx="42" cy="48" r="4.5" fill="#222222" />
                <circle cx="40.5" cy="46" r="1.5" fill="#FFFFFF" />
                <circle cx="58" cy="48" r="4.5" fill="#222222" />
                <circle cx="56.5" cy="46" r="1.5" fill="#FFFFFF" />
                
                {/* Rosy Cheeks */}
                <circle cx="36" cy="53" r="3" fill="#FF8FA3" opacity="0.8" />
                <circle cx="64" cy="53" r="3" fill="#FF8FA3" opacity="0.8" />
                
                {/* Smiling mouth */}
                <path d="M 47 52 Q 50 56, 53 52" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                
                {/* Hands waving */}
                <path d="M 27 50 Q 18 45, 15 50" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                <path d="M 73 50 Q 82 55, 84 48" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                
                {/* Tiny feet */}
                <ellipse cx="38" cy="87" rx="5" ry="3.5" fill="#3F6212" />
                <ellipse cx="62" cy="87" rx="5" ry="3.5" fill="#3F6212" />
              </svg>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
