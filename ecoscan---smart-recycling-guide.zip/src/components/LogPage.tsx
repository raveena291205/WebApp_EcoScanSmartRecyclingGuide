import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  History, Trash2, Shield, Calendar, Award, Leaf, Sparkles, 
  BookOpen, Skull, GlassWater, Coins, AlertCircle, BarChart3, HelpCircle,
  TrendingUp, Award as AwardIcon, CheckCircle2, Lock
} from 'lucide-react';
import { EcoLogItem, WasteType } from '../types';
import { TrophySketch } from './SketchIcons';
import { 
  getLevelInfo, 
  getNextLevelInfo, 
  getPercentageToNextLevel, 
  ECO_LEVELS,
  EcoLevel 
} from '../utils/level';

interface LogPageProps {
  logs: EcoLogItem[];
  onDeleteLog: (id: string) => void;
  onClearAllLogs: () => void;
  points: number;
}

export default function LogPage({ logs, onDeleteLog, onClearAllLogs, points }: LogPageProps) {
  const [showBubble, setShowBubble] = useState(true);
  const [showBintiBubble, setShowBintiBubble] = useState(true);
  const [showTrofiBubble, setShowTrofiBubble] = useState(true);

  // Calculate live stats from logs array
  const totalScanned = logs.length;
  const pointsEarned = logs.reduce((sum, item) => sum + item.ecoPoints, 0);

  const getMostCommonType = (): { type: string; label: string; icon: any } => {
    if (logs.length === 0) {
      return { type: 'None', label: 'Belum ada', icon: HelpCircle };
    }
    const counts: Record<string, number> = {};
    logs.forEach(item => {
      counts[item.wasteType] = (counts[item.wasteType] || 0) + 1;
    });

    let bestType: WasteType | 'None' = 'None';
    let max = 0;
    Object.entries(counts).forEach(([type, count]) => {
      if (count > max) {
        max = count;
        bestType = type as WasteType;
      }
    });

    const mapping: Record<string, { label: string; icon: any }> = {
      organic: { label: 'Organik', icon: Leaf },
      plastic: { label: 'Plastik', icon: Sparkles },
      paper: { label: 'Kertas', icon: BookOpen },
      metal: { label: 'Logam', icon: Shield },
      glass: { label: 'Kaca', icon: GlassWater },
      B3: { label: 'Limbah B3', icon: Skull },
    };

    return {
      type: bestType,
      label: mapping[bestType]?.label || 'Lainnya',
      icon: mapping[bestType]?.icon || HelpCircle
    };
  };

  const mostCommonAttr = getMostCommonType();
  const CommonIcon = mostCommonAttr.icon;

  // Formatting timestamp
  const formatDate = (isoStr: string) => {
    try {
      const date = new Date(isoStr);
      // Indonesian month formatting
      const monthsIndo = [
        'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 
        'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'
      ];
      const day = date.getDate();
      const month = monthsIndo[date.getMonth()];
      const year = date.getFullYear();
      const time = date.toTimeString().split(' ')[0].substring(0, 5); // HH:MM
      
      return `${day} ${month} ${year}, ${time}`;
    } catch {
      return isoStr;
    }
  };

  // Badge mapping helper
  const getBadgeStyleAndName = (type: WasteType) => {
    switch (type) {
      case 'organic':
        return { style: 'bg-emerald-50 text-emerald-800 border-emerald-200', label: 'Organik' };
      case 'plastic':
        return { style: 'bg-rose-50 text-rose-800 border-rose-200', label: 'Plastik' };
      case 'paper':
        return { style: 'bg-amber-50 text-amber-800 border-amber-200', label: 'Kertas' };
      case 'metal':
        return { style: 'bg-sky-50 text-sky-800 border-sky-200', label: 'Logam' };
      case 'glass':
        return { style: 'bg-purple-50 text-purple-800 border-purple-200', label: 'Kaca' };
      case 'B3':
        return { style: 'bg-red-50 text-red-950 border-red-200 font-extrabold', label: 'Limbah B3' };
      default:
        return { style: 'bg-gray-50 text-gray-800 border-gray-200 border', label: 'Lain-lain' };
    }
  };

  return (
    <div className="w-full relative min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8 overflow-hidden bg-[#F4FAF0]" id="log-page-root">
      
      {/* Decorative Blob Shapes */}
      <div className="absolute top-1/3 left-10 w-80 h-80 bg-[#A8DF8E]/15 rounded-full blur-3xl -z-10 animate-float-slow" />
      <div className="absolute bottom-1/3 right-10 w-80 h-80 bg-[#FFD6DC]/25 rounded-full blur-3xl -z-10 animate-float-reverse" />

      <div className="max-w-5xl mx-auto space-y-8">
        
        {/* Responsive Dual Mascot Header */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-20 w-full mb-2">
          
          {/* Left Mascot (Binti the proud Green Star) - Hidden on mobile view, shown on desktop sides */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" title="Binti!">
              {/* Binti SVG Wrapper */}
              <div className="relative mt-2 text-center">
                <div className="absolute inset-0 bg-[#A8DF8E]/20 rounded-full blur-xl group-hover:bg-[#FFD6DC]/20 transition-colors duration-300 -z-10" />
                <div>
                  <svg viewBox="0 0 100 100" className="w-20 h-20 sm:w-24 sm:h-24 mx-auto filter drop-shadow-md select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                    <path d="M 50 12 L 61 38 L 89 38 L 66 54 L 75 80 L 50 63 L 25 80 L 34 54 L 11 38 L 39 38 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" strokeLinejoin="round" />
                    <circle cx="42" cy="45" r="4.5" fill="#222222" />
                    <circle cx="40.5" cy="43" r="1.5" fill="#FFFFFF" />
                    <circle cx="58" cy="45" r="4.5" fill="#222222" />
                    <circle cx="56.5" cy="43" r="1.5" fill="#FFFFFF" />
                    <circle cx="36" cy="50" r="3" fill="#FF8FA3" opacity="0.8" />
                    <circle cx="64" cy="50" r="3" fill="#FF8FA3" opacity="0.8" />
                    <path d="M 46 50 Q 50 55, 54 50" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 32 49 Q 27 53, 32 56" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 68 49 Q 73 53, 68 56" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 45 13 L 50 7 L 55 13" stroke="#222222" strokeWidth="1.5" fill="none" />
                    <circle cx="50" cy="5" r="1.5" fill="#FF8FA3" />
                  </svg>
                </div>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-lime-800 bg-[#E8F8E8] px-2 py-0.5 rounded-full border border-lime-300/40 shadow-sm">
                    Binti
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Title area */}
          <div className="flex-1 text-center py-2 space-y-2 font-nunito">
            <span className="text-xs uppercase font-mono tracking-widest font-extrabold text-[#FF8FA3]">
              Buku Catatan Ekologis Saya
            </span>
            <h1 className="font-fredoka text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#1A4A0A]">
              Log Hijau <span className="text-[#A8DF8E]">Saya</span>
            </h1>
            <p className="text-sm sm:text-base text-[#5A7A50] max-w-xl mx-auto font-semibold">
              Catatan komprehensif dari upaya daur ulang Anda. Pantau perkembangan kontribusi penyelamatan kelestarian bumi!
            </p>
          </div>

          {/* Right Mascot (Trofi the Pink Trophy) - Hidden on mobile view, shown on desktop sides */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" title="Trofi!">
              {/* Trofi SVG Wrapper */}
              <div className="relative mt-2 text-center">
                <div className="absolute inset-0 bg-[#FF8FA3]/25 rounded-full blur-xl group-hover:bg-[#A8DF8E]/25 transition-colors duration-300 -z-10" />
                <div>
                  <svg viewBox="0 0 100 100" className="w-20 h-20 sm:w-24 sm:h-24 mx-auto filter drop-shadow-md select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                    <rect x="36" y="80" width="28" height="6" rx="2" fill="#4B5563" stroke="#3F6212" strokeWidth="2" />
                    <path d="M 42 70 L 58 70 L 55 80 L 45 80 Z" fill="#9CA3AF" stroke="#3F6212" strokeWidth="2" />
                    <path d="M 27 34 Q 15 34, 27 54 Z" fill="none" stroke="#FF8FA3" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 73 34 Q 85 34, 73 54 Z" fill="none" stroke="#FF8FA3" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 28 30 L 72 30 C 72 58, 62 69, 50 70 C 38 69, 28 58, 28 30 Z" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.8" strokeLinejoin="round" />
                    <path d="M 64 36 L 68 36 C 68 50, 62 58, 55 62" stroke="#FFFFFF" strokeWidth="2" fill="none" opacity="0.6" strokeLinecap="round" />
                    <path d="M 50 36 L 52 42 L 57 42 L 53 45 L 55 51 L 50 48 L 45 51 L 47 45 L 43 42 L 48 42 Z" fill="#FACC15" />
                    <circle cx="43" cy="46" r="3.2" fill="#222222" />
                    <circle cx="41.5" cy="44.2" r="1.1" fill="#FFFFFF" />
                    <circle cx="57" cy="46" r="3.2" fill="#222222" />
                    <circle cx="55.5" cy="44.2" r="1.1" fill="#FFFFFF" />
                    <circle cx="36" cy="51" r="2.2" fill="#A8DF8E" opacity="0.9" />
                    <circle cx="64" cy="51" r="2.2" fill="#A8DF8E" opacity="0.9" />
                    <path d="M 47 52 Q 50 56, 53 52" stroke="#222222" strokeWidth="2.2" strokeLinecap="round" fill="none" />
                    <path d="M 45 86 L 42 93" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                    <path d="M 55 86 L 58 93" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                  </svg>
                </div>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-pink-850 bg-pink-50 px-2 py-0.5 rounded-full border border-pink-300/40 shadow-sm">
                    Trofi
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Mascot Row - shown side by side below/within header layout to save height on mobile */}
          <div className="flex md:hidden items-center justify-center gap-8 w-full select-none pt-2 border-t border-dotted border-[#A8DF8E]/30">
            {/* Binti on mobile */}
            <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer">
              <div className="relative mt-2">
                <svg viewBox="0 0 100 100" className="w-16 h-16 filter drop-shadow">
                  <path d="M 50 12 L 61 38 L 89 38 L 66 54 L 75 80 L 50 63 L 25 80 L 34 54 L 11 38 L 39 38 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" />
                  <circle cx="42" cy="45" r="4.5" fill="#222222" />
                  <circle cx="58" cy="45" r="4.5" fill="#222222" />
                  <path d="M 46 50 Q 50 55, 54 50" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-lime-800 bg-lime-50 px-1.5 py-0.2 rounded-full border border-lime-300/30">
                    Binti
                  </span>
                </div>
              </div>
            </div>

            {/* Trofi on mobile */}
            <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer">
              <div className="relative mt-2">
                <svg viewBox="0 0 100 100" className="w-16 h-16 filter drop-shadow">
                  <path d="M 28 30 L 72 30 C 72 58, 62 69, 50 70 C 38 69, 28 58, 28 30 Z" fill="#FF8FA3" stroke="#3F6212" strokeWidth="2.8" />
                  <circle cx="43" cy="46" r="3.2" fill="#222222" />
                  <circle cx="57" cy="46" r="3.2" fill="#222222" />
                  <path d="M 47 52 Q 50 56, 53 52" stroke="#222222" strokeWidth="2.2" strokeLinecap="round" fill="none" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-pink-850 bg-pink-50 px-1.5 py-0.2 rounded-full border border-pink-300/30">
                    Trofi
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Stats widgets layout */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 font-nunito">
          
          {/* Stat 1: Total Items Scanned */}
          <div className="p-5 rounded-[2rem] border border-[#E0F0D8] shadow-sm relative overflow-hidden group hover:shadow-md transition-all duration-300 flex items-center space-x-4 bg-[#EAF7EA]">
            <div className="p-3.5 rounded-2xl bg-emerald-100 text-[#1A4A0A] group-hover:scale-105 transition-transform animate-pulse-slow">
              <BarChart3 className="h-6 w-6" />
            </div>
            <div>
              <span className="block text-[10px] uppercase font-mono tracking-wider text-[#5A7A50] font-black">Total Pemindaian</span>
              <span className="block font-fredoka text-2xl sm:text-3xl font-bold text-[#1A4A0A]">{totalScanned} Sampah</span>
              <span className="block text-[10px] text-[#5A7A50] leading-none">Disimpan dalam buku catatan</span>
            </div>
          </div>

          {/* Stat 2: Most Common Waste */}
          <div className="p-5 rounded-[2rem] border border-[#FF8FA3]/20 shadow-sm relative overflow-hidden group hover:shadow-md transition-all duration-300 flex items-center space-x-4 bg-[#FFF0F2]">
            <div className="p-3.5 rounded-2xl bg-[#FFD6DC] text-rose-800 group-hover:scale-105 transition-transform">
              <CommonIcon className="h-6 w-6 text-rose-700 animate-bounce" />
            </div>
            <div>
              <span className="block text-[10px] uppercase font-mono tracking-wider text-[#5A7A50] font-black">Material Dominan</span>
              <span className="block font-fredoka text-lg sm:text-xl font-bold text-[#1A4A0A] truncate max-w-[12rem]">{mostCommonAttr.label}</span>
              <span className="block text-[10px] text-[#5A7A50] leading-none">Paling sering dikumpulkan</span>
            </div>
          </div>

          {/* Stat 3: Points Earned from Logs */}
          <div className="p-5 rounded-[2rem] border border-[#F1E3AD] shadow-sm relative overflow-hidden group hover:shadow-md transition-all duration-300 bg-[#FCF9E3] flex items-center space-x-4">
            <div className="p-3.5 rounded-2xl bg-amber-100 text-yellow-800 group-hover:scale-105 transition-transform">
              <Coins className="h-6 w-6 text-amber-600 animate-pulse-slow font-black" />
            </div>
            <div>
              <span className="block text-[10px] uppercase font-mono tracking-wider text-amber-800 font-extrabold">Akumulasi Poin Anda</span>
              <span className="block font-fredoka text-2xl sm:text-3xl font-bold text-[#1A4A0A]">+{pointsEarned} POIN</span>
              <span className="block text-[10px] text-[#5A7A50] leading-none">Diperoleh dari pemindaian</span>
            </div>
          </div>

        </div>

        {/* Level Progression & Badges Inventory Panel */}
        <div className="bg-[#F4FAF0] p-5 sm:p-7 rounded-[2.5rem] border border-[#E0F0D8]" id="level-progression-section">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6" id="level-progression-panel">
          
          {/* Card 1: Active Level & Progress Bar (Takes 7/12 cols) */}
          <div className="md:col-span-12 lg:col-span-7 p-6 rounded-[2rem] border border-[#E0F0D8] relative overflow-hidden bg-white shadow-sm flex flex-col justify-between">
            
            {/* Ambient Level-dependent glowing gradient in the background */}
            {(() => {
              const currentLvl = getLevelInfo(points);
              const nextLvl = getNextLevelInfo(points);
              const pct = getPercentageToNextLevel(points);
              const pointsNeeded = nextLvl ? (nextLvl.minPoints - points) : 0;
              
              return (
                <>
                  <div className={`absolute top-0 right-0 w-48 h-48 bg-gradient-to-br ${currentLvl.gradient} opacity-20 rounded-full blur-2xl -z-10`} />

                  <div className="space-y-5">
                    
                    {/* Level Tag Header info */}
                    <div className="flex items-center space-x-4">
                      {/* Big glossy avatar bubble with spring bounce animation */}
                      <motion.div
                        animate={{ y: [0, -4, 0] }}
                        transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
                        className="w-20 h-20 bg-emerald-50 rounded-2xl flex items-center justify-center text-4xl shadow-md border-2 border-emerald-300 shrink-0 select-none"
                      >
                        <TrophySketch className="w-10 h-10 text-emerald-600" />
                      </motion.div>

                      <div className="space-y-1">
                        <span className="inline-block text-[10px] font-black uppercase tracking-widest text-[#FF8FA3] bg-[#FFD6DC]/30 px-2.5 py-0.5 rounded-full border border-[#FF8FA3]/25 font-nunito">
                          Tingkat Saat Ini
                        </span>
                        <h3 className="font-fredoka text-2xl font-bold text-[#1A4A0A] leading-tight">
                          {currentLvl.name}
                        </h3>
                        <p className="text-xs text-[#5A7A50] font-semibold font-nunito">
                          {currentLvl.description}
                        </p>
                      </div>
                    </div>

                    {/* Progress Slider block */}
                    <div className="space-y-2.5 pt-2 font-nunito">
                      <div className="flex items-center justify-between text-xs font-mono font-bold text-[#1A4A0A]">
                        <span className="flex items-center space-x-1.5 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-200">
                          <span>{currentLvl.minPoints} POIN</span>
                        </span>
                        <span className="font-mono text-xs font-extrabold text-[#1A4A0A] bg-[#F4FAF0] px-2.5 py-1 rounded-full border border-[#E0F0D8]">
                          {points} POIN AKTIF
                        </span>
                        {nextLvl ? (
                          <span className="flex items-center space-x-1.5 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-200">
                            <span>{nextLvl.minPoints} POIN</span>
                          </span>
                        ) : (
                          <span className="text-[10px] text-amber-900 bg-amber-50 px-2 py-1 rounded-full font-black uppercase">Maksimum</span>
                        )}
                      </div>

                      {/* Green-Pink custom progression bar */}
                      <div className="h-4 w-full bg-[#F4FAF0] border border-[#E0F0D8] rounded-full overflow-hidden shadow-inner p-0.5">
                        <motion.div
                          className="h-full bg-gradient-to-r from-[#1A4A0A] via-[#A8DF8E] to-[#FF8FA3] rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ duration: 1.2, ease: "easeOut" }}
                        />
                      </div>

                      {/* Progression status text marker */}
                      <div className="flex items-center justify-between text-[11px] font-mono font-bold text-slate-500 pt-1">
                        <span>Min: {currentLvl.minPoints}</span>
                        <span>Progression: {Math.round(pct)}%</span>
                        <span>Max: {nextLvl ? (nextLvl.minPoints - 1) : "∞"}</span>
                      </div>
                    </div>

                  </div>

                  {/* X Poin Lagi status callout banner */}
                  <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-250 font-nunito">
                    <div className="flex items-center space-x-2">
                       <div className="p-1.5 rounded-lg bg-slate-100 text-slate-700">
                        <TrendingUp className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-bold text-slate-900">
                        {nextLvl ? (
                          <>
                            Butuh <span className="text-[#1A4A0A] font-mono font-black">{pointsNeeded}</span> poin lagi menuju level <span className="font-fredoka font-bold text-[#1A4A0A]">{nextLvl.name}</span>
                          </>
                        ) : (
                          "Luar biasa! Anda telah menjabat kasta tertinggi Eco Master!"
                        )}
                      </span>
                    </div>

                    {nextLvl && (
                      <span className="text-[10px] font-mono bg-slate-100 text-[#1A4A0A] border border-[#E0F0D8] font-black uppercase py-1 px-2.5 rounded-lg shadow-sm w-fit leading-none">
                        Tingkat Berikutnya: {nextLvl.name}
                      </span>
                    )}
                  </div>
                </>
              );
            })()}

          </div>

          {/* Card 2: Badges Inventory Achievements List (Takes 5/12 cols) */}
          <div className="md:col-span-12 lg:col-span-5 p-6 rounded-[2rem] border border-[#E0F0D8] bg-white flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 pb-2 border-b border-green-50 font-nunito">
                <AwardIcon className="w-5 h-5 text-[#1A4A0A]" />
                <h4 className="font-fredoka text-lg font-bold text-[#1A4A0A]">
                  Koleksi Lencana Saya
                </h4>
              </div>

              {/* Scrollable Badges checklist container */}
              <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1 font-nunito" id="badges-achievements-checklist">
                {ECO_LEVELS.map((lvl) => {
                  const isUnlocked = points >= lvl.minPoints;
                  return (
                    <div 
                      key={lvl.id}
                      className={`flex items-center justify-between p-2.5 rounded-xl transition-all border ${
                        isUnlocked 
                          ? 'bg-white border-y-[#E0F0D8] border-r-[#E0F0D8] border-l-4 border-l-[#1A4A0A] shadow-sm' 
                          : 'bg-slate-50/60 border-slate-200/85 opacity-[0.55] select-none grayscale'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <TrophySketch className={`w-6 h-6 shrink-0 ${isUnlocked ? 'text-emerald-600' : 'text-slate-400'}`} />
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="text-xs font-extrabold text-green-950">{lvl.name}</span>
                            <span className="text-[9px] font-mono text-slate-500 bg-slate-100 px-1 py-0.2 rounded-md font-bold">
                              {lvl.minPoints}{lvl.id === 5 ? '+' : `-${lvl.maxPoints}`} pts
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-500 leading-tight line-clamp-1 max-w-[14rem]">
                            {lvl.description}
                          </p>
                        </div>
                      </div>

                      {/* Unlock indicator status */}
                      <div className="shrink-0 pl-1.5">
                        {isUnlocked ? (
                          <div className="flex items-center space-x-1 text-emerald-700 font-extrabold text-[10px]">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 fill-emerald-100" />
                            <span className="hidden sm:inline font-mono text-[9px] uppercase tracking-wide">Aktif</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-1 text-slate-400 font-bold text-[10px]">
                            <Lock className="w-3.5 h-3.5 text-slate-400" />
                            <span className="hidden sm:inline font-mono text-[9px] text-slate-500">Kunci</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          </div>

        </div>
        </div>

        {/* History table list container */}
        <div className="bg-white rounded-[2rem] border border-[#E0F0D8] p-6 shadow-md space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E0F0D8] font-nunito">
            <div className="flex items-center space-x-2">
              <History className="h-5 w-5 text-[#1A4A0A]" />
              <h2 className="font-fredoka text-lg sm:text-xl font-bold text-[#1A4A0A]">
                Riwayat Pemilahan & Daur Ulang
              </h2>
            </div>

            {logs.length > 0 && (
              <button
                onClick={onClearAllLogs}
                className="flex items-center justify-center space-x-1.5 px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-xl text-xs font-bold border border-rose-200 tracking-tight transition-all cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Hapus Semua Riwayat</span>
              </button>
            )}
          </div>

          <AnimatePresence mode="wait">
            {logs.length === 0 ? (
              <motion.div
                key="empty-ledger"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="py-12 px-4 text-center text-green-905/60 max-w-sm mx-auto flex flex-col items-center justify-center space-y-3"
              >
                <div className="p-4 rounded-full bg-green-50 text-green-700/80 mb-1">
                  <AlertCircle className="h-8 w-8 text-green-650" />
                </div>
                <p className="font-bold text-green-950 text-sm">Belum Ada Riwayat Catatan</p>
                <p className="text-xs font-medium text-green-850">
                  Sampah yang Anda pindai akan tercatat lengkap beserta perolehan poin dan foto di sini setelah diklaim dengan menekan tombol <strong>Klaim & Simpan</strong>!
                </p>
              </motion.div>
            ) : (
              <div className="overflow-x-auto relative">
                <table className="w-full text-left border-collapse min-w-[35rem]" id="log-history-table">
                  <thead>
                    <tr className="border-b border-green-100 text-[10px] uppercase font-mono tracking-wider text-green-800/85">
                      <th className="pb-3 pt-1 pl-2">Foto</th>
                      <th className="pb-3 pt-1">Nama Barang</th>
                      <th className="pb-3 pt-1 text-center">Kategori</th>
                      <th className="pb-3 pt-1">Tanggal & Waktu</th>
                      <th className="pb-3 pt-1 text-right">Poin</th>
                      <th className="pb-3 pt-1 text-center pr-2">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <AnimatePresence>
                      {logs.map((item, index) => {
                        const stylePackage = getBadgeStyleAndName(item.wasteType);
                        return (
                          <motion.tr
                            key={item.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, x: -10 }}
                            transition={{ duration: 0.2 }}
                            className="border-b border-green-50/55 hover:bg-[#E8F8E8]/20 transition-all group"
                          >
                            {/* Base64 preview photo */}
                            <td className="py-3 pl-2">
                              {item.imageUrl ? (
                                <div className="h-12 w-16 rounded-lg overflow-hidden bg-cover bg-center border border-green-100 shadow-sm relative">
                                  <img 
                                    src={item.imageUrl} 
                                    alt="gambar barang sampah" 
                                    className="h-full w-full object-cover"
                                  />
                                </div>
                              ) : (
                                <div className="h-12 w-16 rounded-lg bg-green-50 border border-green-100 flex items-center justify-center text-green-700">
                                  <Leaf className="h-5 w-5" />
                                </div>
                              )}
                            </td>

                            {/* Item Name */}
                            <td className="py-3 pr-2">
                              <span className="block font-bold text-green-950 text-sm sm:text-base leading-tight">
                                {item.itemName}
                              </span>
                              <span className="block text-[10px] uppercase font-mono text-green-700/60 leading-none mt-0.5">
                                ID: {item.id.substring(0, 8)}
                              </span>
                            </td>

                            {/* Waste Type Color coded badges */}
                            <td className="py-3 text-center">
                              <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] uppercase font-mono font-black border ${stylePackage.style}`}>
                                {stylePackage.label}
                              </span>
                            </td>

                            {/* Formatted Datestamp */}
                            <td className="py-3 text-xs text-green-900/80 font-semibold">
                              <div className="flex items-center space-x-1">
                                <Calendar className="h-3.5 w-3.5 opacity-65 shrink-0" />
                                <span>{formatDate(item.timestamp)}</span>
                              </div>
                            </td>

                            {/* Coins Awarded weight */}
                            <td className="py-3 text-right font-mono font-black text-xs text-amber-800">
                              +{item.ecoPoints} POIN
                            </td>

                            {/* Deletion control */}
                            <td className="py-3 text-center pr-2">
                              <button
                                onClick={() => onDeleteLog(item.id)}
                                className="p-2 rounded-xl text-stone-500 hover:text-red-600 hover:bg-rose-50 transition-all opacity-80 group-hover:opacity-100 cursor-pointer"
                                title="Hapus catatan ini"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </td>
                          </motion.tr>
                        );
                      })}
                    </AnimatePresence>
                  </tbody>
                </table>
              </div>
            )}
          </AnimatePresence>
        </div>

        {/* Cute Proud Green Star Mascot in the Corner */}
        <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 hidden xs:block">
          <div className="relative group">
            {/* Mascot Button */}
            <div className="w-16 h-16 sm:w-20 sm:h-20 filter drop-shadow-md cursor-pointer select-none" title="Binti!">
              <svg viewBox="0 0 100 100" className="w-full h-full transform hover:scale-110 active:scale-95 transition-transform duration-200">
                {/* Star Body */}
                <path d="M 50 12 L 61 38 L 89 38 L 66 54 L 75 80 L 50 63 L 25 80 L 34 54 L 11 38 L 39 38 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" strokeLinejoin="round" />
                
                {/* Face inside star */}
                {/* Shiny eyes */}
                <circle cx="42" cy="45" r="4.5" fill="#222222" />
                <circle cx="40.5" cy="43" r="1.5" fill="#FFFFFF" />
                <circle cx="58" cy="45" r="4.5" fill="#222222" />
                <circle cx="56.5" cy="43" r="1.5" fill="#FFFFFF" />
                
                {/* Rosy Cheeks */}
                <circle cx="36" cy="50" r="3" fill="#FF8FA3" opacity="0.8" />
                <circle cx="64" cy="50" r="3" fill="#FF8FA3" opacity="0.8" />
                
                {/* Big proud smiling mouth */}
                <path d="M 46 50 Q 50 55, 54 50" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                
                {/* Hands on waist */}
                <path d="M 32 49 Q 27 53, 32 56" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                <path d="M 68 49 Q 73 53, 68 56" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                
                {/* Mini crown on head segment */}
                <path d="M 45 13 L 50 7 L 55 13" stroke="#222222" strokeWidth="1.5" fill="none" />
                <circle cx="50" cy="5" r="1.5" fill="#FF8FA3" />
              </svg>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
