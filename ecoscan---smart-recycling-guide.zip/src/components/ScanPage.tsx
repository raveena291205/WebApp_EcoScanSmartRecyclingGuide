import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, Upload, RefreshCw, AlertTriangle, CheckCircle, 
  Leaf, Sparkles, BookOpen, Skull, GlassWater, HelpCircle, 
  ShieldAlert, Lightbulb, ChevronRight, Save, Coins, Zap
} from 'lucide-react';
import { ScanResult, WasteType } from '../types';

interface ScanPageProps {
  onAddLog: (item: { itemName: string; wasteType: WasteType; ecoPoints: number; imageUrl?: string }) => void;
  onAwardPoints: (points: number) => void;
}

export default function ScanPage({ onAddLog, onAwardPoints }: ScanPageProps) {
  // Input Selection
  const [activeTab, setActiveTab] = useState<'upload' | 'camera'>('upload');
  
  // Image State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');
  
  // Camera State
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Scan State
  const [isAnalyseLoading, setIsAnalyseLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [hasClaimed, setHasClaimed] = useState(false);

  // File drag & drop state
  const [isDragging, setIsDragging] = useState(false);

  // Mascot 1: Piko (Green Leaf) Tip list
  const pikoTips = [
    "Pisahkan sampah basah dan kering agar proses daur ulang menjadi lebih mudah",
    "Kulit jeruk dapat dimanfaatkan menjadi pembersih alami serbaguna yang harum",
    "Koran bekas bisa disulap menjadi keranjang anyaman bernilai estetika tinggi",
    "Kaleng bekas cat atau susu bisa dicat ulang menjadi wadah pot bunga cantik",
    "Kardus bekas bisa dijadikan mainan edukatif yang menyenangkan untuk anak-anak",
    "Rancang kompos mandiri di rumah menggunakan sisa sayuran organik dapur Anda",
    "Cangkang telur dapat ditumbuk halus untuk memberikan tambahan nutrisi bagi tanaman",
    "Daur ulang botol kaca wadah cairan untuk dekorasi vas bunga air minimalis",
    "Kardus telur (egg carton) merupakan wadah semai benih tanaman yang sangat ideal"
  ];
  const [pikoTipIdx, setPikoTipIdx] = useState(0);

  const rotatePikoTip = () => {
    setPikoTipIdx((prev) => (prev + 1) % pikoTips.length);
  };

  // Mascot 2: Reko (Blue Earth) Tip list
  const rekoTips = [
    "Bawa botol minum isi ulang sendiri untuk kurangi timbulan sampah plastik sekali pakai",
    "Kulit pisang dapat difermentasi menghasilkan pupuk tanaman alami berkalium tinggi",
    "Selalu pisahkan sampah kertas kering agar serat seluloranya aman didaur ulang",
    "Sampah kaca dapat dilebur kembali menjadi kaca baru tanpa mengurangi nilai kualitasnya",
    "Gunakan tas belanja kain yang tahan lama untuk menjaga kebersihan laut dari plastik",
    "Cabut pengisi daya ponsel dari stopkontak saat selesai digunakan demi efisiensi listrik",
    "Biasakan membawa wadah bekal sendiri saat memesan makanan luar guna mengurangi kemasan",
    "Membeli baju bekas layak pakai mendukung industri fesyen ramah lingkungan berkelanjutan",
    "Kumpulkan minyak jelantah sisa dapur untuk disalurkan ke lembaga pengolah biofuel resmi"
  ];
  const [rekoTipIdx, setRekoTipIdx] = useState(0);

  const rotateRekoTip = () => {
    setRekoTipIdx((prev) => (prev + 1) % rekoTips.length);
  };

  const [showSpeechBubble] = useState(true);

  // Slogans untuk loader
  const loadingSteps = [
    "Mengunggah gambar sampah ke Server EcoScan...",
    "Kecerdasan Buatan Gemini AI menganalisis kandungan material...",
    "Memeriksa standar klasifikasi daur ulang ekosistem Indonesia...",
    "Merumuskan alternatif kreasi daur ulang (upcycling) yang kreatif...",
    "Menyelesaikan kalkulasi perolehan Poin Eco..."
  ];

  // Rotate loading text
  useEffect(() => {
    let interval: any;
    if (isAnalyseLoading) {
      interval = setInterval(() => {
        setLoadingStep((prev) => (prev < loadingSteps.length - 1 ? prev + 1 : 0));
      }, 2500);
    } else {
      setLoadingStep(0);
    }
    return () => clearInterval(interval);
  }, [isAnalyseLoading]);

  // Handle Drag Over
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    handleDragLeaveState();
  };

  const handleDragLeaveState = () => {
    setIsDragging(false);
  };

  // Convert files to base64
  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert("Silakan unggah jenis file gambar yang valid.");
      return;
    }
    setImageMime(file.type);
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Camera Actions
  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' } // focus on rear camera if mobile
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setCameraActive(true);
      }
    } catch (err: any) {
      console.error("Camera access failed:", err);
      setCameraError("Aktivasi kamera gagal. Pastikan izin kamera sudah diberikan atau beralihlah ke Unggah File manual.");
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  // Turn off stream on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const triggerCameraMode = () => {
    setActiveTab('camera');
    setSelectedImage(null);
    startCamera();
  };

  const triggerUploadMode = () => {
    stopCamera();
    setActiveTab('upload');
    setSelectedImage(null);
  };

  const captureSnapshot = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setSelectedImage(dataUrl);
        setImageMime('image/jpeg');
        stopCamera();
      }
    }
  };

  // Analyze API request
  const handleAnalyzeWaste = async () => {
    if (!selectedImage) return;
    setIsAnalyseLoading(true);
    setScanError(null);
    setScanResult(null);
    setHasClaimed(false);

    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: selectedImage,
          mimeType: imageMime
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Gagal menghubungi server analisis.");
      }

      const data: ScanResult = await response.json();
      setScanResult(data);
    } catch (error: any) {
      console.error(error);
      setScanError(error.message || "Terjadi kesalahan analisis kecerdasan buatan. Silakan coba kembali!");
    } finally {
      setIsAnalyseLoading(false);
    }
  };

  // Claim Points & Save
  const handleClaimPoints = () => {
    if (!scanResult) return;
    onAddLog({
      itemName: scanResult.itemName,
      wasteType: scanResult.wasteType,
      ecoPoints: scanResult.ecoPoints,
      imageUrl: selectedImage || undefined
    });
    onAwardPoints(scanResult.ecoPoints);
    setHasClaimed(true);
  };

  // Reset Scan Card
  const handleResetScan = () => {
    setSelectedImage(null);
    setScanResult(null);
    setScanError(null);
    setHasClaimed(false);
    if (activeTab === 'camera') {
      startCamera();
    }
  };

  // Style attributes based on Waste Category
  const getCategoryTheme = (type: WasteType) => {
    switch (type) {
      case 'organic':
        return {
          icon: Leaf,
          label: 'Sampah Organik',
          bg: 'bg-emerald-50 border-emerald-200 text-emerald-800',
          badgeBg: 'bg-emerald-600',
          gradient: 'from-emerald-50 to-green-100',
          borderColor: 'border-emerald-300'
        };
      case 'plastic':
        return {
          icon: Sparkles,
          label: 'Sampah Plastik',
          bg: 'bg-[#FFD6DC]/60 border-[#FF8FA3]/30 text-rose-800',
          badgeBg: 'bg-[#FF8FA3]',
          gradient: 'from-[#FFD6DC]/40 to-[#FF8FA3]/20',
          borderColor: 'border-[#FF8FA3]/40'
        };
      case 'paper':
        return {
          icon: BookOpen,
          label: 'Sampah Kertas',
          bg: 'bg-amber-50 border-amber-200 text-amber-800',
          badgeBg: 'bg-amber-500',
          gradient: 'from-amber-50 to-orange-100/30',
          borderColor: 'border-amber-300'
        };
      case 'metal':
        return {
          icon: ShieldAlert,
          label: 'Sampah Logam',
          bg: 'bg-sky-50 border-sky-200 text-sky-800',
          badgeBg: 'bg-sky-500',
          gradient: 'from-sky-50 to-blue-100',
          borderColor: 'border-sky-300'
        };
      case 'glass':
        return {
          icon: GlassWater,
          label: 'Sampah Kaca',
          bg: 'bg-purple-50 border-purple-200 text-purple-800',
          badgeBg: 'bg-purple-500',
          gradient: 'from-purple-50 to-fuchsia-100/30',
          borderColor: 'border-purple-300'
        };
      case 'B3':
        return {
          icon: Skull,
          label: 'Limbah B3 (Berbahaya)',
          bg: 'bg-rose-50 border-rose-200 text-rose-950',
          badgeBg: 'bg-rose-600',
          gradient: 'from-rose-50 to-red-100/50',
          borderColor: 'border-rose-300'
        };
      default:
        return {
          icon: HelpCircle,
          label: 'Sampah Lainnya',
          bg: 'bg-gray-50 border-gray-200 text-gray-800',
          badgeBg: 'bg-gray-500',
          gradient: 'from-gray-50 to-slate-100',
          borderColor: 'border-gray-300'
        };
    }
  };

  return (
    <div className="w-full relative min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8 flex items-center justify-center overflow-hidden bg-[#F4FAF0]" id="scan-page-root">
      
      {/* Decorative Blur Blobs representing Design specifications */}
      <div className="absolute top-20 left-12 w-64 h-64 bg-[#A8DF8E]/20 rounded-full blur-3xl -z-10 animate-float-slow" />
      <div className="absolute bottom-20 right-12 w-80 h-80 bg-[#FFD6DC]/35 rounded-full blur-3xl -z-10 animate-float-reverse" />

      <div className="w-full max-w-4xl mx-auto flex flex-col space-y-6">
        
        {/* Responsive Dual Mascot Hero Header */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10 w-full mb-2 p-6 md:p-8 rounded-[2.5rem] border border-[#E0F0D8] bg-[linear-gradient(135deg,#E8F5E0_50%,#ffffff_50%)] shadow-md overflow-hidden">
          
          {/* Left Mascot (Piko the Leaf) - Hidden on mobile view, shown on desktop sides */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" onClick={rotatePikoTip} title="Klik saya untuk tips daur ulang dari Piko!">
              {/* Speech bubble */}
              <AnimatePresence mode="wait">
                {showSpeechBubble && (
                  <motion.div
                    key={pikoTipIdx}
                    initial={{ opacity: 0, scale: 0.8, y: 15 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8, y: -5 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="absolute -top-16 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-4 py-2 rounded-2xl text-xs shadow-md border border-[#A8DF8E]/40 w-48 text-center z-20 hover:scale-103 transition-all duration-200"
                  >
                    <p className="leading-snug text-green-950 font-semibold">{pikoTips[pikoTipIdx]}</p>
                    <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Piko Leaf SVG Wrapper */}
              <div className="relative mt-12 text-center">
                <div className="absolute inset-0 bg-[#A8DF8E]/20 rounded-full blur-xl group-hover:bg-[#FFD6DC]/20 transition-colors duration-300 -z-10" />
                <svg viewBox="0 0 160 160" className="w-24 h-24 sm:w-28 sm:h-28 mx-auto filter drop-shadow-md animate-float-slow select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                  {/* Stem on top of head */}
                  <path d="M 80 30 C 85 15, 95 10, 95 10" stroke="#4D7C0F" strokeWidth="3" strokeLinecap="round" fill="none" />
                  
                  {/* Leaf Body (Beautiful green leaf shape) */}
                  <path d="M 80 25 C 120 50, 125 110, 80 145 C 35 110, 40 50, 80 25 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" />
                  
                  {/* Leaf Veins */}
                  <path d="M 80 25 L 80 145" stroke="#4D7C0F" strokeWidth="2.5" strokeLinecap="round" opacity="0.6" strokeDasharray="3 3" />
                  <path d="M 80 60 Q 100 50, 110 45" stroke="#4D7C0F" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
                  <path d="M 80 60 Q 60 50, 50 45" stroke="#4D7C0F" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
                  <path d="M 80 90 Q 105 80, 115 75" stroke="#4D7C0F" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
                  <path d="M 80 90 Q 55 80, 45 75" stroke="#4D7C0F" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
                  <path d="M 80 120 Q 100 110, 110 105" stroke="#4D7C0F" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
                  <path d="M 80 120 Q 60 110, 50 105" stroke="#4D7C0F" strokeWidth="2" strokeLinecap="round" opacity="0.6" />

                  {/* Hands (Cute tiny twigs) */}
                  {/* Left hand holding a flowers */}
                  <path d="M 45 95 Q 30 100, 32 90" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                  {/* Right hand waving */}
                  <path d="M 115 95 Q 130 90, 128 80" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />

                  {/* Small flower in hand */}
                  <circle cx="28" cy="88" r="4" fill="#FF8FA3" />
                  <circle cx="28" cy="88" r="1.5" fill="#FACC15" />

                  {/* Left Eye: Cute Winking Arc */}
                  <path d="M 58 78 Q 66 68, 74 78" stroke="#222222" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                  {/* Right Eye: Generous Open Eye */}
                  <circle cx="98" cy="76" r="6.5" fill="#222222" />
                  <circle cx="96" cy="73" r="2.2" fill="#FFFFFF" />
                  <circle cx="100.2" cy="78" r="1" fill="#FFFFFF" />

                  {/* Rosy Cheeks */}
                  <ellipse cx="58" cy="88" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />
                  <ellipse cx="102" cy="88" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />

                  {/* Cute Mouth: Adorable cat-mouth ':3' style */}
                  <path d="M 76 86 Q 79 90, 81 86 Q 83 90, 86 86" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />

                  {/* Feet */}
                  <path d="M 70 144 Q 68 152, 58 151" stroke="#3F6212" strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  <path d="M 90 144 Q 92 152, 102 151" stroke="#3F6212" strokeWidth="3.5" strokeLinecap="round" fill="none" />
                </svg>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-lime-800 bg-[#E8F8E8] px-2 py-0.5 rounded-full border border-lime-300/40 shadow-sm">
                    Ketuk Piko
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Main Hero text */}
          <div className="flex-1 text-center py-2 space-y-3 z-10">
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-white/90 text-[#1A4A0A] border border-[#A8DF8E]/40 text-xs font-bold uppercase tracking-wider"
            >
              <Zap className="h-3 w-3 text-[#1A4A0A] animate-pulse" />
              <span className="font-fredoka">Pendeteksi Sampah Berbasis AI</span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="font-fredoka text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#1A4A0A] leading-tight"
            >
              Pindai Sampah, <span className="text-[#FF8FA3]">Bumi Lestari</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-xs sm:text-sm md:text-base text-[#5A7A50] max-w-xl mx-auto font-nunito font-semibold leading-relaxed"
            >
              Unggah foto sampah Anda atau ambil gambar langsung menggunakan kamera untuk menganalisis kandungannya secara cerdas. Temukan cara pengelolaan, ide kreasi daur ulang, serta raih poin eco instan!
            </motion.p>
          </div>

          {/* Right Mascot (Reko the Earth) - Hidden on mobile view, shown on desktop sides */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" onClick={rotateRekoTip} title="Klik saya untuk tips lingkungan dari Reko!">
              {/* Speech bubble */}
              <AnimatePresence mode="wait">
                {showSpeechBubble && (
                  <motion.div
                    key={rekoTipIdx}
                    initial={{ opacity: 0, scale: 0.8, y: 15 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8, y: -5 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="absolute -top-16 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-4 py-2 rounded-2xl text-xs shadow-md border border-[#A8DF8E]/40 w-48 text-center z-20 hover:scale-103 transition-all duration-200"
                  >
                    <p className="leading-snug text-green-950 font-semibold">{rekoTips[rekoTipIdx]}</p>
                    <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Reko Earth SVG Wrapper */}
              <div className="relative mt-12 text-center">
                <div className="absolute inset-0 bg-[#A8DF8E]/25 rounded-full blur-xl group-hover:bg-[#FF8FA3]/25 transition-colors duration-300 -z-10" />
                <svg viewBox="0 0 160 160" className="w-24 h-24 sm:w-28 sm:h-28 mx-auto filter drop-shadow-md animate-float-slow select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                  {/* Sprout on head */}
                  <path d="M 80 40 C 80 25, 95 15, 95 15 C 95 15, 82 23, 80 32" stroke="#55AD47" strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  <path d="M 80 38 C 78 22, 63 15, 63 15 C 63 15, 76 21, 80 31" stroke="#55AD47" strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  <path d="M 80,45 C 80,41, 80,35, 80,35" stroke="#715C46" strokeWidth="3" strokeLinecap="round" />
                  
                  {/* Sprout leaves fill */}
                  <path d="M 80 35 C 80 25, 95 15, 95 15 C 80 22, 80 35, 80 35" fill="#A8DF8E" opacity="0.9" />
                  <path d="M 80 35 C 78 22, 63 15, 63 15 C 78 20, 80 35, 80 35" fill="#A8DF8E" opacity="0.9" />

                  {/* Cute Earth Body */}
                  <circle cx="80" cy="90" r="45" fill="#7BC9FF" stroke="#333333" strokeWidth="3" />
                  
                  {/* Continents/Land (Green) */}
                  <path d="M 50 70 A 45 45 0 0 0 45 110 C 50 115, 60 110, 62 100 C 64 90, 58 80, 50 70 Z" fill="#9ADE7B" stroke="#333333" strokeWidth="1" />
                  <path d="M 105 70 A 45 45 0 0 1 115 110 C 110 115, 100 110, 98 100 C 96 90, 102 80, 105 70 Z" fill="#9ADE7B" stroke="#333333" strokeWidth="1" />
                  <path d="M 70 120 C 75 125, 85 130, 90 125 C 95 120, 90 135, 80 135 A 45 45 0 0 1 70 120 Z" fill="#9ADE7B" stroke="#333333" strokeWidth="1" />
                  <path d="M 65 60 C 72 55, 88 55, 95 60 C 92 65, 80 62, 75 68 C 70 72, 68 65, 65 60 Z" fill="#9ADE7B" stroke="#333333" strokeWidth="1" />

                  {/* Little hands */}
                  <path d="M 33 92 C 22 88, 18 78, 22 74 C 26 70, 30 78, 36 86" fill="#7BC9FF" stroke="#333333" strokeWidth="2.5" strokeLinecap="round" />
                  <path d="M 127 92 C 135 90, 142 94, 142 98 C 142 102, 134 102, 126 95" fill="#7BC9FF" stroke="#333333" strokeWidth="2.5" strokeLinecap="round" />
                  
                  {/* Little feet */}
                  <ellipse cx="60" cy="136" rx="10" ry="7" fill="#7BC9FF" stroke="#333333" strokeWidth="2.5" />
                  <ellipse cx="100" cy="136" rx="10" ry="7" fill="#7BC9FF" stroke="#333333" strokeWidth="2.5" />

                  {/* Recycled leaf in hand */}
                  <path d="M 140 96 C 148 90, 154 94, 150 102 C 145 106, 138 100, 140 96" fill="#A8DF8E" stroke="#333333" strokeWidth="1.5" />

                  {/* Eyes: Happy open eyes (different expression!) */}
                  <circle cx="68" cy="88" r="6" fill="#222222" />
                  <circle cx="66" cy="85" r="2.2" fill="#FFFFFF" />
                  <circle cx="70.2" cy="90.2" r="1" fill="#FFFFFF" />
                  
                  <circle cx="92" cy="88" r="6" fill="#222222" />
                  <circle cx="90" cy="85" r="2.2" fill="#FFFFFF" />
                  <circle cx="94.2" cy="90.2" r="1" fill="#FFFFFF" />

                  {/* Rosy Cheeks */}
                  <ellipse cx="58" cy="96" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />
                  <ellipse cx="102" cy="96" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />

                  {/* Smiling Mouth */}
                  <path d="M 76 96 Q 80 101, 84 96" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                </svg>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-blue-800 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-300/40 shadow-sm">
                    Ketuk Reko
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* MOBILE MASCOT ROW: Displays side-by-side on mobile screens below/within hero layout to save height & avoid scrolling */}
          <div className="flex md:hidden items-center justify-center gap-8 w-full select-none pt-2 border-t border-dotted border-[#A8DF8E]/30">
            
            {/* Piko on mobile */}
            <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer" onClick={rotatePikoTip}>
              {/* Compact speech bubble for mobile */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={pikoTipIdx}
                  initial={{ opacity: 0, scale: 0.8, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: -5 }}
                  className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-3 py-1.5 rounded-xl text-[10px] shadow border border-[#A8DF8E]/40 w-36 text-center z-20"
                >
                  <p className="leading-snug text-green-950 font-semibold text-center">{pikoTips[pikoTipIdx]}</p>
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                </motion.div>
              </AnimatePresence>

              {/* Smaller SVG wrapper */}
              <div className="relative mt-10">
                <svg viewBox="0 0 160 160" className="w-16 h-16 filter drop-shadow animate-float-slow select-none">
                  {/* Stem */}
                  <path d="M 80 30 C 85 15, 95 10, 95 10" stroke="#4D7C0F" strokeWidth="3.5" fill="none" />
                  {/* Leaf */}
                  <path d="M 80 25 C 120 50, 125 110, 80 145 C 35 110, 40 50, 80 25 Z" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" />
                  <path d="M 80 25 L 80 145" stroke="#4D7C0F" strokeWidth="2.5" opacity="0.6" strokeDasharray="3 3" />
                  {/* Left Eye Wink */}
                  <path d="M 58 78 Q 66 68, 74 78" stroke="#222222" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                  {/* Right Eye */}
                  <circle cx="98" cy="76" r="6.5" fill="#222222" />
                  {/* Rosy cheeks */}
                  <ellipse cx="58" cy="88" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />
                  <ellipse cx="102" cy="88" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />
                  {/* Cat mouth */}
                  <path d="M 76 86 Q 79 90, 81 86 Q 83 90, 86 86" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-lime-800 bg-[#E8F8E8] px-1.5 py-0.2 rounded-full border border-lime-300/30">
                    Piko
                  </span>
                </div>
              </div>
            </div>

            {/* Reko on mobile */}
            <div className="flex flex-col items-center max-w-[120px] relative cursor-pointer" onClick={rotateRekoTip}>
              {/* Compact speech bubble for mobile */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={rekoTipIdx}
                  initial={{ opacity: 0, scale: 0.8, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, y: -5 }}
                  className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white text-green-950 font-bold px-3 py-1.5 rounded-xl text-[10px] shadow border border-[#A8DF8E]/40 w-36 text-center z-20"
                >
                  <p className="leading-snug text-green-950 font-semibold text-center">{rekoTips[rekoTipIdx]}</p>
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-white border-r border-b border-[#A8DF8E]/30 rotate-45" />
                </motion.div>
              </AnimatePresence>

              {/* Smaller SVG wrapper */}
              <div className="relative mt-10">
                <svg viewBox="0 0 160 160" className="w-16 h-16 filter drop-shadow animate-float-reverse select-none">
                  <circle cx="80" cy="90" r="45" fill="#7BC9FF" stroke="#333333" strokeWidth="3" />
                  <path d="M 50 70 A 45 45 0 0 0 45 110 C 50 115, 60 110, 62 100 Z" fill="#9ADE7B" stroke="#333333" strokeWidth="1" />
                  <path d="M 105 70 A 45 45 0 0 1 115 110 C 110 115, 100 110, 98 100 Z" fill="#9ADE7B" stroke="#333333" strokeWidth="1" />
                  <circle cx="68" cy="88" r="6" fill="#222222" />
                  <circle cx="92" cy="88" r="6" fill="#222222" />
                  <ellipse cx="58" cy="96" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />
                  <ellipse cx="102" cy="96" rx="5" ry="3.5" fill="#FF8FA3" opacity="0.8" />
                  <path d="M 76 96 Q 80 101, 84 96" stroke="#222222" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-blue-800 bg-blue-50 px-1.5 py-0.2 rounded-full border border-blue-300/30">
                    Reko
                  </span>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Normal Operations Grid */}
        <AnimatePresence mode="wait">
          {!scanResult && !isAnalyseLoading && (
            <motion.div
              key="interaction-card"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="glass-panel rounded-3xl border border-[#E0F0D8] p-6 shadow-xl relative overflow-hidden bg-white"
              id="eco-scan-interaction-card"
            >
              {/* Toggles */}
              <div className="flex bg-[#F4FAF0] p-1.5 rounded-2xl w-fit mx-auto mb-6 border border-[#E0F0D8]">
                <button
                  onClick={triggerUploadMode}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 ${
                    activeTab === 'upload'
                      ? 'bg-[#1A4A0A] text-white shadow-sm'
                      : 'text-[#5A7A50] hover:text-[#1A4A0A]'
                  }`}
                >
                  <Upload className="h-4 w-4" />
                  <span className="font-fredoka">Unggah Berkas</span>
                </button>
                <button
                  onClick={triggerCameraMode}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 ${
                    activeTab === 'camera'
                      ? 'bg-[#1A4A0A] text-white shadow-sm'
                      : 'text-[#5A7A50] hover:text-[#1A4A0A]'
                  }`}
                >
                  <Camera className="h-4 w-4" />
                  <span className="font-fredoka">Ambil Foto</span>
                </button>
              </div>

              {/* Upload interface */}
              {activeTab === 'upload' && (
                <div className="space-y-4">
                  {!selectedImage ? (
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      className={`h-64 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center p-6 text-center cursor-pointer transition-all duration-300 ${
                        isDragging 
                          ? 'border-[#FF8FA3] bg-[#FFF0F3] scale-[1.01]' 
                          : 'border-[#1A4A0A] hover:border-[#A8DF8E] bg-[#F4FAF0] hover:bg-[#E8F5E0]/20'
                      }`}
                    >
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        id="eco-upload-input"
                        onChange={handleFileChange}
                      />
                      <label htmlFor="eco-upload-input" className="cursor-pointer flex flex-col items-center">
                        <div className="p-4 rounded-full bg-white shadow-sm text-green-700/80 mb-3 group-hover:scale-105 transition-all">
                          <Upload className="h-8 w-8 text-[#1A4A0A] animate-bounce" />
                        </div>
                        <span className="font-fredoka font-bold text-[#1A4A0A] text-sm sm:text-base">
                          Seret dan letakkan foto sampah Anda di sini, atau <span className="text-[#FF8FA3] underline">pilih file</span>
                        </span>
                        <span className="text-xs text-[#5A7A50] mt-1 font-nunito">
                          Mendukung format PNG, JPG, atau WEBP hingga ukuran 10MB
                        </span>
                      </label>
                    </div>
                  ) : (
                    <div className="relative rounded-2xl overflow-hidden bg-black/5 aspect-video md:max-h-72 flex items-center justify-center">
                      <img 
                        src={selectedImage} 
                        alt="Pratinjau barang sampah" 
                        className="object-contain h-full w-full max-h-72"
                      />
                      <button
                        onClick={() => setSelectedImage(null)}
                        className="absolute top-3 right-3 p-2 rounded-full bg-white/90 text-red-600 shadow-md hover:bg-white hover:scale-105 transition-all"
                        title="Hapus gambar"
                      >
                        <RefreshCw className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Camera interface */}
              {activeTab === 'camera' && (
                <div className="space-y-4">
                  {cameraError ? (
                    <div className="p-6 bg-red-50 border border-red-200 rounded-2xl text-center text-red-800 flex flex-col items-center justify-center space-y-2">
                      <AlertTriangle className="h-8 w-8 text-red-500" />
                      <p className="font-bold">Aktivasi Kamera Gagal</p>
                      <p className="text-xs">{cameraError}</p>
                      <button 
                        onClick={startCamera}
                        className="px-4 py-2 bg-red-100 hover:bg-red-200 text-red-900 rounded-xl text-xs font-semibold mt-2 transition-all"
                      >
                         Coba Aktifkan Kembali Kamera
                      </button>
                    </div>
                  ) : !selectedImage ? (
                    <div className="relative rounded-2xl overflow-hidden bg-black/90 aspect-video md:max-h-[30rem] flex flex-col items-center justify-center group border border-[#A8DF8E]/30 text-white">
                      <video 
                        ref={videoRef}
                        className="w-full h-full object-cover"
                        playsInline
                        muted
                      />
                      <div className="absolute bottom-4 left-0 right-0 flex justify-center items-center space-x-3">
                        <button
                          onClick={captureSnapshot}
                          className="px-6 py-2.5 rounded-xl bg-[#FF8FA3] hover:bg-[#FF8FA3]/90 text-white font-bold flex items-center space-x-2 shadow-lg hover:scale-105 transition-all animate-pulse-slow cursor-pointer"
                        >
                          <Camera className="h-4 w-4" />
                          <span>Ambil Foto</span>
                        </button>
                        <button
                          onClick={stopCamera}
                          className="px-4 py-2.5 rounded-xl bg-white/25 hover:bg-white/40 text-white text-xs font-medium backdrop-blur-sm"
                        >
                          Matikan Kamera
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="relative rounded-2xl overflow-hidden bg-black/5 aspect-video md:max-h-72 flex items-center justify-center">
                      <img 
                        src={selectedImage} 
                        alt="Hasil pengambilan foto" 
                        className="object-contain h-full w-full max-h-72"
                      />
                      <button
                        onClick={() => {
                          setSelectedImage(null);
                          startCamera();
                        }}
                        className="absolute top-3 right-3 p-2.5 rounded-full bg-white/95 text-green-700 shadow-md hover:bg-white hover:scale-105 transition-all cursor-pointer"
                        title="Foto ulang"
                      >
                        <RefreshCw className="h-4.5 w-4.5" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Error warning */}
              {scanError && (
                <div className="mt-4 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-sm flex items-start space-x-2">
                  <AlertTriangle className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block text-rose-955 text-rose-950">Pemindaian Gagal</span>
                    <span>{scanError}</span>
                  </div>
                </div>
              )}

              {/* Action execute button */}
              {selectedImage && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 flex justify-center"
                >
                  <button
                    onClick={handleAnalyzeWaste}
                    className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-[#1A4A0A] hover:bg-[#1A4A0A]/90 text-white font-fredoka font-bold tracking-wide shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-95 transition-all duration-200 flex items-center justify-center space-x-2 cursor-pointer animate-pulse-slow"
                  >
                    <Leaf className="h-5 w-5 fill-current text-white/20" />
                    <span>Analisis Sampah dengan AI EcoScan</span>
                  </button>
                </motion.div>
              )}
            </motion.div>
          )}

          {/* Progressive loader during AI processing */}
          {isAnalyseLoading && (
            <motion.div
              key="loader-card"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="glass-panel rounded-3xl border border-[#A8DF8E]/40 p-8 flex flex-col items-center justify-center text-center space-y-6 h-96 shadow-lg relative overflow-hidden bg-white/60"
            >
              {/* Spinning eco particle system */}
              <div className="relative">
                <div className="w-20 h-20 rounded-full border-4 border-green-200 border-t-[#A8DF8E] animate-spin" />
                <Leaf className="h-8 w-8 text-green-600 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-bounce" />
              </div>

              <div className="space-y-2 max-w-md">
                <AnimatePresence mode="wait">
                  <motion.p
                    key={loadingStep}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.3 }}
                    className="font-bold text-green-950 text-base md:text-lg leading-relaxed"
                  >
                    {loadingSteps[loadingStep]}
                  </motion.p>
                </AnimatePresence>
                <p className="text-xs text-green-800/60 italic font-mono uppercase tracking-wider">
                  Menganalisis menggunakan Model Gemini 3.5 Flash
                </p>
              </div>

              {/* Progress dots */}
              <div className="flex space-x-1.5">
                {loadingSteps.map((_, i) => (
                  <div
                    key={i}
                    className={`h-2.5 w-2.5 rounded-full transition-all duration-300 ${
                      i === loadingStep ? 'bg-[#FF8FA3] w-6' : 'bg-green-200'
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          )}

          {/* Elegant color-coded Result displays */}
          {scanResult && !isAnalyseLoading && (
            <motion.div
              key="result-card"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-6 w-full"
            >
              <div className="glass-panel rounded-3xl border border-[#A8DF8E]/30 p-6 sm:p-8 shadow-xl relative overflow-hidden bg-white/90">
                
                {/* Result header banner */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-green-100 mb-6">
                  <div className="flex items-center space-x-4">
                    {/* Tiny thumbnail frame representing design specs */}
                    {selectedImage && (
                      <div className="h-16 w-16 min-w-16 rounded-xl overflow-hidden bg-cover bg-center border border-green-200 hidden sm:block shadow-sm">
                        <img src={selectedImage} alt="thumbnail foto sampah" className="h-full w-full object-cover" />
                      </div>
                    )}
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className={`text-[10px] sm:text-xs font-mono font-black uppercase tracking-widest text-white px-2.5 py-0.5 rounded-full ${getCategoryTheme(scanResult.wasteType).badgeBg}`}>
                          {getCategoryTheme(scanResult.wasteType).label}
                        </span>
                      </div>
                      <h2 className="font-serif text-2xl sm:text-3xl font-extrabold text-green-950 mt-1 leading-snug">
                        {scanResult.itemName}
                      </h2>
                    </div>
                  </div>

                  {/* Points Claim Indicator */}
                  <div className="flex items-center space-x-2 bg-gradient-to-r from-[#FFD6DC] to-[#FF8FA3] text-red-950 px-4 py-2 rounded-2xl border border-[#FF8FA3]/20 shadow-sm w-fit self-start md:self-auto">
                    <Coins className="h-5 w-5 text-red-900" />
                    <div>
                      <span className="block text-[9px] uppercase tracking-wider leading-none opacity-85 font-black">Penghargaan Poin</span>
                      <span className="block font-mono font-black text-lg">+{scanResult.ecoPoints} POIN</span>
                    </div>
                  </div>
                </div>

                {/* Grid layout sections */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Disposal Column */}
                  <div className="space-y-6">
                    {/* Method card */}
                    <div className="rounded-2xl bg-white/80 border border-green-100 p-5 space-y-3 shadow-sm hover:shadow-md transition-all">
                      <div className="flex items-center space-x-2.5">
                        <div className="p-2 rounded-xl bg-green-100 text-green-800">
                          <Leaf className="h-5 w-5" />
                        </div>
                        <h3 className="font-black text-green-950 text-base">Panduan Cara Pembuangan</h3>
                      </div>
                      <p className="text-sm text-green-950/85 leading-relaxed whitespace-pre-line pl-1 font-medium">
                        {scanResult.disposalMethod}
                      </p>
                    </div>

                    {/* Env threat alert card */}
                    <div className="rounded-2xl bg-rose-50/70 border border-rose-200/50 p-5 space-y-2 shadow-sm">
                      <div className="flex items-center space-x-2.5 text-rose-900">
                        <div className="p-2 rounded-xl bg-rose-100 text-rose-700">
                          <Skull className="h-5 w-5" />
                        </div>
                        <h3 className="font-black text-rose-950 text-base">Dampak Terhadap Lingkungan</h3>
                      </div>
                      <p className="text-sm text-rose-900/95 leading-relaxed pl-1 font-semibold">
                        {scanResult.environmentalImpact}
                      </p>
                    </div>
                  </div>

                  {/* Upcycling column */}
                  <div className="space-y-6">
                    {/* Recycling/upcycling list box */}
                    <div className="rounded-2xl bg-gradient-to-b from-white/90 to-white/60 border border-green-100 p-5 space-y-4 shadow-sm">
                      <div className="flex items-center space-x-2.5">
                        <div className="p-2 rounded-xl bg-[#FFD6DC] text-[#FF8FA3]">
                          <Lightbulb className="h-5 w-5 fill-current text-rose-500/10" />
                        </div>
                        <h3 className="font-black text-green-950 text-base">Ide Kerajinan Daur Ulang Kreatif (Upcycle)</h3>
                      </div>
                      
                      <div className="space-y-3.5">
                        {scanResult.recyclingTips.map((tip, index) => (
                          <div key={index} className="flex items-start space-x-3 group">
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E8F8E8] text-green-700 text-xs font-black group-hover:bg-[#FFD6DC] transition-all">
                              {index + 1}
                            </span>
                            <span className="text-sm text-green-950/90 leading-normal font-semibold">
                              {tip}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Recyclability stamp widget */}
                    <div className={`p-4 rounded-xl border flex items-center justify-between ${
                      scanResult.isRecyclable 
                        ? 'bg-[#E8F8E8]/50 border-emerald-200 text-emerald-800' 
                        : 'bg-amber-50/50 border-amber-200 text-amber-800'
                    }`}>
                      <div className="flex items-center space-x-2">
                        {scanResult.isRecyclable ? (
                          <CheckCircle className="h-5 w-5 text-emerald-600" />
                        ) : (
                          <AlertTriangle className="h-5 w-5 text-amber-600" />
                        )}
                        <div>
                          <span className="block text-xs uppercase font-extrabold tracking-wide">Status Daur Ulang Mandiri</span>
                          <span className="text-xs font-medium">
                            {scanResult.isRecyclable 
                              ? 'Sangat dapat didaur ulang / dikreasikan di ekosistem Indonesia' 
                              : 'Memiliki keterbatasan fasilitas infrastruktur daur ulang domestik'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions banner */}
                <div className="mt-8 pt-6 border-t border-green-100 flex flex-col sm:flex-row gap-4 items-center justify-between">
                  <button
                    onClick={handleResetScan}
                    className="w-full sm:w-auto flex items-center justify-center space-x-2 px-5 py-3 rounded-xl border border-green-200 text-green-800 hover:bg-[#E8F8E8]/50 text-sm font-bold transition-all duration-200 cursor-pointer"
                  >
                    <RefreshCw className="h-4 w-4" />
                    <span>Pindai Barang Lain</span>
                  </button>

                  <AnimatePresence mode="wait">
                    {!hasClaimed ? (
                      <motion.button
                        key="claim-btn"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        onClick={handleClaimPoints}
                        className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#FF8FA3] to-red-400 hover:from-[#FF8FA3] hover:to-red-500 text-white font-extrabold shadow-md hover:shadow-lg hover:scale-[1.02] active:scale-95 transition-all duration-200 flex items-center justify-center space-x-2 cursor-pointer"
                      >
                        <Save className="h-4 w-4" />
                        <span>Klaim & Simpan (+{scanResult.ecoPoints} Poin!)</span>
                      </motion.button>
                    ) : (
                      <motion.div
                        key="saved-claimed"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="w-full sm:w-auto px-6 py-3 rounded-xl bg-emerald-600 text-white font-black text-center flex items-center justify-center space-x-2 shadow-sm"
                      >
                        <CheckCircle className="h-5 w-5 animate-bounce" />
                        <span>Poin Berhasil Diklaim & Tersimpan di Log!</span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
