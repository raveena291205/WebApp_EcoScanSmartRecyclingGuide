import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Globe, Heart, ArrowRight, X, ShieldCheck, Bookmark, 
  Share2, Search, RotateCw, Check, Award, Flame, Lightbulb, CheckCircle2 
} from 'lucide-react';
import { ECO_FACTS } from '../data';
import { LeafSketch, ClockSketch, SparklesSketch, BookSketch } from './SketchIcons';

const FACT_SOURCES: Record<number, { source: string; details: string; agency: string }> = {
  1: {
    source: "Kementerian Lingkungan Hidup dan Kehutanan (KLHK) RI & Laporan Multipihak World Bank",
    details: "Studi kolaboratif 'Indonesia Marine Plastic Waste Baseline Study' (2020) mengonfirmasi timbunan sampah plastik nasional per tahun berkisaran 6.8 juta ton dengan kebocoran ke perairan pesisir berkisar 620.000 ton.",
    agency: "KLHK RI & World Bank"
  },
  2: {
    source: "Unit Pengelola Sampah Terpadu (UPST) Dinas Lingkungan Hidup DKI Jakarta",
    details: "Data operasional harian menunjukkan TPST Bantar Gebang memproses 7.500 hingga 8.000 ton sampah per hari dari 5 wilayah administratif Jakarta, dengan puncak ketinggian kubah sampah mencapai limit kritis 40-42 meter.",
    agency: "DLH Provinsi DKI Jakarta"
  },
  3: {
    source: "Sistem Informasi Pengelolaan Sampah Nasional (SIPSN) - Kementerian LHK",
    details: "Database Kementerian LHK mencatat pertumbuhan Bank Sampah Unit dan Induk hingga melebihi 11.556 titik nasional, bekerja sama dengan entitas keuangan mikro BUMN untuk penyediaan layanan konversi emas Pegadaian.",
    agency: "SIPSN Kementerian LHK RI"
  },
  4: {
    source: "Direktorat Jenderal Industri Agro - Kementerian Perindustrian RI",
    details: "Kemenperin memandu pelaku industri hijau lokal dalam pengembangan sabut kelapa (coco coir) geopolimer dan substitusi batubara berbasis limbah kopi/biomassa sekam untuk target dekarbonisasi nasional.",
    agency: "Kementerian Perindustrian"
  },
  5: {
    source: "Laporan Inventarisasi Gas Rumah Kaca (GRK) Sektor Pengelolaan Limbah - Kementerian LHK",
    details: "Gas metana (CH4) dari pembusukan anaerobik materi organik basah di TPA berkontribusi 21 kali lebih berbahaya terhadap akumulasi pemanasan global dibanding karbon dioksida jika tidak dialirkan via flaring/uji sani.",
    agency: "Kementerian LHK & ESDM"
  },
  6: {
    source: "Peraturan Gubernur (Pergub) Daerah Khusus Ibukota Jakarta Nomor 142 Tahun 2019",
    details: "Serta Peraturan Gubernur Bali Nomor 97 Tahun 2018 tentang Pembatasan Timbulan Sampah Plastik Sekali Pakai. Memiliki payung hukum resmi dengan sanksi administratif berupa pembekuan izin ritel.",
    agency: "Pemprov DKI Jakarta & Pemprov Bali"
  },
  7: {
    source: "US Environmental Protection Agency (EPA) - WARM Benefit Metrics Database",
    details: "Rasio konversi ilmiah membuktikan daur ulang serat kertas murni mengurangi kebutuhan penebangan pohon pinus/selulosa dan menghemat energi air pulp sebesar 58% dibanding pembuatan kertas segar di pabrik semen bubur.",
    agency: "US EPA & KLHK Kehutanan"
  },
  8: {
    source: "Sungai Watch Bali-Java annual Waste Audit Report & Marine Conservancy Database",
    details: "Melalui pemasangan lebih dari 150 jaring penghalang sampah (river barriers) di perlintasan air utama, relawan mencatat audit fisik bulanan untuk mengategorikan produsen kemasan pencemar lingkungan terbesar.",
    agency: "Sungai Watch Indonesia"
  },
  9: {
    source: "Glass Packaging Association Metric Study & Pusat Standardisasi Industri Material",
    details: "Pasokan Cullet (serpihan pecahan kaca siap lebur) menurunkan titik lebur tungku pabrik kaca secara eksponensial, menghemat bahan bakar gas dan tidak melepaskan emisi berbahaya selama re-polimerisasi fisik.",
    agency: "Glass Packaging Institute"
  }
};

// Help map category tags to each fact item for precise filtering
const FACT_CATEGORIES: Record<number, string[]> = {
  1: ["Plastik", "Lautan", "Indonesia"],
  2: ["Daur Ulang", "Indonesia"],
  3: ["Daur Ulang", "Indonesia"],
  4: ["Daur Ulang", "Indonesia"],
  5: ["Energi", "Indonesia"],
  6: ["Plastik", "Indonesia"],
  7: ["Daur Ulang", "Energi"],
  8: ["Plastik", "Lautan", "Indonesia"],
  9: ["Daur Ulang"]
};

// Custom interactive Count-Up Component using Intersection Observer
interface AnimatedCounterProps {
  target: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
}

const AnimatedCounter: React.FC<AnimatedCounterProps> = ({ 
  target, 
  duration = 1000, 
  prefix = '', 
  suffix = '', 
  decimals = 0 
}) => {
  const [count, setCount] = useState(0);
  const elementRef = useRef<HTMLSpanElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      const [entry] = entries;
      if (entry.isIntersecting && !hasAnimated.current) {
        hasAnimated.current = true;
        let startTimestamp: number | null = null;
        const step = (timestamp: number) => {
          if (!startTimestamp) startTimestamp = timestamp;
          const progress = Math.min((timestamp - startTimestamp) / duration, 1);
          setCount(progress * target);
          if (progress < 1) {
            window.requestAnimationFrame(step);
          } else {
            setCount(target);
          }
        };
        window.requestAnimationFrame(step);
      }
    }, { threshold: 0.1 });

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }
    return () => observer.disconnect();
  }, [target, duration]);

  const formatted = count.toLocaleString('id-ID', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });

  return (
    <span ref={elementRef} className="font-mono">
      {prefix}{formatted}{suffix}
    </span>
  );
};

export default function FactsPage() {
  const [selectedFact, setSelectedFact] = useState<any | null>(null);
  
  // Custom states for filter, search, bookmarks, reactions & toasts
  const [selectedCategory, setSelectedCategory] = useState<string>("Semua");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [bookmarks, setBookmarks] = useState<Record<number, boolean>>(() => {
    try {
      const saved = localStorage.getItem('eco_facts_bookmarks');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Keep a reactivity count index for user custom reaction triggers
  const [reactions, setReactions] = useState<Record<number, Record<string, number>>>(() => {
    try {
      const saved = localStorage.getItem('eco_facts_reactions');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Live Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('eco_facts_bookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  useEffect(() => {
    localStorage.setItem('eco_facts_reactions', JSON.stringify(reactions));
  }, [reactions]);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const toggleBookmark = (id: number) => {
    setBookmarks(prev => {
      const next = { ...prev, [id]: !prev[id] };
      if (next[id]) {
        triggerToast("Fakta berhasil disimpan ke penanda!");
      } else {
        triggerToast("Penanda fakta dihapus.");
      }
      return next;
    });
  };

  const handleReaction = (factId: number, type: string) => {
    setReactions(prev => {
      const currentFact = prev[factId] || { wow: 0, shock: 0, motivated: 0 };
      const updatedFact = { ...currentFact, [type]: currentFact[type] + 1 };
      triggerToast(`Anda mengekspresikan reaksi untuk fakta ini!`);
      return { ...prev, [factId]: updatedFact };
    });
  };

  const handleShare = (fact: any) => {
    const textToCopy = `[Tahukah Kamu? — EcoScan] ${fact.title}\n\n"${fact.factIndonesian || fact.fact}"\n\nDapatkan lebih banyak panduan daur ulang dan wawasan di EcoScan!`;
    navigator.clipboard.writeText(textToCopy)
      .then(() => {
        triggerToast("Konten fakta disalin ke papan klip! Siap dibagikan.");
      })
      .catch(() => {
        triggerToast("Gagal menyalin otomatis.");
      });
  };

  // 1. FAKTA HARI INI: Date-based logic for daily rotating hero fact
  const today = new Date();
  const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);
  const factOfDayIndex = Math.max(0, dayOfYear % ECO_FACTS.length);
  const dailyFact = ECO_FACTS[factOfDayIndex] || ECO_FACTS[0];

  // Filters setup
  const categoriesList = ["Semua", "Plastik", "Lautan", "Daur Ulang", "Energi", "Indonesia"];

  const filteredFacts = ECO_FACTS.filter(fact => {
    const textMatch = (fact.title + " " + (fact.factIndonesian || fact.fact))
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    
    if (selectedCategory === "Semua") return textMatch;
    const itemCategories = FACT_CATEGORIES[fact.id] || [];
    return itemCategories.includes(selectedCategory) && textMatch;
  });

  // Calculate default values for mock visual progress stats and reaction totals
  const getMockPeopleCount = (id: number) => {
    // Deterministic random numbers between 400 and 950 based on ID
    return 400 + ((id * 47) % 551);
  };

  const getMockBookmarksCount = (id: number) => {
    // Deterministic bookmark counts
    const base = 80 + ((id * 23) % 180);
    return bookmarks[id] ? base + 1 : base;
  };

  const getReactionCount = (id: number, type: string) => {
    const userReacted = reactions[id]?.[type] || 0;
    let base = 10;
    if (type === 'wow') base = 48 + ((id * 31) % 110);
    if (type === 'shock') base = 32 + ((id * 19) % 80);
    if (type === 'motivated') base = 64 + ((id * 37) % 140);
    return base + userReacted;
  };

  return (
    <div className="w-full relative min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-10 overflow-hidden bg-[#F4FAF0]" id="facts-page-root">
      
      {/* Decorative Blur Shapes */}
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-emerald-100/40 rounded-full blur-3xl -z-10" />
      <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-sky-100/40 rounded-full blur-3xl -z-10" />

      {/* Floating Success Toast Message */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -40, x: "-50%" }}
            animate={{ opacity: 1, y: 0, x: "-50%" }}
            exit={{ opacity: 0, y: -20, x: "-50%" }}
            className="fixed top-20 left-1/2 z-[100] transform -translate-x-1/2 px-5 py-3 rounded-2xl bg-slate-900 text-white text-xs font-bold font-mono tracking-wide shadow-2xl flex items-center space-x-2.5 border border-slate-755"
          >
            <div className="p-1 rounded-full bg-emerald-500 fill-current text-slate-900 flex items-center justify-center">
              <Check className="h-3.5 w-3.5 stroke-[3] text-black" />
            </div>
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-6xl mx-auto space-y-10 relative">
        
        {/* Responsive Dual Mascot Header */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-20 w-full mb-2">
          
          {/* Left Mascot (Buku) */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" title="Buku">
              <div className="relative mt-2 text-center">
                <div className="absolute inset-0 bg-emerald-100/30 rounded-full blur-xl group-hover:bg-slate-200/40 transition-colors duration-300 -z-10" />
                <div>
                  <svg viewBox="0 0 100 100" className="w-20 h-20 sm:w-24 sm:h-24 mx-auto filter drop-shadow-md select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                    <path d="M 28 82 L 72 82 L 75 30 L 31 30 Z" fill="#FBFADA" />
                    <path d="M 25 80 L 70 80 Q 73 80, 73 78 L 73 24 Q 73 22, 70 22 L 25 22 Q 22 22, 22 25 L 22 77 Q 22 80, 25 80" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" />
                    <path d="M 30 74 L 68 74 L 68 28 L 30 28 Z" fill="#FFFFFF" stroke="#3F6212" strokeWidth="2.2" />
                    <circle cx="43" cy="45" r="7" fill="none" stroke="#222222" strokeWidth="2.5" />
                    <circle cx="57" cy="45" r="7" fill="none" stroke="#222222" strokeWidth="2.5" />
                    <circle cx="43" cy="45" r="2.2" fill="#222222" />
                    <circle cx="57" cy="45" r="2.2" fill="#222222" />
                    <circle cx="35" cy="52" r="2.5" fill="#FF8FA3" opacity="0.8" />
                    <circle cx="65" cy="52" r="2.5" fill="#FF8FA3" opacity="0.8" />
                    <path d="M 47 51 Q 50 54, 53 51" stroke="#222222" strokeWidth="2" strokeLinecap="round" fill="none" />
                    <path d="M 45 74 L 45 84 L 48 81 L 51 84 L 51 74 Z" fill="#FF8FA3" stroke="#3F6212" strokeWidth="1.5" />
                    <path d="M 22 55 Q 14 58, 16 63" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 73 55 Q 81 58, 79 63" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M 38 79 L 35 87" stroke="#3F6212" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 62 79 L 65 87" stroke="#3F6212" strokeWidth="3" strokeLinecap="round" />
                  </svg>
                </div>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">
                    Buku
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Title area */}
          <div className="flex-1 text-center py-2 space-y-2 font-nunito">
            <span className="text-xs uppercase font-mono tracking-widest font-extrabold text-[#1A4A0A] inline-flex items-center gap-1.5 justify-center">
              <Globe className="h-4 w-4 text-[#1A4A0A]" />
              <span>Dunia Lestari Indonesia</span>
            </span>
            <h1 className="font-fredoka text-3.5xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#1A4A0A] leading-tight">
              Eksplorasi <span className="text-[#FF8FA3]">Fakta Hijau</span>
            </h1>
            <p className="text-xs sm:text-sm text-[#5A7A50] max-w-xl mx-auto font-semibold">
              Wawasan statistik terkini dan inisiatif ekologis penting dalam aksi nyata penyelamatan ekosistem di Indonesia.
            </p>
          </div>

          {/* Right Mascot (Ide) */}
          <div className="hidden md:flex flex-col items-center justify-center w-full max-w-[170px] shrink-0">
            <div className="relative cursor-pointer group" title="Ide">
              <div className="relative mt-2 text-center">
                <div className="absolute inset-0 bg-amber-100/30 rounded-full blur-xl group-hover:bg-slate-200/40 transition-colors duration-300 -z-10" />
                <div>
                  <svg viewBox="0 0 100 100" className="w-20 h-20 sm:w-24 sm:h-24 mx-auto filter drop-shadow-md select-none transform group-hover:scale-105 active:scale-95 transition-all duration-300">
                    <path d="M 40 70 L 60 70 L 56 82 L 44 82 Z" fill="#94A3B8" stroke="#3F6212" strokeWidth="2.5" strokeLinejoin="round" />
                    <rect x="42" y="82" width="16" height="5" rx="1.5" fill="#475569" stroke="#3F6212" strokeWidth="2" />
                    <path d="M 50 18 C 25 18, 25 55, 40 70 L 60 70 C 75 55, 75 18, 50 18 Z" fill="#FACC15" stroke="#3F6212" strokeWidth="3" strokeLinejoin="round" />
                    <ellipse cx="43" cy="48" rx="3.5" ry="5" fill="#222222" />
                    <ellipse cx="57" cy="48" rx="3.5" ry="5" fill="#222222" />
                    <circle cx="36" cy="54" r="2.5" fill="#FF8FA3" opacity="0.8" />
                    <circle cx="64" cy="54" r="2.5" fill="#FF8FA3" opacity="0.8" />
                    <path d="M 47 54 Q 50 58, 53 54" stroke="#222222" strokeWidth="2" strokeLinecap="round" fill="none" />
                    <path d="M 33 58 Q 23 54, 21 47" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" fill="none" />
                    <path d="M 67 58 Q 77 54, 79 47" stroke="#3F6212" strokeWidth="2" strokeLinecap="round" fill="none" />
                    <path d="M 45 87 L 43 94" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                    <path d="M 55 87 L 57 94" stroke="#3F6212" strokeWidth="2.5" strokeLinecap="round" />
                  </svg>
                </div>
                <div className="mt-1">
                  <span className="inline-block text-[9px] uppercase font-mono tracking-wider font-extrabold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">
                    Ide
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Mascot Row */}
          <div className="flex md:hidden items-center justify-center gap-8 w-full select-none pt-2 border-t border-dotted border-slate-300/60">
            <div className="flex flex-col items-center max-w-[120px] relative">
              <div className="relative mt-2">
                <svg viewBox="0 0 100 100" className="w-16 h-16 filter drop-shadow">
                  <path d="M 28 82 L 72 82 L 75 30 L 31 30 Z" fill="#FBFADA" />
                  <path d="M 25 80 L 70 80 Q 73 80, 73 78 L 73 24 Q 73 22, 70 22 L 25 22 C 22 22, 22 25, 22 25 L 22 77 Q 22 80, 25 80" fill="#A8DF8E" stroke="#3F6212" strokeWidth="3" />
                  <circle cx="43" cy="45" r="7" fill="none" stroke="#222222" strokeWidth="2.5" />
                  <circle cx="57" cy="45" r="7" fill="none" stroke="#222222" strokeWidth="2.5" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-slate-700 bg-slate-100 px-1.5 py-0.2 rounded-full border border-slate-200">
                    Buku
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center max-w-[120px] relative">
              <div className="relative mt-2">
                <svg viewBox="0 0 100 100" className="w-16 h-16 filter drop-shadow">
                  <path d="M 40 70 L 60 70 L 56 82 L 44 82 Z" fill="#94A3B8" stroke="#3F6212" strokeWidth="2.5" strokeLinejoin="round" />
                  <path d="M 50 18 C 25 18, 25 55, 40 70 L 60 70 C 75 55, 75 18, 50 18 Z" fill="#FACC15" stroke="#3F6212" strokeWidth="3" />
                </svg>
                <div className="text-center mt-0.5">
                  <span className="inline-block text-[8px] font-black text-slate-700 bg-slate-100 px-1.5 py-0.2 rounded-full border border-slate-200">
                    Ide
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 1. FAKTA HARI INI - Featured Hero Card */}
        {dailyFact && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full bg-gradient-to-br from-[#1A4A0A] to-slate-950 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl border border-[#1A4A0A]/40"
            id="fakta-hari-ini-hero"
          >
            {/* Animated background highlights to make it eye-catching (pure design canvas) */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_120%,rgba(16,185,129,0.18),transparent_60%)] pointer-events-none" />
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
              <div className="space-y-4 max-w-3xl">
                <div className="flex items-center space-x-2">
                  <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-black tracking-widest uppercase px-3 py-1 rounded-full border border-emerald-400/20 flex items-center gap-1">
                    <Flame className="w-3 h-3 text-emerald-400" />
                    Fakta Utama Hari Ini
                  </span>
                  <span className="font-mono text-[10px] text-slate-400">
                    {today.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  </span>
                </div>

                <div className="space-y-1">
                  <span className="text-xs text-emerald-450 font-semibold tracking-wider block uppercase font-mono">
                    Tahukah kamu?
                  </span>
                  <h2 className="font-serif text-2xl sm:text-3xl font-black text-white tracking-tight leading-tight">
                    {dailyFact.title}
                  </h2>
                </div>

                <p className="text-sm sm:text-base text-slate-100 leading-relaxed font-medium bg-white/5 p-4 rounded-2xl border border-white/10 backdrop-blur-sm">
                  "{dailyFact.factIndonesian || dailyFact.fact}"
                </p>

                {/* Hero Footnotes with simple interaction items */}
                <div className="flex flex-wrap gap-4 items-center text-xs text-slate-300 pt-1">
                  <button 
                    onClick={() => setSelectedFact(dailyFact)}
                    className="flex items-center gap-1 text-emerald-400 font-extrabold hover:text-emerald-300 transition-colors"
                  >
                    Selidiki Bukti Statistik ➜
                  </button>
                  <span className="text-slate-600">|</span>
                  <span className="font-mono text-slate-400">
                    Kategori: {(FACT_CATEGORIES[dailyFact.id] || []).join(", ")}
                  </span>
                </div>
              </div>

              {/* Dynamic Action items embedded inside Hero for clean responsive experience */}
              <div className="flex flex-col sm:flex-row md:flex-col gap-3 justify-center items-stretch sm:items-center md:items-stretch w-full md:w-auto shrink-0 md:bg-white/5 md:p-5 md:rounded-2xl md:border md:border-white/10">
                <button
                  onClick={() => handleShare(dailyFact)}
                  className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs transition-all flex items-center justify-center gap-2 outline-none"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  Bagikan Fakta
                </button>

                <button
                  onClick={() => toggleBookmark(dailyFact.id)}
                  className={`px-5 py-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 border ${
                    bookmarks[dailyFact.id] 
                      ? 'bg-slate-800 text-emerald-400 border-emerald-500/40' 
                      : 'bg-transparent text-slate-100 border-white/20 hover:bg-white/10'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${bookmarks[dailyFact.id] ? 'fill-current' : ''}`} />
                  {bookmarks[dailyFact.id] ? 'Tersimpan' : 'Tandai Fakta'}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* 6. ECO CORE STATISTIK WATERFALL SECTION - Beautiful dynamic scroll counting stats */}
        <div className="bg-[#F4FAF0] p-6 sm:p-8 rounded-[2rem] border border-[#E0F0D8] shadow-md space-y-6">
          <div className="text-center sm:text-left">
            <h3 className="text-xs uppercase font-mono tracking-widest font-bold text-[#1A4A0A]/70">
              Statistik Kunci Nasional
            </h3>
            <h4 className="font-fredoka text-2xl font-bold text-[#1A4A0A] leading-tight">
              Tantangan & Peluang Masa Depan Hijau RI
            </h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-2">
            
            {/* Stat Item 1 */}
            <div className="p-5 bg-[#EAF7EA] rounded-2xl border border-[#A8DF8E]/30 flex flex-col justify-between">
              <span className="text-[10px] font-mono uppercase text-[#5A7A50] font-bold block">
                Plastik Tahunan
              </span>
              <div className="my-2">
                <span className="text-3xl font-black font-fredoka text-[#1A4A0A]">
                  <AnimatedCounter target={6.8} decimals={1} duration={1200} />
                </span>
                <span className="text-sm font-bold text-[#5A7A50] block">Juta Ton Sampah</span>
              </div>
              <p className="text-[11px] text-[#3A5A30] font-semibold leading-relaxed font-nunito">
                Timbulan sampah plastik yang dihasilkan di dalam negeri setiap tahun.
              </p>
            </div>

            {/* Stat Item 2 */}
            <div className="p-5 bg-[#FFF0F2] rounded-2xl border border-[#FF8FA3]/30 flex flex-col justify-between">
              <span className="text-[10px] font-mono uppercase text-[#FF8FA3] font-bold block">
                Kebocoran Lautan
              </span>
              <div className="my-2">
                <span className="text-3xl font-black font-fredoka text-[#FF8FA3]">
                  <AnimatedCounter target={620} duration={1000} />.000+
                </span>
                <span className="text-sm font-bold text-[#5A7A50] block">Ton Menuju Pesisir</span>
              </div>
              <p className="text-[11px] text-[#3A5A30] font-semibold leading-relaxed font-nunito">
                Perkiraan bocoran limbah tidak terkelola ramah lingkungan yang mengotori perairan laut kita.
              </p>
            </div>

            {/* Stat Item 3 */}
            <div className="p-5 bg-[#FCF9E3] rounded-2xl border border-amber-200/50 flex flex-col justify-between">
              <span className="text-[10px] font-mono uppercase text-amber-700 font-bold block">
                Sistem Penyaluran
              </span>
              <div className="my-2">
                <span className="text-3xl font-black font-fredoka text-amber-800">
                  <AnimatedCounter target={11556} duration={1400} />
                </span>
                <span className="text-sm font-bold text-[#5A7A50] block">Bank Sampah Unit</span>
              </div>
              <p className="text-[11px] text-[#3A5A30] font-semibold leading-relaxed font-nunito">
                Sistem mikro-tabungan ekologi terdaftar SIPSN KLHK di seluruh provinsi indonesia.
              </p>
            </div>

            {/* Stat Item 4 */}
            <div className="p-5 bg-[#EAF7EA] rounded-2xl border border-[#A8DF8E]/30 flex flex-col justify-between">
              <span className="text-[10px] font-mono uppercase text-[#1A4A0A] font-bold block">
                Komposisi Organik
              </span>
              <div className="my-2">
                <span className="text-3xl font-black font-fredoka text-[#1A4A0A]">
                  <AnimatedCounter target={55} duration={1000} />%
                </span>
                <span className="text-sm font-bold text-[#5A7A50] block">Sampah Basah Dapur</span>
              </div>
              <p className="text-[11px] text-[#3A5A30] font-semibold leading-relaxed font-nunito">
                Dominan volume sampah nasional yang membawa ancaman pelepasan gas metana gas bumi.
              </p>
            </div>

          </div>
        </div>

        {/* 4 & 5. SEARCH & CATEGORY FILTER BAR */}
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            
            {/* Search Bar */}
            <div className="relative flex-1 max-w-lg">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Cari kata kunci fakta lingkungan..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-4 py-3 rounded-2xl bg-white border border-[#E0F0D8] focus:border-[#1A4A0A] focus:ring-2 focus:ring-[#1A4A0A]/20 focus:outline-none text-[#1A2E10] text-sm shadow-md font-medium transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-0.5 rounded-full hover:bg-slate-100 text-[#5A7A50]"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            {/* Counter Badge */}
            <div className="text-xs font-mono font-bold text-[#5A7A50] bg-white border border-[#E0F0D8] px-4 py-2 rounded-xl self-start md:self-auto">
              Ditemukan: <span className="text-[#1A4A0A] font-extrabold">{filteredFacts.length} fakta</span>
            </div>

          </div>

          {/* Category Tabs Wrapper */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none w-full border-b border-[#E0F0D8]">
            {categoriesList.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all whitespace-nowrap outline-none ${
                  selectedCategory === cat 
                    ? 'bg-[#1A4A0A] text-white shadow-sm font-extrabold' 
                    : 'bg-white hover:bg-[#F4FAF0] text-[#5A7A50] border border-[#E0F0D8]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* TWO COLUMN CONTENT: Fact Bento Grid + Facts of the Week Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Fact Cards Block (8 cols on lg) */}
          <div className="lg:col-span-8 space-y-6">
            <AnimatePresence mode="popLayout">
              {filteredFacts.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3"
                >
                  <SparklesSketch className="w-8 h-8 text-slate-350 mx-auto" />
                  <p className="text-sm font-bold text-slate-800">Tidak ada fakta yang cocok dengan pencarian Anda.</p>
                  <button 
                    onClick={() => { setSearchQuery(""); setSelectedCategory("Semua"); }}
                    className="text-xs text-emerald-600 font-extrabold underline hover:text-emerald-700"
                  >
                    Reset Filter Pencarian
                  </button>
                </motion.div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {filteredFacts.map((fact, index) => {
                    const isBookmarked = bookmarks[fact.id] || false;
                    const peopleKnown = getMockPeopleCount(fact.id);
                    const percentKnown = Math.round((peopleKnown / 1000) * 100);
                    const totalBookmarks = getMockBookmarksCount(fact.id);

                    return (
                      <motion.div
                        key={fact.id}
                        layout
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.35, delay: index * 0.04 }}
                        className="bg-white hover:shadow-lg rounded-[2rem] border border-[#E0F0D8] p-5 shadow-sm hover:shadow-md transition-all duration-200 group flex flex-col justify-between cursor-pointer relative overflow-hidden"
                        id={`eco-fact-card-${fact.id}`}
                        onClick={() => setSelectedFact(fact)}
                      >
                        <div className="space-y-4">
                          {/* Banner Badge Top Row */}
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono font-black bg-[#A8DF8E] text-[#1A4A0A] px-2.5 py-0.5 rounded-md">
                              No. {String(fact.id).padStart(2, "0")}
                            </span>
                            
                            {/* Bookmark Action */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleBookmark(fact.id);
                              }}
                              className={`p-1.5 rounded-full transition-all outline-none ${
                                isBookmarked 
                                  ? 'bg-amber-50 text-amber-500 border border-amber-250' 
                                  : 'hover:bg-slate-100 text-slate-400'
                              }`}
                              title={isBookmarked ? "Hapus penanda" : "Tandai fakta ini"}
                            >
                              <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-current' : ''}`} />
                            </button>
                          </div>

                          {/* 2. CARD REDESIGN: Title + Plain-Text Labels + "Tahukah kamu?" */}
                          <div className="space-y-1.5">
                            <span className="text-[10px] text-[#1A4A0A] font-extrabold uppercase font-mono block tracking-wider leading-none">
                              Tahukah kamu?
                            </span>
                            <h3 className="font-fredoka text-base font-bold text-[#1A4A0A] group-hover:text-[#FF8FA3] transition-colors leading-snug">
                              {fact.title}
                            </h3>
                            <p className="text-xs text-[#3A5A30] leading-relaxed font-semibold font-nunito">
                              {fact.factIndonesian || fact.fact}
                            </p>
                          </div>

                          {/* Progress bar info: "X dari 1000 orang sudah tahu fakta ini" */}
                          <div className="space-y-1 pt-1.5">
                            <div className="flex items-center justify-between text-[10px] font-mono text-slate-650">
                              <span>Sadar Edukasi</span>
                              <span className="font-bold">{peopleKnown} / 1000 orang</span>
                            </div>
                            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/50">
                              <div 
                                className="h-full bg-emerald-500 rounded-full transition-all duration-300" 
                                style={{ width: `${percentKnown}%` }}
                              />
                            </div>
                          </div>
                        </div>

                        {/* Interactive Reaction and Social Actions Row */}
                        <div className="mt-4 pt-3 border-t border-slate-150 flex flex-col gap-2">
                          
                          {/* Reaction button pills (Plain text formatting, no colored emojis) */}
                          <div className="flex flex-wrap gap-1.5 items-center justify-between" onClick={(e) => e.stopPropagation()}>
                            <div className="flex flex-wrap gap-1 items-center">
                              {/* Pill A: Wow */}
                              <button
                                onClick={() => handleReaction(fact.id, 'wow')}
                                className="px-2 py-1 rounded-lg border border-slate-200 hover:border-slate-350 bg-slate-50 hover:bg-slate-100 text-[10px] font-bold text-slate-650 flex items-center space-x-1 transition-all outline-none"
                              >
                                <span>Wow</span>
                                <span className="font-mono text-slate-900 bg-white/80 px-1 rounded-md border border-slate-150 text-[9px]">
                                  {getReactionCount(fact.id, 'wow')}
                                </span>
                              </button>

                              {/* Pill B: Terkejut */}
                              <button
                                onClick={() => handleReaction(fact.id, 'shock')}
                                className="px-2 py-1 rounded-lg border border-slate-200 hover:border-slate-350 bg-slate-50 hover:bg-slate-100 text-[10px] font-bold text-slate-650 flex items-center space-x-1 transition-all outline-none"
                              >
                                <span>Kaget</span>
                                <span className="font-mono text-slate-900 bg-white/80 px-1 rounded-md border border-slate-150 text-[9px]">
                                  {getReactionCount(fact.id, 'shock')}
                                </span>
                              </button>

                              {/* Pill C: Inspiratif */}
                              <button
                                onClick={() => handleReaction(fact.id, 'motivated')}
                                className="px-2 py-1 rounded-lg border border-slate-200 hover:border-slate-350 bg-slate-50 hover:bg-slate-100 text-[10px] font-bold text-slate-650 flex items-center space-x-1 transition-all outline-none"
                              >
                                <span>Peduli</span>
                                <span className="font-mono text-slate-900 bg-white/80 px-1 rounded-md border border-slate-150 text-[9px]">
                                  {getReactionCount(fact.id, 'motivated')}
                                </span>
                              </button>
                            </div>

                            {/* Share button */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleShare(fact);
                              }}
                              className="p-1.5 rounded-lg border border-slate-150 hover:bg-slate-100 text-slate-650 transition-all outline-none"
                              title="Salin dan Bagikan"
                            >
                              <Share2 className="w-3.5 h-3.5 text-slate-500" />
                            </button>
                          </div>

                          {/* Small bookmarks indicator counts & more link */}
                          <div className="flex items-center justify-between text-[9px] font-mono text-slate-400">
                            <span>Ditandai {totalBookmarks} orang</span>
                            <span className="text-emerald-700 font-extrabold hover:underline">Detail Bukti Statistik ➜</span>
                          </div>

                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </AnimatePresence>
          </div>

          {/* 7. FACT OF THE WEEK SIDEBAR (4 cols on lg) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-3xl border border-slate-250 p-6 shadow-sm space-y-6">
              <div className="space-y-1">
                <span className="bg-emerald-50 text-[#1A4A0A] text-[9px] font-mono font-black tracking-widest uppercase px-2.5 py-1 rounded-full border border-emerald-100 w-fit block mb-1">
                  Wawasan Utama Mingguan
                </span>
                <h4 className="font-serif text-xl font-black text-[#1A4A0A] leading-tight">
                  Fakta Minggu Ini: Biometrik Selulosa Kertas
                </h4>
              </div>

              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-150/60 space-y-3">
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800 shrink-0">
                    <Lightbulb className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Penyelamatan Energi Pulp</h5>
                    <p className="text-[11px] text-slate-700 leading-relaxed font-semibold mt-0.5">
                      Daur ulang 1 ton kertas kantor mencegah pelepasan karbon dan menghemat 26.500 liter air murni murni dibandingkan pabrik baru.
                    </p>
                  </div>
                </div>
              </div>

              {/* Action list related to Fact of the Week */}
              <div className="space-y-3.5 pt-1">
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 block font-mono">
                  Aksi Nyata Yang Bisa Anda Lakukan:
                </span>
                
                <ul className="space-y-3">
                  <li className="flex items-start space-x-2.5 text-xs text-slate-800 leading-relaxed">
                    <div className="min-w-4 h-4 rounded-full bg-slate-100 text-slate-700 font-mono text-[9px] font-bold flex items-center justify-center border border-slate-200 mt-0.5">
                      1
                    </div>
                    <span>Gunakan kertas bermuka ganda (print duplex) demi memangkas kebutuhan kertas harian kantor hingga 50%.</span>
                  </li>
                  <li className="flex items-start space-x-2.5 text-xs text-slate-800 leading-relaxed">
                    <div className="min-w-4 h-4 rounded-full bg-slate-100 text-slate-700 font-mono text-[9px] font-bold flex items-center justify-center border border-slate-200 mt-0.5">
                      2
                    </div>
                    <span>Kumpulkan sisa kardus pembungkus paket belanja online Anda, lipat rapi, lalu setorkan ke bank sampah local terdekat.</span>
                  </li>
                  <li className="flex items-start space-x-2.5 text-xs text-slate-800 leading-relaxed">
                    <div className="min-w-4 h-4 rounded-full bg-slate-100 text-slate-700 font-mono text-[9px] font-bold flex items-center justify-center border border-slate-200 mt-0.5">
                      3
                    </div>
                    <span>Daur ulang kotak wadah telur karton kasar dengan mencampurnya ke dalam tong aerobik pembuatan pupuk organik dapur.</span>
                  </li>
                </ul>
              </div>

              {/* Verified Badge seal */}
              <div className="pt-4 border-t border-slate-150 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center space-x-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="font-semibold text-slate-900">Eko-Sertifikasi SIPSN</span>
                </div>
                <span className="font-mono text-[9px] uppercase">KLHK Laporan</span>
              </div>
            </div>

            {/* Bookmarks Quick panel - view bookmarked facts locally */}
            <div className="bg-white rounded-3xl border border-slate-250 p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-serif text-base font-black text-[#1A4A0A]">
                  Fakta Favorit Anda
                </h4>
                <span className="font-mono text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                  {Object.values(bookmarks).filter(Boolean).length}
                </span>
              </div>

              {Object.values(bookmarks).filter(Boolean).length === 0 ? (
                <p className="text-xs text-slate-500 italic leading-relaxed">
                  Belum ada fakta yang ditandai. Klik ikon penanda pada kartu fakta di sebelah kiri untuk menyimpannya di sini.
                </p>
              ) : (
                <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                  {ECO_FACTS.map(f => {
                    if (!bookmarks[f.id]) return null;
                    return (
                      <div 
                        key={f.id} 
                        onClick={() => setSelectedFact(f)}
                        className="p-3 bg-slate-50 rounded-xl hover:bg-slate-100 border border-slate-200 cursor-pointer transition-all space-y-1.5 relative group"
                      >
                        <h5 className="text-xs font-bold text-slate-950 group-hover:text-emerald-700 line-clamp-1 transition-colors">
                          {f.title}
                        </h5>
                        <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                          {f.factIndonesian || f.fact}
                        </p>
                        <div className="flex items-center justify-between text-[9px] font-mono text-slate-400">
                          <span>Verified Referensi</span>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleBookmark(f.id);
                            }}
                            className="text-red-500 hover:underline"
                          >
                            Hapus
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Dynamic motivational CTA Banner */}
        <div className="bg-slate-900 text-white p-6 sm:p-10 rounded-3xl border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_0%_0%,rgba(16,185,129,0.1),transparent_50%5)] pointer-events-none" />
          
          <div className="space-y-3 text-center md:text-left max-w-2xl relative z-10">
            <div className="flex items-center justify-center md:justify-start space-x-2 text-emerald-405 text-emerald-400">
              <Award className="h-4.5 w-4.5 text-emerald-450" />
              <span className="text-[10px] font-mono uppercase tracking-widest font-black text-emerald-300">EcoScan Youth Movement</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-black text-white leading-tight">
              Aksi Kecil, Dampak Hidup Lestari!
            </h3>
            <p className="text-xs sm:text-sm text-slate-350 leading-relaxed font-medium">
              Satu pilahan sampah organik dan anorganik harian Anda menjamin keselamatan bumi lebih dari ratusan tahun ke depan. Bagikan fakta-fakta edukatif ini kepada keluarga Anda!
            </p>
          </div>
          
          <div className="flex flex-col text-center space-y-1 p-5 rounded-2xl bg-white/5 border border-white/10 shrink-0 relative z-10 w-full md:w-auto">
            <span className="text-[9px] uppercase font-mono tracking-widest text-[#FF8FA3] font-extrabold">TAHUKAH ANDA?</span>
            <span className="font-mono text-3xl font-black text-white leading-none">100%</span>
            <span className="text-[10px] text-slate-300 leading-none font-semibold mt-1">Gelas kaca dapat didaur ulang selamanya!</span>
          </div>
        </div>

        {/* Modal Popup Bukti Statistik */}
        <AnimatePresence>
          {selectedFact && (
            <div className="fixed inset-0 z-55 flex items-center justify-center p-4">
              {/* Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-slate-950/50 backdrop-blur-md"
                onClick={() => setSelectedFact(null)}
              />

              {/* Main Modal Card */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative bg-white border border-slate-20 w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl z-50 flex flex-col"
              >
                {/* Header pattern decoration */}
                <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-emerald-500 via-[#FF8FA3] to-amber-400" />
                
                <div className="p-6 sm:p-8 space-y-6">
                  {/* Close button in header */}
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-mono font-bold uppercase border border-emerald-200/50">
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" /> Referensi Terverifikasi Sektor
                    </span>
                    <button
                      onClick={() => setSelectedFact(null)}
                      className="p-1.5 rounded-full hover:bg-slate-100 text-slate-600 transition-colors"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  {/* Fact Brief */}
                  <div className="flex gap-4 items-start">
                    <div className="text-sm font-mono font-bold px-4 py-2.5 bg-slate-100 border border-slate-200 text-slate-750 rounded-2xl shrink-0">
                      {String(selectedFact.id).padStart(2, "0")}
                    </div>
                    <div className="space-y-1">
                      <span className="font-mono text-[9px] text-slate-500 uppercase tracking-widest font-black">
                        Pernyataan IDN-0{selectedFact.id}
                      </span>
                      <h4 className="font-serif text-xl font-black text-slate-905 leading-tight">
                        {selectedFact.title}
                      </h4>
                    </div>
                  </div>

                  {/* Fact Text Quote */}
                  <div className="border-l-4 border-emerald-600 pl-4 py-2 bg-slate-50 rounded-r-2xl">
                    <p className="text-xs sm:text-sm font-bold text-slate-800 leading-relaxed italic">
                      "{selectedFact.factIndonesian || selectedFact.fact}"
                    </p>
                  </div>

                  {/* Source citation */}
                  <div className="space-y-3 pt-2">
                    <h5 className="text-[10px] uppercase font-mono font-extrabold tracking-widest text-slate-500">
                      Mitra / Dokumen Sumber Publik:
                    </h5>
                    
                    <div className="p-4 rounded-2xl bg-gradient-to-b from-slate-50 to-slate-100/30 border border-slate-200/80 space-y-2">
                      <div className="flex items-center gap-2">
                        <BookSketch className="h-4 w-4 text-emerald-600 shrink-0" />
                        <span className="text-xs font-bold text-slate-950">
                          {FACT_SOURCES[selectedFact.id]?.agency || "Sistem Informasi Pengelolaan Sampah Nasional (SIPSN) - KLHK"}
                        </span>
                      </div>
                      <p className="text-xs text-slate-800 font-semibold leading-relaxed pl-6">
                        {FACT_SOURCES[selectedFact.id]?.details || "Referensi diperoleh dari direktori bank sampah resmi, publikasi data spasial kehutanan, serta pengawasan TPA harian."}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Footer buttons */}
                <div className="bg-slate-50 border-t border-slate-150 p-4 sm:px-8 flex justify-between items-center">
                  <span className="text-[9px] font-mono text-slate-400">Verifikasi: EcoScan IDN</span>
                  <button
                    onClick={() => setSelectedFact(null)}
                    className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-955 text-white font-bold text-xs shadow-md transition-all duration-150"
                  >
                    Tutup Referensi
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
