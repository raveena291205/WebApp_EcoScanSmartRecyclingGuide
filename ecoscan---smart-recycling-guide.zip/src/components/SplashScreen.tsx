import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface SplashScreenProps {
  onComplete: () => void;
}

const ECO_TIPS = [
  "Pilah sampah organik dan anorganik secara terpisah",
  "Cuci kemasan plastik sebelum didaur ulang dengan air mengalir",
  "Gunakan tempat minum pribadi (tumbler) untuk kurangi botol sekali pakai",
  "Satu kilogram plastik membutuhkan waktu hingga ratusan tahun untuk terurai",
  "Ubah limbah organik menjadi kompos subur untuk tanaman",
  "Kertas daur ulang mampu menghemat hingga 58% air hutan",
  "Matikan lampu dan keran air saat tidak digunakan untuk menghemat energi"
];

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('Memuat EcoScan.');
  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  // Smooth loading percentage bar at 60fps over 4.5 seconds
  useEffect(() => {
    const duration = 4500; // 4.5 seconds as requested (4-5s)
    const startTime = Date.now();

    const progressInterval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min((elapsed / duration) * 100, 100);
      setProgress(pct);
      
      if (pct >= 100) {
        clearInterval(progressInterval);
      }
    }, 16); // 16ms interval for ~60fps smooth updates

    // Dynamic dot-dot-dot text animation
    const textInterval = setInterval(() => {
      setLoadingText((prev) => {
        if (prev === 'Memuat EcoScan...') return 'Memuat EcoScan.';
        if (prev === 'Memuat EcoScan.') return 'Memuat EcoScan..';
        return 'Memuat EcoScan...';
      });
    }, 450);

    // Call completion trigger
    const exitTimeout = setTimeout(() => {
      onComplete();
    }, duration + 100);

    return () => {
      clearInterval(progressInterval);
      clearInterval(textInterval);
      clearTimeout(exitTimeout);
    };
  }, [onComplete]);

  // Handle Eco Tips Carousel animation interval
  useEffect(() => {
    const tipInterval = setInterval(() => {
      setCurrentTipIndex((prev) => (prev + 1) % ECO_TIPS.length);
    }, 1500); // changes tip every 1.5 seconds

    return () => clearInterval(tipInterval);
  }, []);

  // 10 distinct gorgeous mascot SVGs with unique style, size, and bounce offsets
  const floatingItems = [
    // 1. Daun (Leaf) - Top Left
    {
      id: 1,
      style: { left: '4%', top: '10%' },
      duration: 3.4,
      delay: 0.1,
      scale: 1.0,
      svg: (
        <svg viewBox="0 0 100 100" className="w-14 h-14 filter drop-shadow-md">
          <path d="M 50 15 C 20 40, 25 80, 50 85 C 75 80, 80 40, 50 15 Z" fill="#73EC8B" stroke="#1E5128" strokeWidth="3.5" />
          <path d="M 50 15 L 50 85" stroke="#1E5128" strokeWidth="2.5" />
          <path d="M 50 35 Q 35 45, 30 40" stroke="#1E5128" strokeWidth="2" fill="none" />
          <path d="M 50 55 Q 65 65, 70 60" stroke="#1E5128" strokeWidth="2" fill="none" />
          <circle cx="42" cy="50" r="3.5" fill="#132F1A" />
          <circle cx="58" cy="50" r="3.5" fill="#132F1A" />
          <path d="M 46 58 Q 50 62, 54 58" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
          <circle cx="36" cy="52" r="2" fill="#FF8FA3" />
          <circle cx="64" cy="52" r="2" fill="#FF8FA3" />
        </svg>
      )
    },
    // 2. Bumi (Happy Earth Globe) - Top Right
    {
      id: 2,
      style: { right: '4%', top: '12%' },
      duration: 4.6,
      delay: 0.3,
      scale: 1.15,
      svg: (
        <svg viewBox="0 0 100 100" className="w-16 h-16 filter drop-shadow-md">
          <circle cx="50" cy="50" r="35" fill="#7BC9FF" stroke="#1E5128" strokeWidth="3.5" />
          <path d="M 30 35 C 25 45, 38 48, 42 40 C 46 32, 35 25, 30 35 Z" fill="#73EC8B" />
          <path d="M 60 55 C 55 65, 70 72, 72 60 C 74 48, 65 48, 60 55 Z" fill="#73EC8B" />
          <path d="M 32 62 C 28 68, 38 72, 40 64 Z" fill="#73EC8B" />
          <circle cx="43" cy="46" r="3" fill="#132F1A" />
          <circle cx="57" cy="46" r="3" fill="#132F1A" />
          <path d="M 47 52 Q 50 56, 53 52" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
          <circle cx="37" cy="48" r="1.8" fill="#FF8FA3" />
          <circle cx="63" cy="48" r="1.8" fill="#FF8FA3" />
        </svg>
      )
    },
    // 3. Botol Plastik (Recycled Plastic Bottle) - Bottom Left
    {
      id: 3,
      style: { left: '5%', bottom: '12%' },
      duration: 4.0,
      delay: 0.5,
      scale: 0.95,
      svg: (
        <svg viewBox="0 0 100 100" className="w-14 h-14 filter drop-shadow-md">
          <path d="M 42 15 L 58 15 L 56 25 L 68 35 L 68 85 L 32 85 L 32 35 L 44 25 Z" fill="#FFFFFF" stroke="#1E5128" strokeWidth="3.5" strokeLinejoin="round" />
          <rect x="40" y="25" width="20" height="5" rx="1.5" fill="#64748B" stroke="#1E5128" strokeWidth="2.2" />
          <path d="M 40 45 L 60 45" stroke="#1E5128" strokeWidth="2" />
          <path d="M 50 48 L 56 58 L 44 58 Z" fill="#73EC8B" stroke="#1E5128" strokeWidth="1.5" />
          <circle cx="43" cy="68" r="3.2" fill="#132F1A" />
          <circle cx="57" cy="68" r="3.2" fill="#132F1A" />
          <path d="M 47 74 Q 50 78, 53 74" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
          <circle cx="36" cy="70" r="1.8" fill="#FF8FA3" />
          <circle cx="64" cy="70" r="1.8" fill="#FF8FA3" />
        </svg>
      )
    },
    // 4. Kaleng (Alu Can) - Bottom Right
    {
      id: 4,
      style: { right: '6%', bottom: '11%' },
      duration: 4.2,
      delay: 0.25,
      scale: 0.95,
      svg: (
        <svg viewBox="0 0 100 100" className="w-14 h-14 filter drop-shadow-md">
          <rect x="34" y="24" width="32" height="56" rx="6" fill="#D1D5DB" stroke="#1E5128" strokeWidth="3.5" />
          <ellipse cx="50" cy="24" rx="16" ry="4" fill="#E5E7EB" stroke="#1E5128" strokeWidth="3" />
          <path d="M 46 20 L 52 16 L 56 20" stroke="#1E5128" strokeWidth="2" fill="none" />
          <circle cx="43" cy="50" r="3" fill="#132F1A" />
          <circle cx="57" cy="50" r="3" fill="#132F1A" />
          <path d="M 47 58 Q 50 62, 53 58" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
          <circle cx="37" cy="53" r="1.5" fill="#FF8FA3" />
          <circle cx="63" cy="53" r="1.5" fill="#FF8FA3" />
        </svg>
      )
    },
    // 5. Kertas (Smiling Document Pages) - Middle Left
    {
      id: 5,
      style: { left: '8%', top: '38%' },
      duration: 3.8,
      delay: 0.45,
      scale: 1.0,
      svg: (
        <svg viewBox="0 0 100 100" className="w-14 h-14 filter drop-shadow-md">
          <path d="M 30 20 L 60 20 L 75 35 L 75 80 L 30 80 Z" fill="#FFFFFF" stroke="#1E5128" strokeWidth="3.5" strokeLinejoin="round" />
          <path d="M 60 20 L 60 35 L 75 35" fill="#FFFFFF" stroke="#1E5128" strokeWidth="3.5" strokeLinejoin="round" />
          <line x1="40" y1="45" x2="65" y2="45" stroke="#1E5128" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="40" y1="55" x2="55" y2="55" stroke="#1E5128" strokeWidth="2.5" strokeLinecap="round" />
          <circle cx="44" cy="68" r="3" fill="#132F1A" />
          <circle cx="58" cy="68" r="3" fill="#132F1A" />
          <path d="M 48 73 Q 50 75, 52 73" stroke="#132F1A" strokeWidth="1.5" strokeLinecap="round" fill="none" />
        </svg>
      )
    },
    // 6. Bintang Hijau (Bright Green Twinkling Star) - Middle Right
    {
      id: 6,
      style: { right: '8%', top: '42%' },
      duration: 3.2,
      delay: 0.15,
      scale: 1.1,
      svg: (
        <svg viewBox="0 0 100 100" className="w-13 h-13 filter drop-shadow-md">
          <path d="M 50 12 L 61 38 L 89 38 L 66 54 L 75 80 L 50 63 L 25 80 L 34 54 L 11 38 L 39 38 Z" fill="#73EC8B" stroke="#1E5128" strokeWidth="3.5" strokeLinejoin="round" />
          <circle cx="42" cy="46" r="3.2" fill="#132F1A" />
          <circle cx="58" cy="46" r="3.2" fill="#132F1A" />
          <path d="M 47 52 Q 50 56, 53 52" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
          <circle cx="36" cy="49" r="1.5" fill="#FF8FA3" />
          <circle cx="64" cy="49" r="1.5" fill="#FF8FA3" />
        </svg>
      )
    },
    // 7. Bunga (Cute Eco Flower) - Top Center Left
    {
      id: 7,
      style: { left: '30%', top: '7%' },
      duration: 4.8,
      delay: 0.2,
      scale: 1.05,
      svg: (
        <svg viewBox="0 0 100 100" className="w-13 h-13 filter drop-shadow-md">
          {/* Petals */}
          <circle cx="50" cy="32" r="13" fill="#FF8FA3" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="32" cy="50" r="13" fill="#FF8FA3" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="68" cy="50" r="13" fill="#FF8FA3" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="50" cy="68" r="13" fill="#FF8FA3" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="37" cy="37" r="13" fill="#FFD6DC" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="63" cy="37" r="13" fill="#FFD6DC" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="37" cy="63" r="13" fill="#FFD6DC" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="63" cy="63" r="13" fill="#FFD6DC" stroke="#1E5128" strokeWidth="2.5" />
          {/* Core */}
          <circle cx="50" cy="50" r="14" fill="#FACC15" stroke="#1E5128" strokeWidth="3" />
          <circle cx="44" cy="47" r="2.5" fill="#132F1A" />
          <circle cx="56" cy="47" r="2.5" fill="#132F1A" />
          <path d="M 47 52 Q 50 55, 53 52" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
        </svg>
      )
    },
    // 8. Ulat (Cute Caterpillar) - Bottom Center Left
    {
      id: 8,
      style: { left: '26%', bottom: '9%' },
      duration: 3.6,
      delay: 0.55,
      scale: 1.0,
      svg: (
        <svg viewBox="0 0 120 100" className="w-15 h-15 filter drop-shadow-md">
          {/* Segmented body */}
          <circle cx="30" cy="55" r="12" fill="#A8DF8E" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="48" cy="52" r="12" fill="#73EC8B" stroke="#1E5128" strokeWidth="2.5" />
          <circle cx="66" cy="48" r="12" fill="#A8DF8E" stroke="#1E5128" strokeWidth="2.5" />
          {/* Head */}
          <circle cx="84" cy="42" r="14" fill="#73EC8B" stroke="#1E5128" strokeWidth="3" />
          {/* Antennas */}
          <path d="M 80 30 Q 75 16, 73 18" stroke="#1E5128" strokeWidth="2" fill="none" />
          <circle cx="73" cy="18" r="2" fill="#FF8FA3" />
          <path d="M 88 30 Q 93 16, 95 18" stroke="#1E5128" strokeWidth="2" fill="none" />
          <circle cx="95" cy="18" r="2" fill="#FF8FA3" />
          {/* Facial features */}
          <circle cx="80" cy="38" r="2" fill="#132F1A" />
          <circle cx="90" cy="38" r="2" fill="#132F1A" />
          <path d="M 82 44 Q 85 47, 88 44" stroke="#132F1A" strokeWidth="1.5" strokeLinecap="round" fill="none" />
          <circle cx="76" cy="41" r="1.5" fill="#FF8FA3" />
          <circle cx="94" cy="41" r="1.5" fill="#FF8FA3" />
        </svg>
      )
    },
    // 9. Kupu-Kupu (Fluttering Colorful Butterfly) - Top Center Right
    {
      id: 9,
      style: { right: '28%', top: '8%' },
      duration: 4.1,
      delay: 0.1,
      scale: 1.05,
      svg: (
        <svg viewBox="0 0 100 100" className="w-14 h-14 filter drop-shadow-md">
          {/* Wings */}
          <path d="M 50 50 C 50 30, 25 15, 25 35 C 25 50, 48 50, 50 50" fill="#FFD6DC" stroke="#1E5128" strokeWidth="2.5" />
          <path d="M 50 50 C 50 30, 75 15, 75 35 C 75 50, 52 50, 50 50" fill="#FFD6DC" stroke="#1E5128" strokeWidth="2.5" />
          <path d="M 50 50 C 50 68, 30 78, 30 65 C 30 55, 48 53, 50 50" fill="#FF8FA3" stroke="#1E5128" strokeWidth="2" />
          <path d="M 50 50 C 50 68, 70 78, 70 65 C 70 55, 52 53, 50 50" fill="#FF8FA3" stroke="#1E5128" strokeWidth="2" />
          {/* Body */}
          <rect x="47" y="32" width="6" height="40" rx="3" fill="#60A5FA" stroke="#1E5128" strokeWidth="2.5" />
          {/* Antennas */}
          <path d="M 48 32 Q 40 22, 42 21" stroke="#1E5128" strokeWidth="1.5" fill="none" />
          <path d="M 52 32 Q 60 22, 58 21" stroke="#1E5128" strokeWidth="1.5" fill="none" />
          {/* Eyes */}
          <circle cx="49" cy="35" r="1" fill="#132F1A" />
          <circle cx="51" cy="35" r="1" fill="#132F1A" />
        </svg>
      )
    },
    // 10. Tong Sampah Mini (Happy Recycled Bin) - Bottom Center Right
    {
      id: 10,
      style: { right: '26%', bottom: '8%' },
      duration: 5.0,
      delay: 0.6,
      scale: 1.1,
      svg: (
        <svg viewBox="0 0 100 100" className="w-15 h-15 filter drop-shadow-md">
          <path d="M 33 28 L 67 28 L 60 84 L 40 84 Z" fill="#A8DF8E" stroke="#1E5128" strokeWidth="3.5" strokeLinejoin="round" />
          <rect x="30" y="20" width="40" height="8" rx="2" fill="#73EC8B" stroke="#1E5128" strokeWidth="3" />
          <path d="M 44 20 L 46 14 L 54 14 L 56 20" stroke="#1E5128" strokeWidth="2.5" strokeLinejoin="round" fill="none" />
          {/* Recycled arrow circle */}
          <path d="M 44 48 L 50 53 L 44 58" stroke="#1E5128" strokeWidth="2" fill="none" strokeLinecap="round" />
          <circle cx="50" cy="53" r="5" stroke="#1E5128" strokeWidth="2" fill="none" strokeDasharray="14 10" />
          {/* Face */}
          <circle cx="43" cy="38" r="2.8" fill="#132F1A" />
          <circle cx="57" cy="38" r="2.8" fill="#132F1A" />
          <path d="M 47 42 Q 50 45, 53 42" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
        </svg>
      )
    }
  ];

  return (
    <div 
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[linear-gradient(135deg,#E8F5E0_0%,#F4FAF0_50%,#E8F5E0_100%)] select-none text-[#0F172A] overflow-hidden" 
      id="splash-screen-container"
    >
      {/* Dynamic Background Grid Pattern in soft gray dots */}
      <div className="absolute inset-0 opacity-[0.4] pointer-events-none" style={{
        backgroundImage: 'radial-gradient(circle, #E2E8F0 1.5px, transparent 1.5px)',
        backgroundSize: '24px 24px'
      }} />

      {/* Scattered cute mini characters bouncing and swaying across the workspace */}
      {floatingItems.map((item) => (
        <motion.div
          key={item.id}
          className="absolute pointer-events-none select-none"
          style={item.style}
          initial={{ opacity: 0, scale: 0.2 }}
          animate={{
            opacity: [0.75, 1, 0.75],
            scale: [item.scale, item.scale * 1.08, item.scale],
            y: [0, -28, 0], // dynamic up-down bounce
            x: [0, 14, -14, 0], // organic leaves-swaying wind simulation!
            rotate: [0, 20, -20, 0] // gentle spin rotation
          }}
          transition={{
            y: {
              repeat: Infinity,
              duration: item.duration,
              ease: "easeInOut",
              delay: item.delay
            },
            x: {
              repeat: Infinity,
              duration: item.duration * 1.25,
              ease: "easeInOut",
              delay: item.delay
            },
            rotate: {
              repeat: Infinity,
              duration: item.duration * 1.45,
              ease: "easeInOut",
              delay: item.delay
            },
            opacity: {
              duration: 1.2,
              delay: item.delay
            }
          }}
        >
          {item.svg}
        </motion.div>
      ))}

      {/* Main Logo card and scanner layout */}
      <div className="max-w-md w-full px-6 flex flex-col items-center space-y-8 z-20">
        
        {/* Animated EcoScan Scanner Logo illustration */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 120, damping: 15 }}
          className="relative w-44 h-44 flex items-center justify-center"
        >
          {/* Glowing scanner ring on clean light background */}
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
            className="absolute inset-0 border-4 border-dashed border-[#2D6A2D]/60 rounded-full blur-[0.5px]"
          />
          <motion.div 
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
            className="absolute inset-2 border-2 border-dashed border-[#FF8FA3]/80 rounded-full"
          />

          {/* Core Smiling Leaf-Earth Logo graphic with subtle white backdrop shadow */}
          <div className="w-28 h-28 bg-white rounded-full flex items-center justify-center shadow-lg shadow-[#1E5128]/10 border-2 border-[#1E5128] relative overflow-hidden">
            <svg viewBox="0 0 100 100" className="w-21 h-21">
              {/* Earth/Leaf dual core symbol */}
              <circle cx="50" cy="50" r="30" fill="#7BC9FF" stroke="#1E5128" strokeWidth="3" />
              <path d="M 32 38 C 28 48, 42 55, 46 45 C 50 35, 36 28, 32 38 Z" fill="#73EC8B" />
              <path d="M 52 28 C 30 50, 45 78, 62 70 C 78 62, 70 42, 52 28 Z" fill="#73EC8B" stroke="#1E5128" strokeWidth="2" />
              <path d="M 52 28 L 62 70" stroke="#1E5128" strokeWidth="1.5" />
              {/* Smiling eyes */}
              <circle cx="42" cy="50" r="3.2" fill="#132F1A" />
              <circle cx="57" cy="50" r="3.2" fill="#132F1A" />
              <path d="M 46 56 Q 50 60, 54 56" stroke="#132F1A" strokeWidth="2" strokeLinecap="round" fill="none" />
              <circle cx="36" cy="53" r="1.5" fill="#FF8FA3" />
              <circle cx="63" cy="53" r="1.5" fill="#FF8FA3" />
            </svg>

            {/* Neon scanner laser line sweep */}
            <motion.div
              animate={{ y: [-10, 104, -10] }}
              transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
              className="absolute left-0 right-0 h-1.5 bg-[#FF8FA3] shadow-[0_0_12px_#FF8FA3] border-b border-[#fff]/40"
            />
          </div>
        </motion.div>

        {/* Title text and elegant Playfair Display + font-sans bold */}
        <div className="text-center space-y-2">
          <motion.h1
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="font-fredoka font-bold text-[64px] leading-none select-none mb-1 text-center"
          >
            <span className="text-[#FF8FA3]">Eco</span>
            <span className="text-[#1A4A0A]">Scan</span>
          </motion.h1>
          
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.28 }}
            className="font-nunito font-light text-xs sm:text-sm tracking-[3px] text-[#5A7A50] text-center"
          >
            PANDUAN DAUR ULANG PINTAR & INTERAKTIF
          </motion.p>
        </div>

        {/* Custom Progress slidebar widget styled inside light-green themes */}
        <div className="w-full max-w-[325px] space-y-4 bg-white/60 p-5 rounded-3xl border border-white/80 shadow-md shadow-[#1E5128]/5 backdrop-blur-sm">
          {/* Track and loading progress bar */}
          <div className="h-3 w-full bg-[#1E5128]/10 border border-[#1E5128]/5 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#FF8FA3] to-[#A8DF8E]"
              style={{ width: `${progress}%` }}
              transition={{ ease: "easeInOut" }}
            />
          </div>

          <div className="flex items-center justify-between border-b border-[#1E5128]/10 pb-2 text-[11px] tracking-wide">
            <span className="font-nunito font-normal text-[#3B6D11]">{loadingText}</span>
            <span className="font-fredoka font-semibold text-[#1A4A0A]">{Math.round(progress)}%</span>
          </div>

          {/* Interesting rotating Eco Tip Carousel elements with micro-transitions */}
          <div className="h-10 flex flex-col items-center justify-center text-center overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.p
                key={currentTipIndex}
                initial={{ y: 15, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -15, opacity: 0 }}
                transition={{ duration: 0.35 }}
                className="font-nunito text-[12px] text-[#5A7A50] leading-relaxed text-center"
              >
                {ECO_TIPS[currentTipIndex]}
              </motion.p>
            </AnimatePresence>
          </div>
        </div>

      </div>

      {/* Decorative credit text below */}
      <div className="absolute bottom-6 font-nunito text-[10px] font-light text-[#5A7A50] tracking-widest uppercase">
        EcoScan Indonesia © 2026
      </div>
    </div>
  );
}
