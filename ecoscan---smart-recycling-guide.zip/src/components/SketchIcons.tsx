import React from 'react';

export interface SketchIconProps extends React.SVGProps<SVGSVGElement> {
  className?: string;
  size?: number | string;
}

export const CameraSketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M2.5 8.2 C 2.5 7.2, 3.2 7.0, 4.2 7.0 L 7.8 7.0 C 8.4 7.0, 8.9 6.6, 9.3 6.0 L 10.1 4.8 C 10.5 4.2, 11.2 4.0, 12.0 4.0 L 13.5 4.0 C 14.3 4.0, 15.0 4.2, 15.4 4.8 L 16.2 6.0 C 16.6 6.6, 17.1 7.0, 17.7 7.0 L 20.3 7.0 C 21.3 7.0, 22.0 7.2, 22.0 8.2 L 21.8 18.5 C 21.8 19.5, 21.0 19.8, 20.0 19.8 L 4.0 19.8 C 3.0 19.8, 2.2 19.5, 2.2 18.5 Z" />
    <path d="M12 15.5 C 13.9 15.5, 15.5 13.9, 15.5 12 C 15.5 10.1, 13.9 8.5, 12 8.5 C 10.1 8.5, 8.5 10.1, 8.5 12 C 8.5 13.9, 10.1 15.5, 12 15.5 Z" />
    <path d="M11.2 10.5 C 11.8 10.1, 12.5 10.1, 13.0 10.5" />
    <path d="M18.8 9.5 C 19.2 9.5, 19.5 9.2, 19.5 8.8 C 19.5 8.4, 19.2 8.1, 18.8 8.1 C 18.4 8.1, 18.1 8.4, 18.1 8.8 C 18.1 9.2, 18.4 9.5, 18.8 9.5 Z" />
  </svg>
);

export const BookSketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M12 20.5 C 7.5 19.5, 4.5 19.8, 2.5 21.0 L 2.8 5.5 C 4.8 4.2, 7.8 4.0, 12 5.0 C 16.2 4.0, 19.2 4.2, 21.2 5.5 L 21.5 21.0 C 19.5 19.8, 16.5 19.5, 12 20.5" />
    <path d="M12 5.0 L 12 20.5" />
    <path d="M4.5 8.2 C 6.5 7.5, 8.5 7.5, 10.2 8.0" />
    <path d="M4.5 11.5 C 6.5 10.8, 8.5 10.8, 10.2 11.3" />
    <path d="M4.5 14.8 C 6.5 14.1, 8.5 14.1, 10.2 14.6" />
    <path d="M13.8 8.0 C 15.5 7.5, 17.5 7.5, 19.5 8.2" />
    <path d="M13.8 11.3 C 15.5 10.8, 17.5 10.8, 19.5 11.5" />
    <path d="M13.8 14.6 C 15.5 14.1, 17.5 14.1, 19.5 14.8" />
  </svg>
);

export const LeafSketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M2.2 21.5 C 3.5 19.0, 5.0 16.5, 7.5 13.8" />
    <path d="M7.5 13.8 C 10.0 10.5, 12.2 6.5, 21.5 2.5 C 20.0 11.5, 15.5 15.5, 7.5 13.8 Z" />
    <path d="M7.5 13.8 C 10.5 11.5, 14.0 9.0, 18.5 5.5" />
    <path d="M11.0 11.0 C 11.5 9.0, 13.0 8.0, 14.5 7.0" />
    <path d="M14.0 12.5 C 14.5 10.8, 16.2 10.2, 17.5 9.5" />
    <path d="M9.8 12.2 C 8.5 10.5, 8.0 9.2, 7.5 7.8" />
  </svg>
);

export const PencilSketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M17.8 3.5 L 20.5 6.2 C 21.0 5.7, 21.0 4.8, 20.5 4.3 L 19.6 3.4 C 19.1 2.9, 18.2 2.9, 17.7 3.4 Z" />
    <path d="M16.5 4.8 L 19.2 7.5" />
    <path d="M6.5 14.8 L 17.8 3.5" />
    <path d="M9.2 17.5 L 20.5 6.2" />
    <path d="M7.8 16.2 L 19.1 4.8" />
    <path d="M6.5 14.8 L 3.2 20.8 C 3.1 20.9, 3.1 21.0, 3.2 21.1 C 3.3 21.2, 3.4 21.2, 3.5 21.1 L 9.2 17.5 Z" />
    <path d="M3.2 20.8 L 4.8 19.2" />
  </svg>
);

export const ClockSketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M12 21.5 C 17.2 21.5, 21.5 17.2, 21.5 12 C 21.5 6.8, 17.2 2.5, 12 2.5 C 6.8 2.5, 2.5 6.8, 2.5 12 C 2.5 17.2, 6.8 21.5, 12 21.5 Z" />
    <path d="M12 12 L 12.2 7.2" />
    <path d="M12 12 L 15.8 14.5" />
    <circle cx="12" cy="12" r="1.0" fill="currentColor" />
  </svg>
);

export const SparklesSketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M12 3 C 12 8, 12 10, 16 11 C 12 12, 12 14, 12 21 C 12 14, 12 12, 8 11 C 12 10, 12 8, 12 3 Z" />
    <path d="M19 6 C 19 8, 19 8.5, 21 9 C 19 9.5, 19 10, 19 12 C 19 10, 19 9.5, 17 9 C 19 8.5, 19 8, 19 6 Z" />
    <path d="M6 14 C 6 15, 6 15.5, 7 16 C 6 16.5, 6 17, 6 18 C 6 17, 6 16.5, 5 16 C 6 15.5, 6 15, 6 14 Z" />
  </svg>
);

export const TrashSketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M3.2 6.0 L 20.8 6.0" />
    <path d="M8.2 6.0 C 8.2 4.2, 9.5 3.5, 12.0 3.5 C 14.5 3.5, 15.8 4.2, 15.8 6.0" />
    <path d="M5.5 6.0 L 6.5 19.5 C 6.5 20.5, 7.5 20.8, 8.5 20.8 L 15.5 20.8 C 16.5 20.8, 17.5 20.5, 17.5 19.5 L 18.5 6.0" />
    <path d="M9.8 10.0 L 9.8 16.8" />
    <path d="M14.2 10.0 L 14.2 16.8" />
  </svg>
);

export const TrophySketch = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    <path d="M6.2 4.5 L 17.8 4.5 C 17.8 10.5, 16.5 13.5, 12.0 13.5 C 7.5 13.5, 6.2 10.5, 6.2 4.5 Z" />
    <path d="M12.0 13.5 L 12.0 18.2" />
    <path d="M8.5 18.2 L 15.5 18.2" />
    <path d="M7.0 20.5 L 17.0 20.5" />
    <path d="M6.2 6.5 C 4.0 6.5, 3.5 8.5, 3.5 10.0 C 3.5 11.5, 4.5 12.0, 6.2 11.0" />
    <path d="M17.8 6.5 C 20.0 6.5, 20.5 8.5, 20.5 10.0 C 20.5 11.5, 19.5 12.0, 17.8 11.0" />
  </svg>
);

export const EcoScanLogo = ({ className, size = 20, ...props }: SketchIconProps) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    {...props}
  >
    {/* Clean, rounded modern leaf outline */}
    <path d="M12 2 C17.3 6, 21.2 11, 18.2 17 C16.2 20, 13.5 21.5, 12 22 C10.5 21.5, 7.8 20, 5.8 17 C2.8 11, 6.7 6, 12 2 Z" />
    
    {/* Simple parallel lines inside the leaf */}
    <path d="M9 8.5 L15 8.5" />
    <path d="M7.5 12 L16.5 12" />
    <path d="M9 15.5 L15 15.5" />

    {/* Subtle horizontal scan line cutting through the middle */}
    <path d="M1.5 12 L22.5 12" strokeWidth="1.2" strokeDasharray="1.5 2" className="opacity-75" />
  </svg>
);
