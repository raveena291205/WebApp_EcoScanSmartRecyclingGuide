import React from 'react';
import { Coins, Menu, X } from 'lucide-react';
import { getLevelInfo } from '../utils/level';
import { CameraSketch, BookSketch, LeafSketch, PencilSketch, ClockSketch, EcoScanLogo } from './SketchIcons';

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  points: number;
}

export default function Header({ currentPage, setCurrentPage, points }: HeaderProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const currentLvl = getLevelInfo(points);

  const navItems = [
    { id: 'scan', label: 'Pindai Sampah', icon: CameraSketch },
    { id: 'guide', label: 'Panduan', icon: BookSketch },
    { id: 'facts', label: 'Fakta Lingkungan', icon: LeafSketch },
    { id: 'quiz', label: 'Kuis Hijau', icon: PencilSketch },
    { id: 'log', label: 'Log Saya', icon: ClockSketch },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full bg-white border-b border-[#E8F5E8] shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo Brand */}
          <div 
            onClick={() => setCurrentPage('scan')}
            className="flex items-center space-x-2 cursor-pointer group"
          >
            <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 text-[#1A4A0A] group-hover:scale-105 transition-transform duration-300">
              <EcoScanLogo className="h-6 w-6" />
            </div>
            <div>
              <span className="font-fredoka text-xl font-bold tracking-tight text-[#1A4A0A] sm:text-2xl">
                Eco<span className="text-[#A8DF8E]">Scan</span>
              </span>
              <p className="text-[9px] uppercase tracking-wider font-nunito font-semibold text-[#5A7A50] -mt-1 hidden sm:block">
                Panduan Daur Ulang Pintar
              </p>
            </div>
          </div>

          {/* Desktop Nav Items */}
          <div className="hidden md:flex items-center space-x-1 lg:space-x-2 h-16">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setIsOpen(false);
                  }}
                  className={`flex items-center space-x-1.5 px-3.5 h-full text-xs font-bold tracking-wide transition-all duration-200 relative ${
                    isActive
                      ? 'text-[#1A4A0A]'
                      : 'text-[#5A7A50] hover:text-[#1A4A0A]'
                  }`}
                >
                  <IconComponent className={`h-4.5 w-4.5 ${isActive ? 'text-[#1A4A0A]' : 'text-[#5A7A50]'}`} />
                  <span className="leading-none font-fredoka">{item.label}</span>
                  {isActive && (
                    <span className="absolute bottom-0 left-3.5 right-3.5 h-[2.5px] bg-[#A8DF8E] rounded-full" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Persistent Gamer Eco Points Badge */}
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            {/* Level Badge next to points */}
            <div className="flex items-center space-x-1 px-3 py-1.5 rounded-full border border-[#1A4A0A] bg-white shadow-sm text-xs font-bold text-[#1A4A0A]">
              <span className="font-fredoka tracking-wide">{currentLvl.name}</span>
            </div>
 
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-[#A8DF8E] text-[#1A4A0A] shadow-sm border border-[#A8DF8E]">
               <Coins className="h-4 w-4 text-[#1A4A0A]" />
               <span className="font-fredoka font-extrabold text-sm">{points}</span>
               <span className="text-[9px] uppercase font-fredoka tracking-wider font-extrabold">POIN</span>
             </div>

            {/* Mobile Menu Toggle Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex md:hidden items-center justify-center p-2 rounded-xl text-slate-600 hover:bg-slate-150 focus:outline-none transition-all duration-200"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Overlay */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-[#E0F0D8] px-4 pt-2 pb-4 space-y-1 shadow-md">
          {navItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentPage(item.id);
                  setIsOpen(false);
                }}
                className={`flex items-center space-x-3 w-full px-4 py-3 rounded-xl text-left transition-all duration-200 ${
                  isActive
                    ? 'bg-[#E0F0D8]/40 text-[#1A4A0A] font-bold border-l-4 border-[#A8DF8E]'
                    : 'text-[#5A7A50] hover:bg-slate-50'
                }`}
              >
                <IconComponent className={`h-5 w-5 ${isActive ? 'text-[#1A4A0A]' : 'text-[#5A7A50]'}`} />
                <div>
                  <span className="block font-fredoka text-sm font-semibold">{item.label}</span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </nav>
  );
}
